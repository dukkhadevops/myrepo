﻿$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users
$cert = Get-ChildItem Cert:\LocalMachine\My -DnsName "secretserver"
#cert.thumbprint
#$secretid = 8352
$searchterm = "svcDVHAuthDev"

Function FindSecretID ($searchterm){

    #initial setup of webservice proxy using the url we set
    $proxy = New-WebServiceProxy $url -UseDefaultCredential

    #try to authenticate using the user, pass and domain we provided. this is the login to SecretServer
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0)
        {
            $result1.Errors[0]
            exit
        } 
    else 
        {
            #save our login session token into $token
            $token = $result1.Token
        }
    
    #use search term to find the ID of the Secret 
    $result2 = $proxy.SearchSecrets($token, $searchterm,$null,$null)
    if ($result2.Errors.length -gt 0)
        {
            $result2.Errors[0]
        }
    else
        {
        $secretname = $result2.SecretSummaries.SecretName
        $secretid = $result2.SecretSummaries.SecretID
        Write-Host $secretname " $secretid"
        }
}

#call function
#FindSecretID $searchterm

Function GetSecret ($secretID){
    
    $proxy = New-WebServiceProxy $url -UseDefaultCredential
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0)
        {
            $result1.Errors[0]
            exit
        } 
    else 
        {
            $token = $result1.Token
        }
    $result2 = $proxy.GetSecret($token, $secretId, $false, $null)

    #return the password
    $returnvalue = $result2.Secret.Items[2].Value
    Write-Host $returnvalue

}

#call function
GetSecret $secretid


