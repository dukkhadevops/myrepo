#########
# Author:       Matt Keller
# Description:  Powershell DSC to configure Windows Features & setup files/folders for API Servers to be used in conjunction with other API Server DSC
# Changes:      03/28/2018      Initial creation
#
#########
#########
#ASSUMPTION: You are copying this script out to the server then executing it from there
#########

#install dynatrace from \\cbcnas04\shared\dynatrace
#setup dynatrace server collector - address dvdtcol01uwap port 9998 (or get info from Malik)

#Install Thawte Root & Intermediate Certificates - \\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte_primary_root_ca & thawte EV SSL CA - G3

Set-ExecutionPolicy Unrestricted
$dvconfigpath = "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi01uwaq\conf\dvconfig.xml"
$path1 = "c:\app"
$path2 = "c:\app\conf"
$path3 = "c:\app\log"
$path4 = "c:\www"

Configuration ManageFeatures-API-Dev {
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $env:computername {

        ########
        #Basic File & Folder section. Permissions???
        ########
        File appDir #setup c:\app
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path1
        }

        File confDir #c:\app\conf
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path2
        }

        File logDir #c:\app\log
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path3
        }

        #get DVConfig and put it in c:\app\conf
        File DVConfig
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "File" # Default is "File".
            SourcePath = "$dvconfigpath"
            DestinationPath = "C:\app\conf\dvconfig.xml"
        }

        File wwwDir #c:\www
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path4
        }

        ########
        #Windows Roles & Features section. These should all be relatively in order based on how they appear when you do a get-windowsfeature -name *web*
        ########
        WindowsFeature Web-Server  # Web Server (IIS) base/root feature
        {
               Name = "Web-Server"
               Ensure = "Present"
        }

        WindowsFeature Web-WebServer  # Web Server continued (IIS) parent featureset
        {
               Name = "Web-WebServer"
               Ensure = "Present"
        }

        WindowsFeature Web-Common-Http  # Common Http Features parent featureset
        {
               Name = "Web-Common-Http"
               Ensure = "Present"
        }

        WindowsFeature Web-Default-Doc  # Default Document
        {
               Name = "Web-Default-Doc"
               Ensure = "Present"
        }

        WindowsFeature Web-Dir-Browsing  # Directory Browsing
        {
               Name = "Web-Dir-Browsing"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Errors  # Http Errors
        {
               Name = "Web-Http-Errors"
               Ensure = "Present"
        }

        WindowsFeature Web-Static-Content  # Static Content
        {
               Name = "Web-Static-Content"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Redirect  # Http redirection
        {
               Name = "Web-Http-Redirect"
               Ensure = "Present"
        }

        WindowsFeature Web-Health # Health and Diagnostics parent featureset
        {
               Name = "Web-Health"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Logging # Http Logging
        {
               Name = "Web-Http-Logging"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Tracing  # Tracing
        {
               Name = "Web-Http-Tracing"
               Ensure = "Present"
        }

        WindowsFeature Web-Performance  # Performance parent featureset
        {
               Name = "Web-Performance"
               Ensure = "Present"
        }

        WindowsFeature Web-Stat-Compression  # Static Content Compression
        {
               Name = "Web-Stat-Compression"
               Ensure = "Present"
        }

        WindowsFeature Web-Security  # Security parent featureset
        {
               Name = "Web-Security"
               Ensure = "Present"
        }

        WindowsFeature Web-Filtering  # Request Filtering
        {
               Name = "Web-Filtering"
               Ensure = "Present"
        }

        WindowsFeature Web-App-Dev  # Application Development parent featureset
        {
               Name = "Web-App-Dev"
               Ensure = "Present"
        }

        WindowsFeature Web-Net-Ext45  # .NET Extensibility 4.5
        {
             Name = "Web-Net-Ext"
             Ensure = "Present"
        }

        WindowsFeature Web-AppInit  # Application Initialization
        {
             Name = "Web-AppInit"
             Ensure = "Present"
        }

        WindowsFeature Web-Asp-Net45  # ASP.NET 4.5
        {
             Name = "Web-Asp-Net45"
             Ensure = "Present"
        }

        WindowsFeature Web-ISAPI-Ext  # ISAPI Extensions
        {
             Name = "Web-ISAPI-Ext"
             Ensure = "Present"
        }

        WindowsFeature Web-ISAPI-Filter  # ISAPI Filters
        {
             Name = "Web-ISAPI-Filter"
             Ensure = "Present"
        }

        WindowsFeature Web-Mgmt-Tools  # Management Tools parent featureset
        {
             Name = "Web-Mgmt-Tools"
             Ensure = "Present"
        }

        WindowsFeature Web-Mgmt-Console  # IIS Management Console
        {
             Name = "Web-Mgmt-Console"
             Ensure = "Present"
        }

        ########
        #NON IIS Windows Features section
        ########
        WindowsFeature Net-Framework-Features  # .Net Framework 3.5 Features parent featureset
        {
             Name = "Net-Framework-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-Core  # .Net Framework 3.5 (.NET 2.0 and 3.0)
        {
             Name = "Net-Framework-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Features  # .Net Framework 4.5 Features parent featureset
        {
             Name = "Net-Framework-45-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Core  # .Net Framework 4.5
        {
             Name = "Net-Framework-45-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-ASPNET  # ASP.NET 4.5
        {
             Name = "Net-Framework-45-ASPNET"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-Services45  # WCF Services
        {
             Name = "Net-WCF-Services45"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-TCP-PortSharing45  # TCP Port Sharing
        {
             Name = "Net-Framework-Core"
             Ensure = "Present"
        }

    }

    }

ManageFeatures-API-Dev -OutputPath C:\dsc-mof\ManageFeatures-API-Dev
Publish-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\ManageFeatures-API-Dev -Wait -ErrorAction Stop -Force -Verbose
