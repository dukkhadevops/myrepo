﻿ #####################################################################################
 #It might be a good idea to use this section to automatically install prerequisites
 #Target Prereqs - Powershell 5.0, DSC Resources like xWebAdministration etc
 #Source Prereqs - Powershell 5.0, DSC Resources like xWebAdministration etc
 #####################################################################################
 #This isn't done yet because getting DSC itself working is more important as opposed to automating Powershell installs
 #
 #
 #
 #
 #
 #


 #In practice, this hashtable is likely to be stored in a separate file or even generated on the fly by reading from a database.
 #For us, the important part is that this configuration data MUST be set outside of the configuration keyword itself (line 22 currently)
 #You can set the configuration data many ways or feed it in but it MUST be set prior to executing the configuration.

 $ConfigData= 
    @{
        AllNodes = @(
                        @{
                            #the name of the node we are describing
                            NodeName = "HQWEBDEV03"
                            Role = "Web"

                            #The path to the .cer file containing the public key of the encryption cert
                            CertificateFile = "C:\certs\HQWebDev03DSCPublicKey.cer"

                            #The thumbprint of the encryption cert used to decrypt the credentials on target node
                            Thumbprint = "‎‎‎‎cb 1d e4 10 7a 9d 73 1a 27 26 71 64 4f 6b 8b f1 8e c3 bd 7b"
                        };
                    );
    }

configuration DSC_POC
{
  #Take in credentials - CertPassword is used to access the Website Cert - not a password for the cert used to secure the MOF itself
  ######################### keep in mind for CertPassword that the PSCredential object WILL ask for a username but ANY username is valid
  #Take in credentials - localCredentials is used for the Author Node - what user and pass to use?
  param
  (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullorEmpty()]
    [PsCredential] $CertPassword = (Get-Credential -Message "Enter PFX extraction password." -Username "Ignore")
    #[PsCredential] $localCredentials = (Get-Credential -Message "Enter author node local user and password.")
    [PsCredential] $DFSCredentials = (Get-Credential -Message "Enter domain credentials with access to the area of DFS you're using.")
  )

  #Import all the DSC Resources we are going to use. Remember that these must all be installed before we can import them into this session.
     Import-DscResource -ModuleName xWebAdministration
     Import-DscResource –ModuleName PSDesiredStateConfiguration
     Import-DscResource -ModuleName xCertificate

  #Set the cert in a variable for use. Get the CN from the cert details tab, subject should have CN = xyz
    $cert = dir Cert:\LocalMachine\My | where {$_.Subject -eq 'CN = HQWEBDEV03' }

  #node Dev02
  #If you want to use "roles" within the config use this below
  #node $AllNodes.Where{$_.Role -eq "Web"}.NodeName

  #$AllNodes is a shortcut for $ConfigData['AllNodes']
  node $AllNodes.NodeName
  {
        #Set a path for where you want logging and the app pool recycle hour
        #make sure the $logFilePath exists on the Target server.
          $logFilePath = 'C:\IISLogs'
          $appPoolRecycleHour = '02'

        #Give the LCM a cert to encrypt with
        LocalConfigurationManager
        {
            CertificateID = $cert.Thumbprint
        }
        
        #Ensure the Cert & CertStore Directories are Present on the machine
            File DirectoryCertStore
            {
                Ensure = "Present"
                Type = "Directory"
                DestinationPath = "C:\CertStore"
            }

       #Copy the Website Cert to the proper location from DFS
          File CopyPersonalCert
          {
            Credential = $DFSCredentials
            Ensure = "Present"
            Type = "File"
            SourcePath = "\\safeautonet\dfs\repository\Certificates\SafeAutoNetWildcard Cert\2015-2017\Certificate - Personal\SafeAutoNetWildcard2017.pfx"
            DestinationPath = "C:\CertStore\SafeAutoNetWildcard2017.pfx"
            DependsOn = "[File]DirectoryCertStore"
          }
            
            #PersonalWildCardCert           
            xPfxImport InstallPersonalCert
            {
                Location = "LocalMachine"
                Store = "Personal"
                #Thumbprint = "‎70f3159c161b86a74db2a297699edd21"
                #Thumbprint = "74aacd8f3a5d5704b4db5855f0481075c0537488"
                Credential = $CertPassword
                Path = "C:\CertStore\SafeAutoNetWildcard2017.pfx"
                DependsOn = "[File]CopyPersonalCert"
            }
            

          #WindowsFeatures
          {
           WindowsFeature Web-App-Dev_Feature  # Application Development
          {
               Name = "Web-App-Dev"
               Ensure = "Present"
          }

          WindowsFeature Web-ASP_Feature  # ASP
          {
               Name = "Web-ASP"
               Ensure = "Absent"
          }

          WindowsFeature Web-Asp-Net_Feature  # ASP.NET
          {
               Name = "Web-Asp-Net"
               Ensure = "Present"
          }

          WindowsFeature Web-Basic-Auth_Feature  # Basic Authentication
          {
               Name = "Web-Basic-Auth"
               Ensure = "Present"
          }

          WindowsFeature Web-Cert-Auth_Feature  # IIS Client Certificate Mapping Authentication
          {
               Name = "Web-Cert-Auth"
               Ensure = "Present"
          }

          WindowsFeature Web-CGI_Feature  # CGI
          {
               Name = "Web-CGI"
               Ensure = "Absent"
          }

          WindowsFeature Web-Client-Auth_Feature  # Client Certificate Mapping Authentication
          {
               Name = "Web-Client-Auth"
               Ensure = "Present"
          }

          WindowsFeature Web-Common-Http_Feature  # Common HTTP Features
          {
               Name = "Web-Common-Http"
               Ensure = "Present"
          }

          WindowsFeature Web-Custom-Logging_Feature  # Custom Logging
          {
               Name = "Web-Custom-Logging"
               Ensure = "Absent"
          }

          WindowsFeature Web-DAV-Publishing_Feature  # WebDAV Publishing
          {
               Name = "Web-DAV-Publishing"
               Ensure = "Absent"
          }

          WindowsFeature Web-Default-Doc_Feature  # Default Document
          {
               Name = "Web-Default-Doc"
               Ensure = "Present"
          }

          WindowsFeature Web-Digest-Auth_Feature  # Digest Authentication
          {
               Name = "Web-Digest-Auth"
               Ensure = "Present"
          }

          WindowsFeature Web-Dir-Browsing_Feature  # Directory Browsing
          {
               Name = "Web-Dir-Browsing"
               Ensure = "Present"
          }

          WindowsFeature Web-Dyn-Compression_Feature  # Dynamic Content Compression
          {
               Name = "Web-Dyn-Compression"
               Ensure = "Present"
          }

          WindowsFeature Web-Filtering_Feature  # Request Filtering
          {
               Name = "Web-Filtering"
               Ensure = "Present"
          }

          WindowsFeature Web-Ftp-Ext_Feature  # FTP Extensibility
          {
               Name = "Web-Ftp-Ext"
               Ensure = "Absent"
          }

          WindowsFeature Web-Ftp-Server_Feature  # FTP Server
          {
               Name = "Web-Ftp-Server"
               Ensure = "Absent"
          }

          WindowsFeature Web-Ftp-Service_Feature  # FTP Service
          {
               Name = "Web-Ftp-Service"
               Ensure = "Absent"
          }

          WindowsFeature Web-Health_Feature  # Health and Diagnostics
          {
               Name = "Web-Health"
               Ensure = "Present"
          }

          WindowsFeature Web-Http-Errors_Feature  # HTTP Errors
          {
               Name = "Web-Http-Errors"
               Ensure = "Present"
          }

          WindowsFeature Web-Http-Logging_Feature  # HTTP Logging
          {
               Name = "Web-Http-Logging"
               Ensure = "Present"
          }

          WindowsFeature Web-Http-Redirect_Feature  # HTTP Redirection
          {
               Name = "Web-Http-Redirect"
               Ensure = "Present"
          }

          WindowsFeature Web-Http-Tracing_Feature  # Tracing
          {
               Name = "Web-Http-Tracing"
               Ensure = "Present"
          }

          WindowsFeature Web-Includes_Feature  # Server Side Includes
          {
               Name = "Web-Includes"
               Ensure = "Absent"
          }

          WindowsFeature Web-IP-Security_Feature  # IP and Domain Restrictions
          {
               Name = "Web-IP-Security"
               Ensure = "Present"
          }

          WindowsFeature Web-ISAPI-Ext_Feature  # ISAPI Extensions
          {
               Name = "Web-ISAPI-Ext"
               Ensure = "Present"
          }

          WindowsFeature Web-ISAPI-Filter_Feature  # ISAPI Filters
          {
               Name = "Web-ISAPI-Filter"
               Ensure = "Present"
          }

          WindowsFeature Web-Lgcy-Mgmt-Console_Feature  # IIS 6 Management Console
          {
               Name = "Web-Lgcy-Mgmt-Console"
               Ensure = "Present"
          }

          WindowsFeature Web-Lgcy-Scripting_Feature  # IIS 6 Scripting Tools
          {
               Name = "Web-Lgcy-Scripting"
               Ensure = "Absent"
          }

          WindowsFeature Web-Log-Libraries_Feature  # Logging Tools
          {
               Name = "Web-Log-Libraries"
               Ensure = "Present"
          }

          WindowsFeature Web-Metabase_Feature  # IIS 6 Metabase Compatibility
          {
               Name = "Web-Metabase"
               Ensure = "Present"
          }

          WindowsFeature Web-Mgmt-Compat_Feature  # IIS 6 Management Compatibility
          {
               Name = "Web-Mgmt-Compat"
               Ensure = "Present"
          }

          WindowsFeature Web-Mgmt-Console_Feature  # IIS Management Console
          {
               Name = "Web-Mgmt-Console"
               Ensure = "Present"
          }

          WindowsFeature Web-Mgmt-Service_Feature  # Management Service
          {
               Name = "Web-Mgmt-Service"
               Ensure = "Present"
          }

          WindowsFeature Web-Mgmt-Tools_Feature  # Management Tools
          {
               Name = "Web-Mgmt-Tools"
               Ensure = "Present"
          }

          WindowsFeature Web-Net-Ext_Feature  # .NET Extensibility
          {
               Name = "Web-Net-Ext"
               Ensure = "Present"
          }

          WindowsFeature Web-ODBC-Logging_Feature  # ODBC Logging
          {
               Name = "Web-ODBC-Logging"
               Ensure = "Absent"
          }

          WindowsFeature Web-Performance_Feature  # Performance
          {
               Name = "Web-Performance"
               Ensure = "Present"
          }

          WindowsFeature Web-Request-Monitor_Feature  # Request Monitor
          {
               Name = "Web-Request-Monitor"
               Ensure = "Present"
          }

          WindowsFeature Web-Scripting-Tools_Feature  # IIS Management Scripts and Tools
          {
               Name = "Web-Scripting-Tools"
               Ensure = "Present"
          }

          WindowsFeature Web-Security_Feature  # Security
          {
               Name = "Web-Security"
               Ensure = "Present"
          }

          WindowsFeature Web-Server_Feature  # Web Server (IIS)
          {
               Name = "Web-Server"
               Ensure = "Present"
          }

          WindowsFeature Web-Stat-Compression_Feature  # Static Content Compression
          {
               Name = "Web-Stat-Compression"
               Ensure = "Present"
          }

          WindowsFeature Web-Static-Content_Feature  # Static Content
          {
               Name = "Web-Static-Content"
               Ensure = "Present"
          }

          WindowsFeature Web-Url-Auth_Feature  # URL Authorization
          {
               Name = "Web-Url-Auth"
               Ensure = "Present"
          }

          WindowsFeature Web-WebServer_Feature  # Web Server
          {
               Name = "Web-WebServer"
               Ensure = "Present"
          }

          WindowsFeature Web-WHC_Feature  # IIS Hostable Web Core
          {
               Name = "Web-WHC"
               Ensure = "Absent"
          }

          WindowsFeature Web-Windows-Auth_Feature  # Windows Authentication
          {
               Name = "Web-Windows-Auth"
               Ensure = "Present"
          }

          WindowsFeature Web-WMI_Feature  # IIS 6 WMI Compatibility
          {
               Name = "Web-WMI"
               Ensure = "Absent"
          }

          #EndWindowsFeatures
          }

          #WebsiteConfiguration
          {

          #================== 'AuthorizationServiceTest' site definition ==================
          xWebAppPool AuthorizationServiceTest_Pool
          {
               Name = "AuthorizationServiceTest"
               AutoStart = $true
               ManagedPipelineMode = "Integrated"
               ManagedRuntimeVersion = "v4.0"
               IdentityType = "SpecificUser"
               Enable32BitAppOnWin64 = $false
               RestartSchedule = @($appPoolRecycleHour+':02:00')  # overriding @('06:00:00')
               IdleTimeout = "00:00:00"
               RestartTimeLimit = "00:00:00"
          }

          xWebSite AuthorizationServiceTest_Site
          {
               Name = "AuthorizationServiceTest"
               Ensure = "Present"
               State = "Started"
               ApplicationPool = "AuthorizationServiceTest"
               PhysicalPath = "C:\Websites\AuthorizationServiceTest"  # This folder must already exist
               LogPath = $logFilePath  # overriding "C:\websites\logs\LogFiles"
               DependsOn = "[xWebAppPool]AuthorizationServiceTest_Pool"
               BindingInfo = 
                         @(
                              MSFT_xWebBindingInformation 
                              {
                                   Protocol = "https"
                                   Port = "443"
                                   IPAddress = "192.168.108.164"
                                   CertificateStoreName = "My"
                                   CertificateThumbprint = "‎70f3159c161b86a74db2a297699edd21"
                              }
                         )
          }
          

          #EndWebsiteConfiguration
          }

  #EndNode
  }

#EndConfiguration
}

###############################
#STEP 1########################
###############################
# Compile this DSC down to an .MOF:  A .mof file will be placed in the specified directory
# This is also where we pass in the config data which is so critical in getting the Certificate piece to work properly
DSC_POC -outputpath "c:\powershell\drop" -ConfigurationData $ConfigData -Verbose

###############################
#STEP 2########################
###############################
#Push the MOF file generated to the target node.
#Your authoring node must be able to reach the target node!
#Set-DscLocalConfigurationManager -Computer "dev02" -path "C:\powershell\drop"

###############################
#STEP 3########################
###############################
# Apply the DSC. We use some additional switches like Debug and Verbose for more output.  ALL .mof's in a folder will be executed!
#Start-dscconfiguration -Path "C:\powershell\drop" -wait -debug -erroraction stop -force -verbose

###############################
#JUNK##########################
###############################
#-computername "vagrant-2012-r2"
#Start-DscConfiguration -ConfigurationData $ConfigData -Path "C:\powershell\drop" -CertPassword -Wait -Debug -ErrorAction Stop -Force -Verbose