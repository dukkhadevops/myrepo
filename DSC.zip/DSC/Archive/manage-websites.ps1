########
# Author:       Will Goshen
# Description:  This script uses Powershell DSC to enforce Module configuration for DataVerify IIS servers
# Changes:      7/17/2017 - Initial creation
########

Set-ExecutionPolicy Unrestricted

$application = "@node.application@"
$hostname = "@node.hostname@"

if ($application -eq "Api") {
    $websites = @(
        @{
            Name = "Internal API"
            HttpPort = 4080
            HttpsPort = 443
            SSLCertificate = $hostname
            PhysicalPath = "C:\www"
            SiteAppPool = "DVINApi"
            preloadEnabled = $true
            AppPoolBindings = @(
                @{ Name = "AddressValidation"; AppPool = "AddressValidation"; PhysicalPoolPath = "C:\www\AddressValidation" }
                @{ Name = "DVAuth"; AppPool = "DVAuth"; PhysicalPoolPath = "C:\www\DVAuth" }
                @{ Name = "EarlyWarning"; AppPool = "EarlyWarning"; PhysicalPoolPath = "C:\www\EarlyWarning" }
                @{ Name = "EquifaxMock.Api"; AppPool = "EquifaxMock.api"; PhysicalPoolPath = "C:\www\EquifaxMock.Api" }
                @{ Name = "FNMAapi"; AppPool = "FNMAapi"; PhysicalPoolPath = "C:\www\FNMAapi" }
                @{ Name = "Finicity"; AppPool = "Finicity"; PhysicalPoolPath = "C:\www\Finicity" }
                @{ Name = "lbmonitor"; AppPool = "lbmonitor"; PhysicalPoolPath = "C:\www\lbmonitor" }
                @{ Name = "IV"; AppPool = "IV"; PhysicalPoolPath = "C:\www\IV" }
                @{ Name = "PDFCreatorAPI"; AppPool = "DVINApi"; PhysicalPoolPath = "C:\www\PDFCreatorAPI" }
                @{ Name = "ReportAPI"; AppPool = "EarlyWarning"; PhysicalPoolPath = "C:\www\ReportAPI" }
                @{ Name = "UDM"; AppPool = "UDM"; PhysicalPoolPath = "C:\www\UDM" }
                @{ Name = "VOEI"; AppPool = "VOEI"; PhysicalPoolPath = "C:\www\VOEI" }
            )
        }
    )
}

Configuration ManageWebsites {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    
    Node $hostname {
        foreach ($website in $websites) {
            $websiteName = $website.Name
            xWebsite "$websiteName Website Configuration" {
                Name = $website.Name
                Ensure = "Present"
                State = "Started"
                PhysicalPath = $website.PhysicalPath
                ApplicationPool = $website.SiteAppPool
                PreloadEnabled = $website.preloadEnabled
                BindingInfo = @(
                    MSFT_xWebBindingInformation {
                        Protocol = "http"
                        Port = $website.HttpPort
                        IPAddress = "*"
                        HostName = $hostname
                    }
                    MSFT_xWebBindingInformation {
                        Protocol = "https"
                        Port = $website.HttpsPort
                        IPAddress = "*"
                        HostName = $hostname
                        CertificateStoreName = "My"
                        CertificateThumbprint = ((Get-ChildItem Cert:\LocalMachine\My | where { $_.Subject -eq "CN=" + $website.SSLCertificate}).Thumbprint)
                    }
                )
            }
            foreach ($appPool in $website.AppPoolBindings) {
                $appPoolName = $appPool.Name
                xWebApplication "$appPoolName Application Pool Configuration" {
                    Name = $appPool.Name
                    Ensure = "Present"
                    Website = $website.Name
                    WebAppPool = $appPool.AppPool
                    PhysicalPath = $appPool.PhysicalPoolPath
                    PreloadEnabled = $website.preloadEnabled
                }
            }
        }
    }
}

ManageWebsites -OutputPath C:\dsc-mof\ManageWebsites
Start-DscConfiguration -ComputerName $hostname -Path C:\dsc-mof\ManageWebsites -Wait -ErrorAction Stop -Force -Verbose