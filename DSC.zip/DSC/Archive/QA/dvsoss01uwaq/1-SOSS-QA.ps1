########
# Author:               Matt Keller
# Description:          Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:              04/2/2018      Initial creation
#                       04/17/2018     change pre-work script to use unified config model
#                       06/14/2018     update for dvweb01uwwl
#                       06/15/2018     add IIS windows feature install (fix ISAPI first run problem)
#                       06/18/2018     add copy job for ComputerManagementDSC module so I can setup scheduled tasks
#                       06/26/2018     change everything over to use on dvsoss01uwad
#                       06/27/2018     change everything over to use on dvsoss01uwaq
#
# Future Enhancements:  Add a way to read which modules you want to install from text file then install them
########
# make sure you are running this under your .cbc account
# $destPSModulepath should construct to = either c:\program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

$computers = Get-Content -Path "C:\SVN\WindowsAdmins\DSC\DV\QA\dvsoss01uwaq\computers.txt"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #SOSS
    $sossfileshare = "\\dfs\nas\dv_shared\webapp deploy\soss\soss_setup64.msi"
    $sossfilename = Split-Path $sossfileshare -Leaf
    $sosstargetdest = $localpath + "\" + $sossfilename
    $sossargs = "/i $sosstargetdest /quiet INSTALLLEVEL=1000"

    #soss_params.txt
    $sossparamstxt = "\\dfs\nas\dv_shared\WebApp Deploy\soss\QA-soss_params.txt"
    $sossparamstxtdestpath = "\\" + $target + "\C$\Program Files\ScaleOut_Software\StateServer\soss_params.txt"

    #soss.exe
    $sossexelocalpath = "C:\Program Files\Scaleout_Software\StateServer\soss.exe"
    $sossexeargs = "join" 

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy SOSS install locally & install via silent install using the path you specified above
        Try 
        {
            #copy jobs and echoes first
            echo "starting SOSS installer copy to $target"
            Copy-Item -Path $sossfileshare -Destination $destpath -ErrorAction Stop
            echo "SOSS installer copy okay on $target"

            #trigger install with echoes before and after
            echo "starting SOSS install on $target, this takes a couple minutes on the very first install attempt. its quicker on subsequent runs"
            Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath msiexec $p2 -Wait } -ArgumentList $sossargs -ErrorAction Stop
            echo "SOSS install okay on $target"

            #overwrite soss_params.txt in local install directory
            echo "starting soss_params.txt overwrite on $target"
            Copy-Item -Path $sossparamstxt -Destination $sossparamstxtdestpath -Force -ErrorAction Stop
            echo "soss_params.txt overwrite successful on $target"

            #start sleep for a period of time to see if we can get the join to work on the first try
            echo "start sleep for 15s on $target"
            Start-Sleep -s 15
            echo "end sleep on $target"

            #run soss.exe join
            echo "starting soss.exe join on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs -ErrorAction Stop
            echo "soss.exe join successful on $target"

            #reboot the Server
            echo "attempting reboot on $target."
            Restart-Computer -ComputerName $target -Force -ErrorAction SilentlyContinue
            echo "either the server restarted or it did not restart because someone was still logged in"
        }
        Catch
        {
            echo "one of the SOSS steps failed on $target"
            break
        }

        #endregion

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
}
