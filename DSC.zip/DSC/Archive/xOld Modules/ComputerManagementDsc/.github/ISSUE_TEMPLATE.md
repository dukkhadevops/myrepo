<!--
Your feedback and support is greatly appreciated, thanks for contributing!

Please prefix the issue title with the resource name, i.e. 'xComputer: Short description of my issue'
Please provide the following information regarding your issue (place N/A if the fields that don't apply to your issue):
-->
**Details of the scenario you tried and the problem that is occurring:**

**The DSC configuration that is using the resource (as detailed as possible):**

**Version of the Operating System and PowerShell the DSC Target Node is running:**

**Version of the DSC module you're using, or 'dev' if you're using current dev branch:**
