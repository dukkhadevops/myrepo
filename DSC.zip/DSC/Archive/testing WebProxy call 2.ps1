﻿$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users
$cert = Get-ChildItem Cert:\LocalMachine\My -DnsName "secretserver"
#cert.thumbprint
$secretid = 8352

Function GetSecret ($secretID){
    
    $proxy = New-WebServiceProxy $url -UseDefaultCredential
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0)
        {
            $result1.Errors[0]
            exit
        } 
    else 
        {
            $token = $result1.Token
        }
    $result2 = $proxy.GetSecret($token, $secretId, $false, $null)

    #return the password
    $returnvalue = $result2.Secret.Items[2].FieldName
    Write-Host $returnvalue

}

#call function
GetSecret $secretid
