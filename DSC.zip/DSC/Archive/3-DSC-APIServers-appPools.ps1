﻿########
# Author:       Matt Keller
# Description:  Powershell DSC to configure APP Pools & Sites in IIS for API Servers to be used in conjunction with other API Server DSC
# Changes:      03/28/2018      Initial creation
#               4/10/2018       Added GetSecret function for SecretServer calls
#               4/17/2018       Removed GetSecret functions and setting app pool identity for loop - moved to 5th script
########

##########
#ASSUMPTION: You are copying this script out to the server then executing it from there
##########

Set-ExecutionPolicy Unrestricted

#these are all the pools we'll be creating
$appPools = @(
        @{ AppPool = "AddressValidation"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "DVAuth"; AppPoolIdentity = "world\svcdvhauthdev" }
        @{ AppPool = "DVINApi"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "lbmonitor"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "EarlyWarning"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "EquifaxMock.api"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "Finicity"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "FNMAApi"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "UDM"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "VOEI"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "IV"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
    )

#these are all the default pools we'll be deleting
$defaultAppPools = @(
    "DefaultAppPool",
    ".NET v4.5",
    ".NET v4.5 Classic"
)

Configuration ManageApplicationPools-API-Dev {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName cNtfsAccessControl

    Node $env:computername {

        #setup site folder structure & permissions
        foreach($pool in $appPools)
        {
            #if the app pool name does not equal dvinapi then create the folders for each apppool/site
            #else do not create the folder. we need the app pool we dont need the folder & permissions because the
            #app pool is used for the base site not the web applications
            If( $pool.appPool -ne "DVINApi")
            {
                $poolName = $pool.AppPool
                $permissionname = $poolname + "permissions"
                $identity = $pool.AppPoolIdentity

                File $poolName #setup each sites directory
                                {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = "C:\www\$poolName"
            }
            
                cNtfsPermissionEntry $permissionname #setup permissions on each directory
                {
                    Ensure = 'Present'
                    Path = "C:\www\$poolname"
                    Principal = $identity
                    AccessControlInformation = @(
                        cNtfsAccessControlInformation
                        {
                            AccessControlType = 'Allow'
                            FileSystemRights = 'Modify'
                            Inheritance = 'ThisFolderSubfoldersAndFiles'
                            NoPropagateInherit = $false
                        }
                        cNtfsAccessControlInformation
                        {
                            AccessControlType = 'Allow'
                            FileSystemRights = 'ReadAndExecute'
                            Inheritance = 'ThisFolderSubfoldersAndFiles'
                            NoPropagateInherit = $false
                        }
                    )
                    DependsOn = "[File]$poolname"
                }
            }

        }

        #create each app pool with particular properties
        foreach($pool in $appPools) {
            $poolName = $pool.AppPool
            xWebAppPool "$poolName-Configure" {
                Name = $pool.AppPool
                Ensure = "Present"
                State = "Started"
                autoStart = $true
                queueLength = 4000
                maxProcesses = 2
                restartSchedule = "00:00:00"
                enable32BitAppOnWin64 = $true
            }
        }

        #delete each app pool in defaultapppools
        foreach($pool in $defaultAppPools) {
            xWebAppPool "$pool-Delete" {
                Name = $pool
                Ensure = "Absent"
            }
        }
    }
}

ManageApplicationPools-API-Dev -OutputPath C:\dsc-mof\ManageApplicationPools-API-Dev
#Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\ManageApplicationPools-API-Dev -Wait -ErrorAction Stop -Force -Verbose