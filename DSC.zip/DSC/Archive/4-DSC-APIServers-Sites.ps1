########
# Author:       Matt Keller
# Description:  Powershell DSC to configure APP Pools & Sites in IIS for API Servers to be used in conjunction with other API Server DSC
# Changes:      04/11/2018      Initial creation
#               
########

##########
#ASSUMPTION: You are copying this script out to the server then executing it from there
##########

Set-ExecutionPolicy Unrestricted

#stealing from the app pool config so we can generate sites off of the name easily
#removed the following because we dont need to create a webapp for it but we do need the app pool (the base site runs on this app pool)
#@{ AppPool = "DVINApi"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
$appPools = @(
        @{ AppPool = "AddressValidation"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "DVAuth"; AppPoolIdentity = "world\svcdvhauthdev" }
        @{ AppPool = "lbmonitor"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "EarlyWarning"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "EquifaxMock.api"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "Finicity"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "FNMAApi"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "UDM"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "VOEI"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
        @{ AppPool = "IV"; AppPoolIdentity = "world\svc_dvinwebapi_d" }
    )

#$siteipbinding 

#copied from the app pool config, just change the name
Configuration ManageSites-API-Dev {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration

    #copy from app pool config also to setup this node/machine
    Node $env:computername {

        #setup each site
        #specify the base site name, destination and app pool names you want (make sure the app pool is still setup in step 3)
        $sitename = "Internal API"
        $sitedestination = "C:\www\"
        $basesiteapppool = "DVINApi"
        #using an existing cert created during OSD, which is what the api dev servers currently use
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My -DnsName "$env:computername.cbc.local" -eku "Server Authentication*"
        xWebsite $sitename
        {
            Ensure          = "Present"
            Name            = $sitename
            State           = "Started"
            PreloadEnabled  = $true
            PhysicalPath    = $sitedestination
            ApplicationPool = $basesiteapppool
            BindingInfo = 
                        @(
                            MSFT_xWebBindingInformation 
                            {
                                Protocol = "https"
                                Port = "443"
                                IPAddress = "*"
                                CertificateThumbprint = $cert.thumbprint
                                CertificateStoreName  = "My"
                            }
                            MSFT_xWebBindingInformation 
                            {
                                Protocol = "http"
                                Port = "4080"
                                IPAddress = "*"
                            }
                        )
        }

        foreach($webapp in $appPools)
        {
            #grab the correct name from the apppool array above & set a unique destination for each
            $webappname = $webapp.AppPool
            $webappdestination = $sitedestination + $webappname
            xWebApplication $webappname
            {
                Website = $sitename
                Ensure = "Present"
                Name = $webappname
                PhysicalPath = $webappdestination
                WebAppPool = $webappname
                AuthenticationInfo = MSFT_xWebApplicationAuthenticationInformation
                {
                    Anonymous = $true
                    Basic     = $false
                    Digest    = $false
                    Windows   = $false
                }
                PreloadEnabled = $true
                EnabledProtocols = @("http")

                DependsOn = "[xWebsite]$sitename"
            }
        }

        #C:\inetpub\wwwroot
        # Stop the default website then remove it
        xWebsite DefaultWebSite 
        {
            State           = "Stopped"
            Ensure          = "Absent"
            Name            = "Default Web Site"
            PhysicalPath    = "C:\inetpub\wwwroot"
        }


    }

}

ManageSites-API-Dev -OutputPath C:\dsc-mof\ManageSites-API-Dev
#Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\ManageSites-API-Dev -Wait -ErrorAction Stop -Force -Verbose