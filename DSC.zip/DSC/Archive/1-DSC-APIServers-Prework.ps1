########
# Author:               Matt Keller
# Description:          Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:              04/2/2018      Initial creation
# Future Enhancements:  Add a way to read which modules you want to install from text file then install them
########
# make sure you are running this under your .cbc account
# $destPSModulepath should construct to = either c:\program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules


$computers = Get-Content -Path "C:\SVN\WindowsAdmins\DSC\Test\computers.txt"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"
    $regfilepath = $localpath + "\configure_ssl_and_tls.reg"
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"
    $destfilepath1 = $destpath + "\3-DSC-APIServers-appPools.ps1"
    $destfilepath2 = $destpath + "\2-DSC-APIServers-Features.ps1"
    $destfilepath3 = $destpath + "\4-DSC-APIServers-Sites.ps1"
    $localdscscriptpath1 = "C:\SVN\WindowsAdmins\DSC\Test\3-DSC-APIServers-appPools.ps1"
    $localdscscriptpath2 = "C:\SVN\WindowsAdmins\DSC\Test\2-DSC-APIServers-Features.ps1"
    $localdscscriptpath3 = "C:\SVN\WindowsAdmins\DSC\Test\4-DSC-APIServers-sites.ps1"
    $regfilepath = "\\fs\cbc\dept\windows\build_scripts\configure_ssl_and_tls.reg"

    #cert paths. dont forget to specify below which cert store you're using. Here is a useful mapping for where they go
    #https://stackoverflow.com/questions/40440958/does-anybody-know-how-the-powershell-certificate-provider-paths-map-to-certmgr-m
    $cert1path = "\\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte_primary_root_ca.cer"
    $cert2path = "\\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte EV SSL CA - G3.cer"

    $dynatracesource = "\\cbcnas04\shared\dynaTrace\Dynatrace 7\WIndows\Client\dynatrace-client-7.0.0.2469-x86-64.msi"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        <# Select the master branch and download the zip of the repository from something like: https://github.com/PowerShell/xTimeZone/tree/master
        Extract the zip file to a folder.
        Rename the folder if you need to xTimeZone for example
        Copy xTimeZone to C:\Program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules
        Verify you can discover the DSCResource:
            Get-DscResource
        #>

        #check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }

        #copy DSC script out to hosts
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath2 -Destination $destfilepath2 -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath3 -Destination $destfilepath3 -ErrorAction Stop
            echo "DSC script copies okay on $target"
            }

        Catch {
                echo "failed copying DSC scripts on $target"
                break
                }

        #You need to look at your DSC and see what modules & dsc resources it uses. Copy them to the Powershell Modules folder.
        Try {
            Copy-Item -Path "C:\SVN\WindowsAdmins\DSC\Modules\xWebAdministration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xWebAdministration module copy okay on $target"

            Copy-Item -Path "C:\SVN\WindowsAdmins\DSC\Modules\cNtfsAccessControl" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "cNtfsAccessControl module copy okay on $target"
            #more copies
            #more echoes
            }

        Catch {
                echo "copy of DSC modules to powershell directory failed on $target"
                break
                }

        #copy .reg file
        Try {
            Copy-Item -Path $regfilepath -Destination $destpath -ErrorAction Stop
            echo ".reg file copy okay on $target"
        }

        Catch {
                echo ".reg file copy failed on $target"
                break
        }

        #execute .reg file
        #invoke command on $target passing a scriptblock to execute start-process of regedit.exe with $p2 parameter where $p2 is $regfilepath which is just a .reg file we copied to c:\scripts
        Try {
             Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath "c:\windows\regedit.exe" $p2 } -ArgumentList "$regfilepath" -ErrorAction Stop
             echo ".reg file execution okay on $target"
             }

        Catch {
                echo ".reg file execution failed on $target"
                break
              }

        #install dynatrace via silent install using the path you specified above
        <#
        Try 
        {
            msiexec $dynatracesource SERVER="https://someserver.com" TENANT="xxx" TENANT_TOKEN="xxx" INSTALL_PATH="c:\test dir" /quiet /qn
            echo "dynatrace install okay on $target"
        }
        Catch
        {
            echo "dynatrace install failed on $target"
            break
        }
        #>

        #install required certs $cert1,2,3 etc specify the path above and cert store location below
        Try 
        {
            #Third Party Root CA
            $cert1 = Get-ChildItem -Path $cert1path
            #intermediate CA (works with the root)
            $cert2 = Get-ChildItem -Path $cert2path

            #authroot = Third Part Root CA
            $cert1 | Import-Certificate -CertStoreLocation Cert:\LocalMachine\AuthRoot
            #CA = Intermediate CA
            $cert2 | Import-Certificate -CertStoreLocation Cert:\LocalMachine\CA

            echo "cert imports okay on $target"
        }
        Catch
            {
                echo "cert import failed on $target"
                break
            }
        
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
}
