########
# Author:       Will Goshen
# Description:  This script uses Powershell DSC to enforce Module configuration for DataVerify IIS servers
# Changes:      07/17/2017      Initial creation
#               02/05/2018      Added DVAuth App Pool
#               02/07/2017      Edited script to pull password from protected keystore
#                               $appPools is now an array of objects to allow for specific App Pool properties
########

Set-ExecutionPolicy Unrestricted

$application = "@node.application@"
$hostname = "@node.hostname@"

if ($application -eq "Api") {
    $appPools = @(
        @{ AppPool = "AddressValidation"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "DVAuth"; AppPoolIdentity = "world\svcdvhauthdev"; Password = "@option.svcdvhauthdev@" }
        @{ AppPool = "DVINApi"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "lbmonitor"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "EarlyWarning"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "EquifaxMock.api"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "Finicity"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "FNMAApi"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "UDM"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "VOEI"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "IV"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
    )
}
else {
    Write-Error("Invalid application value. Now exiting")
    exit 1
}
$defaultAppPools = @(
    "DefaultAppPool"
)
$disabledAppPools = @(
    "NET v4.5",
    "NET v4.5 Classic"
)

Configuration ManageApplicationPools {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    
    Node $hostname {
        foreach($pool in $appPools) {
            $poolName = $pool.AppPool
            xWebAppPool "$poolName-Configure" {
                Name = $pool.AppPool
                Ensure = "Present"
                State = "Started"
                autoStart = $true
                queueLength = 4000
                maxProcesses = 2
                restartSchedule = "00:00:00"
                enable32BitAppOnWin64 = $true
            }
        }
        foreach($pool in $defaultAppPools) {
            xWebAppPool "$pool-Delete" {
                Name = $pool
                Ensure = "Absent"
            }
        }
    }
}

ManageApplicationPools -OutputPath C:\dsc-mof\ManageApplicationPools
Start-DscConfiguration -ComputerName $hostname -Path C:\dsc-mof\ManageApplicationPools -Wait -ErrorAction Stop -Force -Verbose

foreach($pool in $appPools) {
    $poolName = $pool.AppPool
    Set-ItemProperty "IIS:\AppPools\$poolName" -Name processModel -Value @{ userName=$pool.AppPoolIdentity; password=$pool.Password; identitytype=3 }
}