﻿#hello

    Function New-ProxyWebServiceProxy {
    [CmdletBinding(DefaultParameterSetName='NoCredentials', HelpUri='http://go.microsoft.com/fwlink/?LinkID=135238')]
    Param (
        [Parameter(Mandatory=$true, Position=0)]
        [Alias('WL','WSDL','Path')]
        [ValidateNotNullOrEmpty()]
        [uri]
        ${Uri},

        [Parameter(ParameterSetName='Credential')]
        [Alias('Cred')]
        [ValidateNotNullOrEmpty()]
        [pscredential]
        [System.Management.Automation.CredentialAttribute()]
        ${Credential},

        [Alias('Cert')]
        [ValidateNotNullOrEmpty()]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]
        ${Certificate},

        [Parameter(Position=1)]
        [Alias('FileName','FN')]
        [ValidateNotNullOrEmpty()]
        [string]
        ${Class},

        [Parameter(Position=2)]
        [Alias('NS')]
        [ValidateNotNullOrEmpty()]
        [string]
        ${Namespace},

        [Parameter(ParameterSetName='UseDefaultCredential')]
        [Alias('UDC')]
        [ValidateNotNull()]
        [switch]
        ${UseDefaultCredential}
    )
    Begin {
        Try {
            $outBuffer = $null
            If ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
                $PSBoundParameters['OutBuffer'] = 1
            }

            If ($Certificate) {
                $TempFile = [System.IO.Path]::GetTempFileName() + "_wsdl.xml"

                $WebRequest = @{
                    "Certificate" = $Certificate
                    "URI" = $URI
                }

                If ($Credential) {
                    $WebRequest.Credential = $Credential
                    #$WebRequest.ProxyCredential = $Credential
                } ElseIf ($UseDefaultCredential) {
                    $WebRequest.UseDefaultCredentials = $True
                    #$WebRequest.ProxyUseDefaultCredentials = $True
                }

                $Response = Invoke-WebRequest @WebRequest
                $Content = [XML]$Response.Content
                $FirstChild = $Content.FirstChild

                If ($FirstChild.Name -eq "xml") {
                    $Content.RemoveChild($FirstChild) | Out-Null
                }

                $Content.OuterXml | Out-File -FilePath $TempFile
                $PSBoundParameters.Uri = "file://" + $TempFile
            }

            $PSBoundParameters.Remove("Certificate") | Out-Null

            $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand('New-WebServiceProxy', [System.Management.Automation.CommandTypes]::Cmdlet)
            $scriptCmd = {& $wrappedCmd @PSBoundParameters }
            $steppablePipeline = $scriptCmd.GetSteppablePipeline($myInvocation.CommandOrigin)
            $steppablePipeline.Begin($PSCmdlet)
        } Catch {
            Throw $_
        }
    }
    Process {
        Try {
            $Proxy = New-WebServiceProxy @PSBoundParameters
            $Proxy.ClientCertificates.Add($Certificate) | Out-Null
            $Proxy
        } Catch {
            Throw $_
        }
    }
    End {
        Try {
            If ($TempFile) {
                Remove-Item $TempFile
            }
        } Catch {
            Throw
        }
    }
    <#
    .ForwardHelpTargetName New-WebServiceProxy
    .ForwardHelpCategory Cmdlet
    #>
}

    #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    #[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls11
    #$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
    #[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

    #$cert = dir Cert:\LocalMachine\My | where {$_.Subject -eq 'CN = secretserver' }
    $cert = Get-ChildItem Cert:\LocalMachine\My -DnsName "secretserver"
    $url = 'https://ss01uwap/webservices/sswebservice.asmx'
    $username = 'svcsccmosdzti'
    $password = ConvertTo-SecureString "pDBJCTU6evVDMwUjRwZy" -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential ($username, $password)
    $domain = 'world'   # leave blank for local users
    $proxy = New-ProxyWebServiceProxy -uri $url -Certificate $cert -Credential $credential
    #$proxy = New-WebServiceProxy -Uri $url -Credential $credential
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    $secretid = 8352

    
	
    if ($result1.Errors.length -gt 0){
        $result1.Errors[0]
        exit
        } 
    else 
        {
            $token = $result1.Token
        }
    $result2 = $proxy.GetSecret($token, $secretId, $false, $null)

    $result2