﻿########
# Author:       Will Goshen
# Description:  This script uses Powershell DSC to enforce Module configuration for DataVerify IIS servers
# Changes:      07/17/2017      Initial creation
#               02/05/2018      Added DVAuth App Pool
#               02/07/2017      Edited script to pull password from protected keystore
#                               $appPools is now an array of objects to allow for specific App Pool properties
########

########
# brainstorm - how often does the config run? are we enforcing config? do we want removal of any extraneous sites/pools/anything not in config?
# idea - remove all sites, remove all apppools then recreate everything from scratch if you want strict enforcement
# cont - otherwise just ensure that everything exists - will create small configuration drift over time.
# brainstorm - can we create a powershell module repository for all the nodes to connect to and install the modules required?
# brainstorm - push or pull method? Or DSC Feature "Push to Pull?"
# will need to make sure LCM is configured correctly on all hosts as well
# PLAN - setup DSC Push server, install source control there, install all required modules there, push all scripts & powershell modules from there
#
# TODO: 
# 00) need test section to copy script out to confmgmt01uwad or confmgmt02uwad
# 0) need a section where we copy the powershell modules and install them correctly
# 1) how do we handle credentials - can we pull from Keepass? Is there an API?
# 2) iterate/setup site folder structure & permissions correctly
# 3) setup c:\app, c:\app\conf, c:\app\log
# 4) get DVConfig and put it in c:\app\conf
# 5) run the ssl&tls .reg setup
# 6) Install IIS role
# 7) IIS Role Services = Application Development, .NET Extensibility 4.5/4.6, Application Initialization, ASP.NET 4.5/4.6, ISAPI Extensions, ISAPI Filters
# 8) install dynatrace from \\cbcnas04\shared\dynatrace
# 9) Install Feature = .net 4.6 &/or asp.net 4.6 (4.5 seems to come on 2012 so may need handling for 2012 vs 2016 servers)
# 10) setup dynatrace server collector - address dvdtcol01uwap port 9998 (or get info from Malik)
# 11) Install Thawte Root & Intermediate Certificates - \\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte_primary_root_ca & thawte EV SSL CA - G3
# 12) whatever service account used for the app pool needs access to \\dfs\nas\dv_shared\webapp deploy\ssl_certs
#
##########

####
#ASSUMPTION: You are copying this script out to the server then executing it from there
####

#$hostname = $env:computername
#$application = "@node.application@"

Set-ExecutionPolicy Unrestricted

<#
if ($application -eq "Api") {
    $appPools = @(
        @{ AppPool = "AddressValidation"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "DVAuth"; AppPoolIdentity = "world\svcdvhauthdev"; Password = "@option.svcdvhauthdev@" }
        @{ AppPool = "DVINApi"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "lbmonitor"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "EarlyWarning"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "EquifaxMock.api"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "Finicity"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "FNMAApi"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "UDM"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "VOEI"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
        @{ AppPool = "IV"; AppPoolIdentity = "world\svc_dvinwebapi_d"; Password = "@option.svc_dvinwebapi_d@" }
    )
}
else {
    Write-Error("Invalid application value. Now exiting")
    exit 1
}
#>

$appPools = @(
    @{ AppPool = "AddressValidation" }
    @{ AppPool = "DVAuth" }
    @{ AppPool = "DVINApi" }
    @{ AppPool = "lbmonitor" }
    @{ AppPool = "EarlyWarning" }
    @{ AppPool = "EquifaxMock.api" }
    @{ AppPool = "Finicity" }
    @{ AppPool = "FNMAApi" }
    @{ AppPool = "UDM" }
    @{ AppPool = "VOEI" }
    @{ AppPool = "IV" }
    )


$defaultAppPools = @(
    "DefaultAppPool"
)

<# unused for now
#
#$disabledAppPools = @(
#    "NET v4.5",
#    "NET v4.5 Classic"
#)
#>



#setup c:\app, c:\app\conf, c:\app\log

#get DVConfig and put it in c:\app\conf

#run the ssl&tls .reg setup

#Install IIS role & 
#IIS Role Services = Application Development, .NET Extensibility 4.5/4.6, Application Initialization, ASP.NET 4.5/4.6, ISAPI Extensions, ISAPI Filters
#Install Feature = .net 4.6 &/or asp.net 4.6 (4.5 seems to come on 2012 so may need handling for 2012 vs 2016 servers)

#install dynatrace from \\cbcnas04\shared\dynatrace
#setup dynatrace server collector - address dvdtcol01uwap port 9998 (or get info from Malik)

#Install Thawte Root & Intermediate Certificates - \\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte_primary_root_ca & thawte EV SSL CA - G3

#ensure app pool service account access to - \\dfs\nas\dv_shared\webapp deploy\ssl_certs

Configuration ManageApplicationPools-API-Dev {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    
    Node $env:computername {

        #setup site folder structure & permissions
        foreach($pool in $appPools) {
            

        foreach($pool in $appPools) {
            $poolName = $pool.AppPool
            xWebAppPool "$poolName-Configure" {
                Name = $pool.AppPool
                Ensure = "Present"
                State = "Started"
                autoStart = $true
                queueLength = 4000
                maxProcesses = 2
                restartSchedule = "00:00:00"
                enable32BitAppOnWin64 = $true
            }
        }
        foreach($pool in $defaultAppPools) {
            xWebAppPool "$pool-Delete" {
                Name = $pool
                Ensure = "Absent"
            }
        }
    }
}

ManageApplicationPools -OutputPath C:\dsc-mof\ManageApplicationPools
Start-DscConfiguration -ComputerName $hostname -Path C:\dsc-mof\ManageApplicationPools -Wait -ErrorAction Stop -Force -Verbose

foreach($pool in $appPools) {
    $poolName = $pool.AppPool
    Set-ItemProperty "IIS:\AppPools\$poolName" -Name processModel -Value @{ userName=$pool.AppPoolIdentity; password=$pool.Password; identitytype=3 }
}