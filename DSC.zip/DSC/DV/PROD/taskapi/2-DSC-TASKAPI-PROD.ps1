#########
# Author:       Matt Keller
# Description:  Powershell DSC to configure Windows Features & setup files/folders for API Servers to be used in conjunction with other API Server DSC
# Changes:      03/28/2018      Initial creation
#               05/2/2018       change everything over for use with Web Servers
#               05/22/2018      added ISAPI restrctions
#               06/05/2018      added SessionStateTimeout & DeleteXPoweredByHTTPResponseHeader
#               06/18/2018      remove restartschedule timespan array (not what we needed) add script resource to handle PeriodRestart time property
#               06/18/2018      update LCM config to ApplyAndMonitor & remove DVConfig file resource & add scheduled task to run script on regular interval
#               06/28/2018      change over to dvad01uwwd
#               09/14/2018      add app pool and site etc for CLAS-API
#               10/22/2018      move ISAPI clear-webconfiguration call to above/outside configuration keyword
#                               add Dynatrace install to script 1
#                               remove dvconfig.xml deploy
#                               fix lbmonitor deploy location
#               10/31/2018      share AppLogs
#                               add creation of C:\app\certs
#                               make sure tasks are setup correctly
#               03/08/2019      change over to taskapi
#               04/08/2019      added in Dynatrace install
#                               change over to DataverifyAPI name
#               04/11/2019      troubleshooting deploy to Lab - fixing lbmonitor and base site creation
#               05/07/2019      add DataVerify.Task.Broker.API web application as webapp under base DataverifyAPI site
#               05/23/2019      change over to INTGW server
#               06/17/2019      add section for removal of x-powered-by http response header
#               08/14/2019      Replaced periodicRestart script resource with restartTimeLimit property
#                               Debugged/Fixed X-Powered By script resource
#                               Cleaned up old comments
#                               Added variables for SMBshare access
#
#########
#########
#ASSUMPTION: You are copying this script out to the server then executing it from there
#########

Set-ExecutionPolicy Unrestricted -Force

#variable that holds our config name since we'll be calling it up here and then all the way at the bottom.
$DSCconfigName = "DSC-TASKAPI-PROD"
# these are used for access to the shares
$SMBshareReadAccess = "world\dv.serverlog.prod"
$SMBshareChangeAccess = "world\dv.serverconf.prod"

#these are all the pools we'll be creating
$appPools = @(
        @{ AppPool = "Dataverify"; AppPoolIdentity = "world\dvservice" }
        @{ AppPool = "DataverifyTaskAPI"; AppPoolIdentity = "world\dvservice" }
    )

#these are all the default pools we'll be deleting
$defaultAppPools = @(
		"DefaultAppPool",
		".NET v4.5",
		".NET v4.5 Classic"
	)

##THIS IS TO FIX ISAPI FIRST RUN PROBLEM
#clear the current ISAPI configs so we can set new ones when the config runs
#Clear-WebConfiguration -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.webServer/security/isapiCgiRestriction'

#create our configuration with the "Configuration" keyword. Now lets use that variable we created above.
#note the resources we're importing here. they must be included in the 1st scripts copy job
#also note the webadministration module. this should be installed by default on 2012 & up servers but not 2008 R2 etc.

Configuration $DSCconfigName {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName cNtfsAccessControl
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName ComputerManagementDsc											

    Node $env:computername {

        #disclaimer
        #do not reorder these sections, they build off one another

        ########
        #region Basic File & Folder section. Permissions???
        ########

        $path1 = "c:\app"
        $path2 = "c:\app\conf"
        $path3 = "c:\app\log"
        $path4 = "c:\www"
        $path5 = "c:\inetpub\logs"

        File appDir #setup c:\app
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path1
        }

        File confDir #c:\app\conf
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path2
            DependsOn = "[File]appDir"
        }

        File logDir #c:\app\log
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path3
            DependsOn = "[File]appDir"
        }

        File wwwDir #c:\www
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $path4
        }

        #endregion

        ########
        #region SMBShare creation
        ########

        xSmbShare appConfShare
        {
            Ensure = "Present"
            Name   = "AppConf"
            Path = $path2
            ChangeAccess = $SMBshareChangeAccess
            Description = "App Conf share"
        }
        
        xSmbShare appLogShare
        {
            Ensure = "Present"
            Name   = "AppLog"
            Path = $path3
            ReadAccess = $SMBshareReadAccess
            Description = "App Log share"
        }        

        xSmbShare IISLogShare
        {
            Ensure = "Present"
            Name   = "IISLogs"
            Path = $path5
            ReadAccess = $SMBshareReadAccess
            Description = "IIS Log share"
        }

        #endregion

        ########
        #region Windows Roles & Features section. These should all be relatively in order based on how they appear when you do a get-windowsfeature -name *web*
        ########

        WindowsFeature Web-Server  # Web Server (IIS) base/root feature
        {
               Name = "Web-Server"
               Ensure = "Present"
        }

        WindowsFeature Web-WebServer  # Web Server continued (IIS) parent featureset
        {
               Name = "Web-WebServer"
               Ensure = "Present"
        }

        WindowsFeature Web-Common-Http  # Common Http Features parent featureset
        {
               Name = "Web-Common-Http"
               Ensure = "Present"
        }

        WindowsFeature Web-Default-Doc  # Default Document
        {
               Name = "Web-Default-Doc"
               Ensure = "Present"
        }

        WindowsFeature Web-Dir-Browsing  # Directory Browsing
        {
               Name = "Web-Dir-Browsing"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Errors  # Http Errors
        {
               Name = "Web-Http-Errors"
               Ensure = "Present"
        }

        WindowsFeature Web-Static-Content  # Static Content
        {
               Name = "Web-Static-Content"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Redirect  # Http redirection
        {
               Name = "Web-Http-Redirect"
               Ensure = "Present"
        }

        WindowsFeature Web-Health # Health and Diagnostics parent featureset
        {
               Name = "Web-Health"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Logging # Http Logging
        {
               Name = "Web-Http-Logging"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Tracing  # Tracing
        {
               Name = "Web-Http-Tracing"
               Ensure = "Present"
        }

        WindowsFeature Web-Performance  # Performance parent featureset
        {
               Name = "Web-Performance"
               Ensure = "Present"
        }

        WindowsFeature Web-Stat-Compression  # Static Content Compression
        {
               Name = "Web-Stat-Compression"
               Ensure = "Present"
        }

        WindowsFeature Web-Security  # Security parent featureset
        {
               Name = "Web-Security"
               Ensure = "Present"
        }

        WindowsFeature Web-Filtering  # Request Filtering
        {
               Name = "Web-Filtering"
               Ensure = "Present"
        }

        WindowsFeature Web-App-Dev  # Application Development parent featureset
        {
               Name = "Web-App-Dev"
               Ensure = "Present"
        }

        WindowsFeature Web-Net-Ext45  # .NET Extensibility 4.5
        {
             Name = "Web-Net-Ext"
             Ensure = "Present"
        }

        WindowsFeature Web-AppInit  # Application Initialization
        {
             Name = "Web-AppInit"
             Ensure = "Present"
        }

        WindowsFeature Web-Asp-Net45  # ASP.NET 4.5
        {
             Name = "Web-Asp-Net45"
             Ensure = "Present"
        }

        WindowsFeature Web-ISAPI-Ext  # ISAPI Extensions
        {
             Name = "Web-ISAPI-Ext"
             Ensure = "Present"
        }

        WindowsFeature Web-ISAPI-Filter  # ISAPI Filters
        {
             Name = "Web-ISAPI-Filter"
             Ensure = "Present"
        }

        WindowsFeature Web-Mgmt-Tools  # Management Tools parent featureset
        {
             Name = "Web-Mgmt-Tools"
             Ensure = "Present"
        }

        WindowsFeature Web-Mgmt-Console  # IIS Management Console
        {
             Name = "Web-Mgmt-Console"
             Ensure = "Present"
        }

        #endregion
        
        ########
        #region NON IIS Windows Features section
        ########
        WindowsFeature Net-Framework-Features  # .Net Framework 3.5 Features parent featureset
        {
             Name = "Net-Framework-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-Core  # .Net Framework 3.5 (.NET 2.0 and 3.0)
        {
             Name = "Net-Framework-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Features  # .Net Framework 4.5 Features parent featureset
        {
             Name = "Net-Framework-45-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Core  # .Net Framework 4.5
        {
             Name = "Net-Framework-45-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-ASPNET  # ASP.NET 4.5
        {
             Name = "Net-Framework-45-ASPNET"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-Services45  # WCF Services
        {
             Name = "Net-WCF-Services45"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-TCP-PortSharing45  # TCP Port Sharing
        {
             Name = "Net-Framework-Core"
             Ensure = "Present"
        }

        WindowsFeature RDC #Remote Differential Compression
        {
             Name = "RDC"
             Ensure = "Present"
        }

        WindowsFeature SNMP-Service #SNMP Service Parent
        {
            Name = "SNMP-Service"
            Ensure = "Present"
        }

        WindowsFeature Telnet-Client #Telnet Client
        {
            Name = "Telnet-Client"
            Ensure = "Present"
        }

        WindowsFeature PowershellRoot #Windows Powershell parent featureset
        {
            Name = "PowershellRoot"
            Ensure = "Present"
        }

        WindowsFeature Powershell #Windows Powershell
        {
            Name = "Powershell"
            Ensure = "Present"
        }

        WindowsFeature Powershell-ISE #Powershell ISE
        {
            Name = "Powershell-ISE"
            Ensure = "Present"
        }

        #endregion

        ########
        #region App Pool creation section
        ########

        #setup site folder structure & permissions
        foreach($pool in $appPools)
        {
            #if the app pool name equals Dataverify then create the base folder
            If( $pool.appPool -eq "DataVerify")
            {
                $poolName = $pool.AppPool
                $permissionname = $poolname + "permissions"
                $identity = $pool.AppPoolIdentity

                File $poolName #setup site directory
                {
                    Ensure = "Present"  # You can also set Ensure to "Absent"
                    Type = "Directory" # Default is "File".
                    DestinationPath = "C:\www\$poolName"
                }
			}
            #else if the app pool name does not equal Dataverify, create a subfolder within the base folder
            Else
            {
                $poolName = $pool.AppPool
                $permissionname = $poolname + "permissions"
                $identity = $pool.AppPoolIdentity

                File $poolName #setup site directory
                {
                    Ensure = "Present"  # You can also set Ensure to "Absent"
                    Type = "Directory" # Default is "File".
                    DestinationPath = "C:\www\DataVerify\$poolName"
                }
            }
        }

        #create each app pool with particular properties
        foreach($pool in $appPools) {
            $poolName = $pool.AppPool
            xWebAppPool "$poolName-Configure" {
                Name = $pool.AppPool
                Ensure = "Present"
                State = "Started"
                autoStart = $true
                queueLength = 4000
                maxProcesses = 2
                enable32BitAppOnWin64 = $true
				restartTimeLimit = "00:00:00"
                restartSchedule = ""							
            }

        #end foreach
        }

        #delete each app pool in defaultapppools
        foreach($pool in $defaultAppPools) {
            xWebAppPool "$pool-Delete" {
                Name = $pool
                Ensure = "Absent"
            }
        }

        #endregion

        ########
        #region Site creation section
        ########

        #setup each site
        #specify the base site name, destination and app pool names you want (make sure the app pool is still setup with app pool section)
        $sitename = "Dataverify"
        $sitedestination = "C:\www\Dataverify"
        $basesiteapppool = "Dataverify"
        #using an existing cert created during OSD
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My -DnsName "$env:computername.cbc.local" -eku "Server Authentication*"
        xWebsite $sitename
        {
            Ensure          = "Present"
            Name            = $sitename
            State           = "Started"
            PreloadEnabled  = $true
            PhysicalPath    = $sitedestination
            ApplicationPool = $basesiteapppool
            BindingInfo = 
                        @(
                            MSFT_xWebBindingInformation 
                            {
                                Protocol = "https"
                                Port = "443"
                                IPAddress = "*"
                                CertificateThumbprint = $cert.thumbprint
                                CertificateStoreName  = "My"
                            }
                            # For HTTP
                            <# MSFT_xWebBindingInformation 
                            {
                                Protocol = "http"
                                Port = "4080"
                                IPAddress = "*"
                            }
                            #>
                        )
        }

        foreach($webapp in $appPools){
            
            If( $webapp.appPool -ne "Dataverify")
            {                                                                                
                #grab the correct name from the apppool array above & set a unique destination for each
                $webappname = $webapp.AppPool
                $webappdestination = $sitedestination + "\" + $webappname
                xWebApplication $webappname
                {
                    Website = $sitename
                    Ensure = "Present"
                    Name = $webappname
                    PhysicalPath = $webappdestination
                    WebAppPool = $webappname
                    AuthenticationInfo = MSFT_xWebApplicationAuthenticationInformation
                    {
                        Anonymous = $true
                        Basic     = $false
                        Digest    = $false
                        Windows   = $false
                    }
                    PreloadEnabled = $true
                    EnabledProtocols = @("http")

                    DependsOn = "[xWebsite]$sitename"
                }
            }
        }

        #C:\inetpub\wwwroot
        # Stop the default website then remove it
        xWebsite DefaultWebSite 
        {
            State           = "Stopped"
            Ensure          = "Absent"
            Name            = "Default Web Site"
            PhysicalPath    = "C:\inetpub\wwwroot"
        }

        #endregion

        ########
        #region HTTP Response Headers
        ########

        Script DeleteXPoweredByHttpResponseHeader {

            #get the http response web configuration property. store the value in a hashtable with key "Result"
            GetScript = {
                $HTTPResponseHeader = Get-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST/Dataverify' -filter "system.webServer/httpProtocol/customHeaders/add[@name='X-Powered-By']" -name "."
                $HTTPResponseHeaderName = $HTTPResponseHeader.name
                @{ "Result" = $HTTPResponseHeaderName }
            }

            #use GetScript and check the "Result" key/value pair. If the value equals "" (an empty string), return true. Else return false which
            #will trigger the running of SetScript
            TestScript = {
                $HTTPResponseHeader = Get-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST/Dataverify' -filter "system.webServer/httpProtocol/customHeaders/add[@name='X-Powered-By']" -name "."
                $HTTPResponseHeaderName = $HTTPResponseHeader.name
                if( $HTTPResponseHeaderName -eq "X-Powered-By")
                {
                    Write-Verbose -Message "X-Powered-By header exists, running SetScript"
                    return $false
                }
                else
                {
                    Write-Verbose -Message "X-Powered-By header does not exist. No action is required."
                    return $true
                }
            }

            #if TestScript returns $false, remove the web configuration property that matches name "X-Powered-By"
            SetScript = {
                Remove-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST/Dataverify' -filter "system.webServer/httpProtocol/customHeaders" -name "." -AtElement @{name='X-Powered-By'}
            }
        }
        #endregion
        
        <#
        ########
        #region lbmonitor page deploy
        ########
        $lbmonitorsourcepath = "\\dfs\nas\DV_Shared\WebApp Deploy\lbmonitor"
        $lbmonitordestpath = "C:\www"

        #copy from share path to local site dir. keep in mind we want to keep permissions in tact and not overwrite permissions.
        #may have to copy file by file
        Copy-Item -Path $lbmonitorsourcepath -Recurse -Force -Destination $lbmonitordestpath -ErrorAction Stop
		
        #endregion			

        #>
        ###end skip lbmonitor deploy

        <#########
        #region Isapi Restrictions
        ########
        ########
        #made a decision here not to include asp.net 2.0 entries into ISAPI/CGI
        #i doubt the code still uses ASP 2.0
        #also i was not able to find c:\windows\system32\inetsrv\asp.dll so i excluded that as well
        ########

        ########
        #See the technet article on how Script resources are used to get an understanding of get, set and test scripts here
        ########

        #clear the current ISAPI configs so we can set new ones
        Clear-WebConfiguration -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.webServer/security/isapiCgiRestriction'

        Script IsapiRestriction1 {
              GetScript = {
                $frameworkPath = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\aspnet_isapi.dll"
                #$isapiConfiguration = Get-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed"
                @{ Result = Get-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed" }
              }

              SetScript = {
                $frameworkPath = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\aspnet_isapi.dll"
                Add-WebConfiguration -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.webServer/security/isapiCgiRestriction' -value @{
                  description = 'ASP.NET v4.0.30319'
                  path        = $frameworkPath
                  allowed     = 'True'
                }

                Set-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed" -value 'True' -PSPath:IIS:\
              }

              TestScript = {
                $frameworkPath = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\aspnet_isapi.dll"
                $isapiConfiguration = Get-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed"
                ($isapiConfiguration.value -ne $null)
              }
            }

        Script IsapiRestriction2 {
              GetScript = {
                $frameworkPath = "$env:windir\Microsoft.NET\Framework\v4.0.30319\aspnet_isapi.dll"
                @{ Result = Get-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed" }
              }

              SetScript = {
                $frameworkPath = "$env:windir\Microsoft.NET\Framework\v4.0.30319\aspnet_isapi.dll"
                Add-WebConfiguration -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.webServer/security/isapiCgiRestriction' -value @{
                  description = 'ASP.NET v4.0.30319'
                  path        = $frameworkPath
                  allowed     = 'True'
                }

                Set-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed" -value 'True' -PSPath:IIS:\
              }

              TestScript = {
                $frameworkPath = "$env:windir\Microsoft.NET\Framework\v4.0.30319\aspnet_isapi.dll"
                $isapiConfiguration = Get-WebConfiguration "/system.webServer/security/isapiCgiRestriction/add[@path='$frameworkPath']/@allowed"
                ($isapiConfiguration.value -ne $null)
              }
            }

        #endregion	
        
        #>	
        ###end skip ISAPI restrictions setup	

		########
        #region Local Configuration Manager
        ########

        #all the settings we want for the Local Configuration Manager (LCM)
        #24hrs in a day X 60mins an hour = 1440mins
        LocalConfigurationManager
        {
            ConfigurationModeFrequencyMins = 1440
            ConfigurationMode = "ApplyAndMonitor"
            RefreshMode = "Push"
            RebootNodeIfNeeded = $false
            AllowModuleOverwrite = $true
        }

        #endregion
		
        ########
        #region TASKS
        ########
        #commenting this out for now
        <#

        #Please see the wealth of examples on https://github.com/PowerShell/ComputerManagementDsc/wiki/ScheduledTask
        ########

        ####remove all non-Microsoft existing tasks first####
            # Create the scripting object
            $TaskScheduler = New-Object -ComObject Schedule.Service

            # Connect to the task scheduler library on the local machine
            $TaskScheduler.Connect('localhost')

            # Retrieve all (non-hidden) tasks from the root folder
            $RootFolder = $TaskScheduler.GetFolder('\')
            $Tasks = $RootFolder.GetTasks(0)

            # Iterate over each task and delete it
            foreach($Task in $Tasks){
                $RootFolder.DeleteTask($Task.Name,$null)
            }
        ####################################################
        
        $taskname1 = "2-" + $DSCconfigName
        $taskname2 = "3-" + $DSCconfigName + "-Final"
        $scriptname1 = $taskname1 + ".ps1"
        $scriptname2 = $taskname2 + ".ps1"

        ScheduledTask $taskname1
        {
            TaskName                = $taskname1
            ActionExecutable        = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments         = "-File `"C:\scripts\$scriptname1`""
            ScheduleType            = 'Daily'
            DaysInterval            = 1
            StartTime               = "00:00:00"
        }

        ScheduledTask $taskname2
        {
            TaskName                = $taskname2
            ActionExecutable        = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments         = "-File `"C:\scripts\$scriptname2`""
            ScheduleType            = 'Daily'
            DaysInterval            = 1
            StartTime               = "00:15:00"
        }

        ####
        #end comment out
        #>

        #endregion

		#end node
    }

#end configuration
}

#call the configuration we specified above which will compile it down into a .mof
#use "&" to call the variable/name of the configuration. the alternative is just specifying the whole name not in a variable like...
&$DSCconfigName -OutputPath C:\dsc-mof\$DSCconfigName
########
#region pre-config-run stuffs 
#delete IIS stuffs
########

#remove all sites
remove-website -name *

#remove all app pools
Get-ChildItem -Path IIS:\AppPools\ | ForEach-Object { Remove-WebAppPool $_.Name }

#cleanup folders?

#endregion

#cleanup is finished so now lets trigger the config
#start the configuration using the same path we just specified where the .mof is
Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\$DSCconfigName -Wait -ErrorAction Stop -Force -Verbose

#apply LCM settings
Set-DscLocalConfigurationManager -Path C:\dsc-mof\$DSCconfigName