########
# Author:       Matt Keller
# Description:  Powershell DSC to configure APP Pools & Sites in IIS for API Servers to be used in conjunction with other API Server DSC
# Changes:      04/17/2018      Initial creation
#               08/08/2019      Updated FindSecretID function to return the exact match from a search
#               08/13/2019      Merged FindSecretID function into GetSecret function
########

##########
#ASSUMPTION: You are copying this script out to the server then executing it from there
#            *The service account must have permissions to view the secret.
##########

#########
#region for functions for grabbing Secrets from SecretServer
#########
$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users
#$searchterm = "svcDVHAuthDev"

#if you're using TLS1.2 instead of 1.0, you need this
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#we need this module in order to use set-itemproperty below
Import-Module WebAdministration

# function that takes in a search term, finds the SecretServer ID, then uses the ID to return the password for that Secret.
Function GetSecret ($searchterm){

    #initial setup of webservice proxy using the url we set
    $proxy = New-WebServiceProxy $url -UseDefaultCredential

    #try to authenticate using the user, pass and domain we provided. this is the login to SecretServer
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0){
            $result1.Errors[0]
            exit
    } 
    else{
            #save our login session token into $token
            $token = $result1.Token
    }
        
    #use search term to find the ID of the Secret 
    $result2 = $proxy.SearchSecrets($token, $searchterm,$null,$null)
    if ($result2.Errors.length -gt 0){
            $result2.Errors[0]
    }
    else{
        #Search each result found for an exact match
        $result2.SecretSummaries | ForEach-Object {
            If ($_.SecretName -eq $searchterm){
                $secretname = $_.SecretName
                $secretId = $_.SecretID
            }
        }
    }

    #use the SecretID that was an exact match to retrieve the password
    $result3 = $proxy.GetSecret($token, $secretId, $false, $null)

    #return the password
    $return = $result3.Secret.Items[2].Value
    Return $return
}

#########
#endregion function stuffs
#########

$appPools = @(
        @{ AppPool = "Dataverify"; AppPoolIdentity = "world\svc_dvbp_d" }
        @{ AppPool = "dvweb"; AppPoolIdentity = "world\svc_dvbp_d" }
    )

foreach($pool in $appPools) {
    $poolidentity = $pool.AppPoolIdentity
    $poolname = $pool.AppPool
    #create our searchterm by removing the world\ in front of the app pool identity
    $searchterm = $poolidentity.Replace("world\","")
    #call our function to find the ID based on the search term, then return the password
    $poolpass = GetSecret $searchterm
    #set the app pool properties to have the identity we want with the password
    Set-ItemProperty "IIS:\AppPools\$poolName" -Name processModel -Value @{ userName=$pool.AppPoolIdentity; password=$poolpass; identitytype=3 }

    #Ensure $pool.AppPoolIdentity has access to \\dfs\nas\dv_shared\webapp deploy\ssl_certs
}