########
# Author:               Matt Keller / John Basso
# Description:          Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:              04/2/2018      Initial creation
#                       04/17/2018     change pre-work script to use unified config model
#                       06/14/2018     update for dvweb01uwwl
#                       06/15/2018     add IIS windows feature install (fix ISAPI first run problem)
#                       06/18/2018     add copy job for ComputerManagementDSC module so I can setup scheduled tasks
#                       06/28/2018     change over to dvad01uwwd. removed tls .reg file, dynatrace, & cert install regions for now
#                       10/22/2018     add Dynatrace install
#                       03/07/2019     change over to taskapi server
#                       04/11/2019     remove Dynatrace install, update variables to dvtaskapi01uwad
#                       05/22/2019     change over to INTGW server, added dynatrace install
#                       06/06/2019     supporting push to multiple hosts at once using computers.txt. had to move get-credential to the top. 
#                                      will have to change all the folders in local repo & GIT repo as well with this change
#                       06/12/2019     tweak IIS feature install section to be more sturdy for previously installed/not installed
#                                      add reboot after installs so #2 scripts runs without manual reboot intervention
#                                      move mailroom install above IIS install so reboot happens after
#                       06/27/2019     add debenu quick pdf install
#                       07/22/2019     change over to dvweb02uwwl, updated Git Paths
#                       07/23/2019     Added -Force to Restart-Computer
#                       07/23/2019     Updated Path to Dynatrace INI in InstallDynatrace.psm1
#                       07/26/2019     Added "-Credential $credential" and "-Authentication Credssp" to New-PSSession for MRTK Install
#                                      to allow elevated permissions for Invoke-Command to use "cmd /c" with a string containing the 
#                                      network path for the installer and parameters
#                       08/07/2019     Added InstallMailroomToolkit Module and removal of scripts 2/3 from local server
#                       08/12/2019     Start PSSession after Test-WSMan, then restart session if server is rebooted
#                                      Added extra Remove-PSSession at end to clear leftover sessions when script fails
#                       08/13/2019     Changed Debenu DLL regsvr32 to use Invoke instead of Psexec
#                       08/14/2019     Added Environment and ServerType variables
#
# Future Enhancements:  Add a way to read which modules you want to install from text file then install them
########
# $destPSModulepath should construct to = either C:\Program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

# Set your environment and server types
$Environment = "DEV"
$ServerType = "WEB"
$computers = Get-Content -Path "C:\GIT\DSC\DV\$Environment\$ServerType\computers.txt"
#full path where we are pulling the DSC scripts from
$localdscscriptpath1 = "C:\GIT\DSC\DV\$Environment\$ServerType\2-DSC-$ServerType-$Environment.ps1"
$localdscscriptpath2 = "C:\GIT\DSC\DV\$Environment\$ServerType\3-DSC-$ServerType-$Environment-Final.ps1"
echo " "
echo " "
echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
echo " "
echo " "
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #where we are copying our required powershell modules
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"

    #full path to where we are copying the DSC scripts to
    $destfilepath1 = $destpath + "\2-DSC-$ServerType-$Environment.ps1"
    $destfilepath2 = $destpath + "\3-DSC-$ServerType-$Environment-Final.ps1"
    $localfilepath1 = $localpath + "\2-DSC-$ServerType-$Environment.ps1"
    $localfilepath2 = $localpath + "\3-DSC-$ServerType-$Environment-Final.ps1"

    #Debenu Quick PDF .dlls
    $Debenufilesharepath = "\\dfs\nas\DV_Shared\WebApp Deploy\Debenu QuickPDF\DebenuPDFLibraryAX1112.dll"
    $Debenulocalpath = "C:\scripts\DebenuPDFLibraryAX1112.dll"

    ####Dynatrace Install variables####
    $InstallDynatrace_modulepath = "C:\GIT\Scripts\DV\InstallDynatrace\InstallDynatrace.psm1"
    $InstallDynatrace_filesharepath = "\\fs\pub\collab\dynatrace\Dynatrace 7\Windows\Agent\dynatrace-agent-7.0.0.2469-x86.msi"

    ###Mailroom Toolkit Install variables###
    $InstallMailroomToolkit_modulepath = "C:\GIT\Scripts\DV\InstallMailroomToolkit\InstallMailroomToolkit.psm1"
    $MRTK_installtype = "COM" # Use "Full" or "COM"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        # Start PSSession with $target computer
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy DSC script out to hosts
        #use -force to overwrite
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -Force -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath2 -Destination $destfilepath2 -ErrorAction Stop
            #Copy-Item -Path $localdscscriptpath3 -Destination $destfilepath3 -ErrorAction Stop
            echo "DSC script copies okay on $target"
            }

        Catch {
                echo "failed copying DSC scripts on $target"
                break
                }
        #endregion

        #region DSC modules & resources for use. Copy them to the Powershell Modules folder.
        Try {
            Copy-Item -Path "C:\Git\DSC\Modules\xWebAdministration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xWebAdministration module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\cNtfsAccessControl" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "cNtfsAccessControl module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\xSmbShare" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xSmbShare module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\ComputerManagementDsc" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "ComputerManagementDSC module copy okay on $target"

            #more copies
            #more echoes
            }

        Catch {
                echo "copy of DSC modules to powershell directory failed on $target"
                break
                }
        #endregion

        # Quick pause for C:\scripts folder creation
        Start-Sleep -Seconds 3

        #region install NetGender
        $NetGenderInstallPath = "\\dfs\NAS\DV_Shared\WebApp Deploy\NetGender\Netgender35\NetGender35.msi"
        Copy-Item -Path $NetGenderInstallPath -Destination $destpath -ErrorAction Stop
        Invoke-Command -ComputerName $target -ScriptBlock {Start-Process -Filepath msiexec "/i C:\scripts\NetGender35.msi /qn" -Wait} -ErrorAction Stop
        #endregion

        #region install MailroomToolkit using InstallMailroomToolkit.psm1
        Import-Module -Name $InstallMailroomToolkit_modulepath -Verbose
        InstallMailroomToolkit $target $MRTK_installtype
        #endregion

        #region install IIS feature remotely first then trigger reboot if needed
        #this was added to fix the ISAPI first run problem. 
        #I need to run Clear-WebConfiguration in the other script FIRST which is included in the WebAdministration module which is included in Server 2016 IIS feature
        echo "starting IIS feature install. This takes a couple minutes the very first time. Should be faster on subsequent runs"
        $windowsfeature1 = Get-WindowsFeature -ComputerName $target -Name Web-Server
        $windowsfeature2 = Get-WindowsFeature -ComputerName $target -Name Web-Mgmt-Console

        If ($windowsfeature1.Installed)
        {
            echo "IIS already installed"
        }
        Else 
        {
            Install-WindowsFeature -Name Web-Server -ComputerName $target -ErrorAction Stop -Verbose
            echo "IIS installed"
        }

        If ($windowsfeature2.Installed)
        {
            echo "Web MGT Console already installed"
        }
        Else
        {
            Install-WindowsFeature -Name Web-Mgmt-Console -ComputerName $target -ErrorAction Stop -Verbose
            echo "Web MGT Console installed"
        }

        #if either $windowsfeature1 or $windowsfeature2 are false reboot server to take effect then wait for server to come back
        If (-Not ($windowsfeature1.Installed -OR $windowsfeature2.Installed))
        {
            echo "At least one of IIS or Web MGT Console were not installed so lets reboot"
            Restart-Computer -ComputerName $target -Wait -For PowerShell -Timeout 300 -Delay 10 -Force
            # recreate session after reboot (the reboot will break the existing session)
            Remove-PSSession $session
            $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        }
        Else
        {
            echo "Both windows features were already installed so no reboot required"
        }

        #endregion

<#        #region install Dynatrace using InstallDynatrace.psm1
        Import-Module -Name $InstallDynatrace_modulepath -Verbose
        InstallDynatrace $target $InstallDynatrace_filesharepath $true
#>        #endregion

<#        #region install & register Debenu Quick PDF
        Try 
        {
            Copy-Item -Path $DebenuFilesharepath -Destination $destpath -Force -ErrorAction Stop
            echo "Debenu.dll copy okay on $target"
        }    
        Catch 
        {
            echo "failed copying Debenu to $target"
            break
        }

        Try
        {
            #Previously working with PSexec
            #psexec -h runs it in an elevated command prompt
            #Psexec -h \\$target regsvr32.exe /s $Debenulocalpath
            #echo "DONT FREAK OUT ABOUT THE RED TEXT - exit code 0 means success"
            Invoke-Command -Session $session -ScriptBlock {param($Debenulocalpath) regsvr32 /s $Debenulocalpath} -ArgumentList $Debenulocalpath
        }
        Catch
        {
            echo "failed registering Debenu.dll on $target"
            break
        }
#>        #endregion

        #region start #2 script
        Try 
        {
            echo " "
            echo "starting #2 DSC script run. This compiles the script into a .mof and runs the entire script. Its slow on first run but should be faster on subsequent runs"

            #invoke command to execute a ps1 script with $p6 parameter($p6 is the path argument for the script being called). -Argumentlist specifies $p6 parameter becomes $localfilepath1
            Invoke-Command -Session $session -scriptblock {
            param($p6) . $p6
            Remove-Item $p6
            } -ArgumentList $localfilepath1 -ErrorAction Stop
            echo " "
            echo "#2 DSC script finished running."
        }
        Catch
        {
            echo " "
            echo "#2 DSC script failed. try running it locally first"
            break
        }

        #endregion

        #region start #3 script
		
        Try
        {
            echo " "
            echo "starting #3 script run. This script is just assigning app pool identities for the most part so it should be fast."

            #invoke command to execute a ps1 script with $p7 parameter($p7 is the path argument for the script being called). -Argumentlist specifies $p7 parameter becomes $localfilepath2
            Invoke-Command -Session $session -scriptblock {
            param($p7) . $p7
            Remove-Item $p7
            } -ArgumentList $localfilepath2 -ErrorAction Stop
            echo " "
            echo "#3 script finished running."
        }
        Catch
        {
            echo " "
            echo "#3 script failed. try running it locally first"
            break
        }

        #endregion

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
    Remove-PSSession $session
}
# To clear leftover session if script fails
Remove-PSSession $session