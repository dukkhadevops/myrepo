########
# Author:               Matt Keller / John Basso
# Description:          Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:              04/2/2018      Initial creation
#                       04/17/2018     change pre-work script to use unified config model
#                       06/14/2018     update for dvweb01uwwl
#                       06/15/2018     add IIS windows feature install (fix ISAPI first run problem)
#                       06/18/2018     add copy job for ComputerManagementDSC module so I can setup scheduled tasks
#                       06/28/2018     change over to dvad01uwwd. removed tls .reg file, dynatrace, & cert install regions for now
#                       10/22/2018     add Dynatrace install
#                       03/07/2019     change over to taskapi server
#                       04/11/2019     remove Dynatrace install, update variables to dvtaskapi01uwad
#                       05/22/2019     change over to INTGW server, added dynatrace install
#                       06/06/2019     supporting push to multiple hosts at once using computers.txt. had to move get-credential to the top. 
#                                      will have to change all the folders in local repo & GIT repo as well with this change
#                       06/12/2019     tweak IIS feature install section to be more sturdy for previously installed/not installed
#                                      add reboot after installs so #2 scripts runs without manual reboot intervention
#                                      move mailroom install above IIS install so reboot happens after
#                       06/27/2019     add debenu quick pdf install
#                       07/22/2019     change over to dvweb02uwwl, updated Git Paths
#                       07/23/2019     Added -Force to Restart-Computer
#                       07/23/2019     Updated Path to Dynatrace INI in InstallDynatrace.psm1
#                       07/26/2019     Added "-Credential $credential" and "-Authentication Credssp" to New-PSSession for MRTK Install
#                                      to allow elevated permissions for Invoke-Command to use "cmd /c" with a string containing the 
#                                      network path for the installer and parameters
#                       08/07/2019     Added InstallMailroomToolkit Module and removal of scripts 2/3 from local server
#                       08/12/2019     Start PSSession after Test-WSMan, then restart session if server is rebooted
#                                      Added extra Remove-PSSession at end to clear leftover sessions when script fails
#                       08/13/2019     Changed Debenu DLL regsvr32 to use Invoke instead of Psexec
#                       08/14/2019     Added Environment and ServerType variables
#                       09/30/2019     Change over to DVDSC type
#
# Future Enhancements:  Add a way to read which modules you want to install from text file then install them
########
# $destPSModulepath should construct to = either C:\Program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

# Set your environment and server types
$Environment = "LAB"
$ServerType = "DVDSC"
$computers = Get-Content -Path "C:\GIT\DSC\DV\$Environment\$ServerType\computers.txt"
#full path where we are pulling the DSC scripts from
$localdscscriptpath1 = "C:\GIT\DSC\DV\$Environment\$ServerType\2-DSC-$ServerType-$Environment.ps1"
$localdscscriptpath2 = "C:\GIT\DSC\DV\$Environment\$ServerType\3-DSC-$ServerType-$Environment-Final.ps1"
echo " "
echo " "
echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
echo " "
echo " "
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $destcertpath = "\\" + $target + "\c$\scripts\certs"
    $localpath = "C:\scripts"
    $localcertpath = "C:\scripts\certs"

    #where we are copying our required powershell modules
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"

    #full path to where we are copying the DSC scripts to
    $destfilepath1 = $destpath + "\2-DSC-$ServerType-$Environment.ps1"
    $destfilepath2 = $destpath + "\3-DSC-$ServerType-$Environment-Final.ps1"
    $localfilepath1 = $localpath + "\2-DSC-$ServerType-$Environment.ps1"
    $localfilepath2 = $localpath + "\3-DSC-$ServerType-$Environment-Final.ps1"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        # Start PSSession with $target computer
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
             Invoke-Command -ComputerName $target -ScriptBlock { param($p2) md $p2 } -ArgumentList $localcertpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region check if c:\scripts\certs exists, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destcertpath)){
             Invoke-Command -ComputerName $target -ScriptBlock { param($p3) md $p3 } -ArgumentList $localcertpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts\certs exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts\certs on $target"
                break
              }
        #endregion

        #region copy DSC script out to hosts
        #use -force to overwrite
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -Force -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath2 -Destination $destfilepath2 -ErrorAction Stop
            #Copy-Item -Path $localdscscriptpath3 -Destination $destfilepath3 -ErrorAction Stop
            echo "DSC script copies okay on $target"
            }

        Catch {
                echo "failed copying DSC scripts on $target"
                break
                }
        #endregion

        #region DSC modules & resources for use. Copy them to the Powershell Modules folder.
        Try {

            Copy-Item -Path "C:\GIT\DSC\Modules\xPSDesiredStateConfiguration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xPSDesiredStateConfiguration module copy okay on $target"

            #more copies
            #more echoes
            }

        Catch {
                echo "copy of DSC modules to powershell directory failed on $target"
                break
                }
        #endregion

        #region create cert request, get it fulfilled, feed the thumbprint to script #2
        #copy out scripts
        #execute scripts to generate certreq & get it fulfilled

        #copy scripts needed to generate certs
        #use -force to overwrite
        Sleep -Seconds 5
        $certscript1 = "C:\git\scripts\NewCertificateSigningRequest\New-CertificateSigningRequest.ps1"
        Try {
            Copy-Item -Path $certscript1 -Destination $destcertpath -Force -ErrorAction Stop
            echo "cert script copy okay on $target"
            }
        Catch {
                echo "failed copying cert script on $target"
                break
                }

        Try 
        {
            echo " "
            echo "starting commands to generate cert request and fulfill it on CBCCA"

            #set location to the folder where everything is. import the module which has our function to create cert req.
            #submit the certreq to cbcca using the template we want. import the certificate into the location machine store
            Invoke-Command -Session $session -scriptblock {

                Set-Location C:\scripts\certs
                Import-Module .\New-CertificateSigningRequest.ps1
                New-CertificateSigningRequest -SubjectHost $env:computername -FilePath "c:\scripts\certs\certreq.csr" -ComputerName $env:computername
                certreq -submit -config "cbcca.cbc.local\CBCCA" -attrib "CertificateTemplate:WebServerSHA256" "C:\scripts\certs\certreq.csr" "C:\scripts\certs\cert.cer"
                Import-Certificate -CertStoreLocation Cert:\LocalMachine\My -FilePath "c:\scripts\certs\cert.cer"
            }

            echo " "
            echo "cert request fulfilled"
            echo "cleaning up cert stuffs"
            Remove-Item $destcertpath -Recurse 
            echo "c:\scripts\certs removed"
        }
        Catch
        {
            echo " "
            echo "cert request commands failed"
            break
        }
        
        #region start #2 script
        Try 
        {
            echo " "
            echo "starting #2 DSC script run. This compiles the script into a .mof and runs the entire script. Its slow on first run but should be faster on subsequent runs"

            #invoke command to execute a ps1 script with $p6 parameter($p6 is the path argument for the script being called). -Argumentlist specifies $p6 parameter becomes $localfilepath1
            Invoke-Command -Session $session -scriptblock {
            param($p6) . $p6
            Remove-Item $p6
            } -ArgumentList $localfilepath1 -ErrorAction Stop
            echo " "
            echo "#2 DSC script finished running."
        }
        Catch
        {
            echo " "
            echo "#2 DSC script failed. try running it locally first"
            break
        }

        #endregion

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
    Remove-PSSession $session
}
# To clear leftover session if script fails
Remove-PSSession $session