#########
# Author:       Matt Keller
# Description:  Powershell DSC to configure Windows Features & setup files/folders for API Servers to be used in conjunction with other API Server DSC
# Changes:      03/28/2018      Initial creation
#               05/2/2018       change everything over for use with Web Servers
#               05/22/2018      added ISAPI restrctions
#               06/05/2018      added SessionStateTimeout & DeleteXPoweredByHTTPResponseHeader
#               06/18/2018      remove restartschedule timespan array (not what we needed) add script resource to handle PeriodRestart time property
#               06/18/2018      update LCM config to ApplyAndMonitor & remove DVConfig file resource & add scheduled task to run script on regular interval
#               06/28/2018      change over to dvad01uwwd
#               09/14/2018      add app pool and site etc for CLAS-API
#               10/22/2018      move ISAPI clear-webconfiguration call to above/outside configuration keyword
#                               add Dynatrace install to script 1
#                               remove dvconfig.xml deploy
#                               fix lbmonitor deploy location
#               10/31/2018      share AppLogs
#                               add creation of C:\app\certs
#                               make sure tasks are setup correctly
#               03/08/2019      change over to taskapi
#               04/08/2019      added in Dynatrace install
#                               change over to DataverifyAPI name
#               04/11/2019      troubleshooting deploy to Lab - fixing lbmonitor and base site creation
#               05/07/2019      add DataVerify.Task.Broker.API web application as webapp under base DataverifyAPI site
#               05/23/2019      change over to INTGW server
#               06/17/2019      add section for removal of x-powered-by http response header
#               08/14/2019      Replaced periodicRestart script resource with restartTimeLimit property
#                               Debugged/Fixed X-Powered By script resource
#                               Cleaned up old comments
#                               Added variables for SMBshare access
#               09/30/2019      Change over to DVDSC
#
#########
#########
#ASSUMPTION: You are copying this script out to the server then executing it from there
#########

Set-ExecutionPolicy Unrestricted -Force

#variable that holds our config name since we'll be calling it up here and then all the way at the bottom.
$DSCconfigName = "DSC-DVDSC-LAB"

#create our configuration with the "Configuration" keyword. Now lets use that variable we created above.
#note the resources we're importing here. they must be included in the 1st scripts copy job
#note the parameters we are pulling in here. you'll need to use those when you call the configuration at the bottom to compile it into a .mof

Configuration $DSCconfigName {
    param 
    (
        [string] $certificateThumbPrint,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $RegistrationKey
    )

    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName PSDesiredStateConfiguration									

    Node $env:computername {

        ########
        #region DSC Features & Service
        ########
        WindowsFeature WebMgmtTools
        {
            Ensure = 'Present'
            Name = 'Web-Mgmt-Tools'
        }

        WindowsFeature DSCServiceFeature 
        {
            Ensure = 'Present'
            Name = 'DSC-Service'   
        }

        xDSCWebService DSCPullServer
        {
            Ensure = 'Present'
            EndpointName = 'DSCPullServer'
            Port = 443
            PhysicalPath = "$env:SystemDrive\inetpub\DSCPullServer"
            ModulePath = "C:\Program Files\WindowsPowerShell\DscService\Modules"
            ConfigurationPath = "C:\Program Files\WindowsPowerShell\DscService\Configuration"
            State = "Started"
            DependsOn = "[WindowsFeature]DSCServiceFeature"
            CertificateThumbPrint =  $certificateThumbprint
            UseSecurityBestPractices = $true
        }

        File RegistrationKeyFile 
        {
            Ensure = 'Present'
            Type = 'File'
            DestinationPath = '$env:PROGRAMFILES\WindowsPowerShell\DscService\RegistrationKeys.txt'
            Contents = $registrationKey
            DependsOn = '[WindowsFeature]DSCServiceFeature'   
        }

        #endregion

		#end node
    }

#end configuration
}

#set some variables for use for cert  regkey which we will use for securing the .mof & communication between pull server and clients
$cert = Get-ChildItem Cert:\LocalMachine\My | where-object Subject -eq "CN=$env:computername"
$cert

$regKey = New-Guid
$regKey
		

#call the configuration we specified above which will compile it down into a .mof
#use "&" to call the variable/name of the configuration. the alternative is just specifying the whole name not in a variable like...
&$DSCconfigName -certificateThumbprint $cert.Thumbprint -RegistrationKey $regkey -OutputPath C:\dsc-mof\$DSCconfigName

#cleanup is finished so now lets trigger the config
#start the configuration using the same path we just specified where the .mof is
Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\$DSCconfigName -Wait -ErrorAction Stop -Force -Verbose

#apply LCM settings
#Set-DscLocalConfigurationManager -Path C:\dsc-mof\$DSCconfigName