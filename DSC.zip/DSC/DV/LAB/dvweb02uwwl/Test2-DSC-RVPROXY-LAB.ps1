﻿#########
# Author:       John Basso
# Description:  Powershell DSC to configure NGINX on Windows
# Changes:      07/29/2019      Initial creation
#
#########
#########
#ASSUMPTION: You are copying this script out to the server then executing it from there
#########

Set-ExecutionPolicy Unrestricted

#lets create a variable that holds our config name since we'll be calling it up here and then all the way at the bottom.
#now we only have to change it in one place..... hopefully...
$DSCconfigName = "DSC-RVPROXY-LAB"

#create our configuration with the "Configuration" keyword. Now lets use that variable we created above.
#note the resources we're importing here. they must be included in the 1st scripts copy job
#also note the webadministration module. this should be installed by default on 2012 & up servers but not 2008 R2 etc.

Configuration $DSCconfigName {
    #Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    #Import-DscResource -ModuleName xWebAdministration
    #Import-DscResource -ModuleName cNtfsAccessControl
    #Import-DscResource -ModuleName xSmbShare
    #Import-DscResource -ModuleName ComputerManagementDsc

    Node $env:computername {

        #disclaimer
        #do not reorder these sections, they build off one another

        ########
        #region Basic File & Folder section. Permissions???
        ########
        
        $RVProxy_AppPath = "C:\Scripts\nginx-1.13.8"
        # Network path needs credentials or permissions 
        #$RVProxy_AppPath = "\\fs\cbc\dept\windows\nginx-1.13.8"
        $RVProxy_ConfPath = "C:\Scripts\NGINX_Conf\conf\nginx.conf"
        $path1 = "C:\Program Files (x86)\nginx-1.13.8"
        $path2 = "C:\Program Files (x86)\nginx-1.13.8\conf\nginx.conf"

        File RVProxyApp #setup C:\Program Files (x86)\nginx-1.13.8
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            Recurse = $true
            SourcePath = $RVProxy_AppPath
            DestinationPath = $path1
        }

        Log AfterRVProxyApp
        {
            # The message below gets written to the Microsoft-Windows-Desired State Configuration/Analytic log
            Message = "Finished running the RVProxyApp"
            DependsOn = "[File]RVProxyApp" # Depends on successful execution of the File resource.
        }

        File RVProxyConfig #C:\Program Files (x86)\nginx-1.13.8\conf\nginx.config
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "File" # Default is "File".
            SourcePath = $RVProxy_ConfPath
            DestinationPath = $path2
            DependsOn = "[File]RVProxyApp"
        }

        Log AfterRVProxyConfig
        {
            # The message below gets written to the Microsoft-Windows-Desired State Configuration/Analytic log
            Message = "Finished running the RVProxyConfig"
            DependsOn = "[File]RVProxyConfig" # Depends on successful execution of the File resource.
        }

        #endregion

        #region Windows Service

        Service RVProxySvc
        {
            Ensure = "Present"
            Name = "NGINX"
            Path = "C:\Program Files (x86)\nginx-1.13.8\nginx.exe"
            BuiltInAccount = "LocalSystem"
            StartupType = "Automatic"
            State = "Running"
            DependsOn = "[File]RVProxyApp"
        }

        Log AfterRVProxySvc
        {
            # The message below gets written to the Microsoft-Windows-Desired State Configuration/Analytic log
            Message = "Finished running the RVProxySvc"
            DependsOn = "[Service]RVProxySvc"
        }

        #endregion

		########
        #region Local Configuration Manager
        ########

        #all the settings we want for the Local Configuration Manager (LCM)
        #24hrs in a day X 60mins an hour = 1440mins
        #[DSCLocalConfigurationManager()]
        LocalConfigurationManager
        {
            ConfigurationModeFrequencyMins = 1440
            ConfigurationMode = "ApplyAndAutoCorrect"
            RefreshMode = "Push"
            RebootNodeIfNeeded = $false
            AllowModuleOverwrite = $true
        }

        #endregion
		
        ########
        #region TASKS
        ########
        #commenting this out for now
        <#


        #Please see the wealth of examples on https://github.com/PowerShell/ComputerManagementDsc/wiki/ScheduledTask
        ########

        ####remove all non-Microsoft existing tasks first####
            # Create the scripting object
            $TaskScheduler = New-Object -ComObject Schedule.Service

            # Connect to the task scheduler library on the local machine
            $TaskScheduler.Connect('localhost')

            # Retrieve all (non-hidden) tasks from the root folder
            $RootFolder = $TaskScheduler.GetFolder('\')
            $Tasks = $RootFolder.GetTasks(0)

            # Iterate over each task and delete it
            foreach($Task in $Tasks){
                $RootFolder.DeleteTask($Task.Name,$null)
            }
        ####################################################
        
        $taskname1 = "2-" + $DSCconfigName
        $taskname2 = "3-" + $DSCconfigName + "-Final"
        $scriptname1 = $taskname1 + ".ps1"
        $scriptname2 = $taskname2 + ".ps1"

        ScheduledTask $taskname1
        {
            TaskName                = $taskname1
            ActionExecutable        = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments         = "-File `"C:\scripts\$scriptname1`""
            ScheduleType            = 'Daily'
            DaysInterval            = 1
            StartTime               = "00:00:00"
        }

        ScheduledTask $taskname2
        {
            TaskName                = $taskname2
            ActionExecutable        = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments         = "-File `"C:\scripts\$scriptname2`""
            ScheduleType            = 'Daily'
            DaysInterval            = 1
            StartTime               = "00:15:00"
        }

        ####
        #end comment out
        #>

        #endregion

		#end node
    }

#end configuration
}

																				 
#call the configuration we specified above which will compile it down into a .mof
#use "&" to call the variable/name of the configuration. the alternative is just specifying the whole name not in a variable like...
&$DSCconfigName -OutputPath C:\dsc-mof\$DSCconfigName
########

#start the configuration using the same path we just specified where the .mof is
Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\$DSCconfigName -Wait -ErrorAction Stop -Force -Verbose
