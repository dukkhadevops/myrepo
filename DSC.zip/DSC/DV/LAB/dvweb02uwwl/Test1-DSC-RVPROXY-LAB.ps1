﻿########
# Author:               John Basso
# Description:          Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:              07/26/2019     Initial creation
#
# Future Enhancements:  Add a way to read which modules you want to install from text file then install them
########
# $destPSModulepath should construct to = either c:\program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

$computers = Get-Content -Path "C:\GIT\DSC\DV\Lab\dvweb02uwwl\computers.txt"
echo " "
echo " "
echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
echo " "
echo " "
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"
    $destconfpath = $destpath + "\nginx-1.13.8"

    #full path where we are pulling the DSC scripts from
    $localdscscriptpath1 = "C:\Git\dsc\DV\Lab\dvweb02uwwl\2-DSC-RVPROXY-LAB.ps1"

    #full path to where we are copying the DSC scripts to
    $destfilepath1 = $destpath + "\2-DSC-RVPROXY-LAB.ps1"
    $localfilepath1 = $localpath + "\2-DSC-RVPROXY-LAB.ps1"

    #where we are copying our required powershell modules
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"

    #RVProxy path
    $RVProxy_AppPath = "\\fs\cbc\dept\windows\nginx-1.13.8"
        
    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy DSC script out to hosts
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -Force -ErrorAction Stop
            echo "DSC script copies okay on $target"
            }

        Catch {
                echo "failed copying DSC scripts on $target"
                break
                }
        #endregion

        #region DSC modules & resources for use. Copy them to the Powershell Modules folder.
        Try {
            Copy-Item -Path "C:\Git\DSC\Modules\xWebAdministration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xWebAdministration module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\cNtfsAccessControl" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "cNtfsAccessControl module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\xSmbShare" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xSmbShare module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\ComputerManagementDsc" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "ComputerManagementDSC module copy okay on $target"

            #Copy NGINX to local server            
            Copy-Item -Path $RVProxy_AppPath -Recurse -Force -Destination $destpath -ErrorAction Stop
            #Copy NGINX config to local server
            Copy-Item -Path "C:\Git\dsc\Test\NGINX_Conf\conf" -Recurse -Force -Destination $destconfpath -ErrorAction Stop
            echo "NGINX copy okay on $target"
            }
        Catch {
            echo "copy of DSC modules to powershell directory failed on $target"
            break
                }
        #endregion

        #region start #2 script
        Try 
        {
            echo "starting #2 DSC script run. This compiles the script into a .mof and runs the entire script."
            $session = New-PSSession $target -Name $target -Authentication Credssp -Credential $credential		
            Invoke-Command -Session $session -scriptblock {param($DSCScript) . $DSCScript} -ArgumentList $localfilepath1 -ErrorAction Stop
            echo " "
            echo "#2 DSC script finished running."
        }
        Catch
        {
            echo " "
            echo "#2 DSC script failed. try running it locally first"
            break
        }
        
        #endregion
        
        echo " "
        echo "##### Done with $target #####"
        echo " "
    }
    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
}
