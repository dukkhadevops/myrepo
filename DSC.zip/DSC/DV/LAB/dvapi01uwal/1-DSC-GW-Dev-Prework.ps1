########
# Author:               Matt Keller
# Description:          Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:              04/2/2018      Initial creation
#                       04/17/2018     change pre-work script to use unified config model
#                       06/06/2018     update for confmgmt04uwad & app server POC
#                       06/07/2018     added MRTK copy and install
#                       06/08/2018     update for confmgmt05uwwd & GW server POC
#
# Future Enhancements:  Add a way to read which modules you want to install from text file then install them
########
# make sure you are running this under your .cbc account
# $destPSModulepath should construct to = either c:\program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

$computers = Get-Content -Path "C:\SVN\WindowsAdmins\DSC\Test\confmgmt05uwwd\computers.txt"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #where we are copying our required powershell modules
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"

    #full path where we are pulling the DSC scripts from
    $localdscscriptpath1 = "C:\SVN\WindowsAdmins\DSC\Test\confmgmt05uwwd\2-DSC-GW-Dev.ps1"
    $localdscscriptpath2 = "c:\SVN\WindowsAdmins\DSC\Test\confmgmt05uwwd\3-DSC-GW-Dev-Final.ps1"

    #full path to where we are copying the DSC scripts to
    $destfilepath1 = $destpath + "\2-DSC-GW-Dev.ps1"
    $destfilepath2 = $destpath + "\3-DSC-GW-Dev-Final.ps1"

    #path to the source reg file for ssl\tls
    $regfilesource = "\\fs\cbc\dept\windows\build_scripts\configure_ssl_and_tls.reg"

    #path to the destination for the reg file
    $regfiledest = $localpath + "\configure_ssl_and_tls.reg"

    #cert paths and names. dont forget to specify below which cert store you're using. Here is a useful mapping for where they go
    #https://stackoverflow.com/questions/40440958/does-anybody-know-how-the-powershell-certificate-provider-paths-map-to-certmgr-m
    $cert1path = "\\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte_primary_root_ca.cer"
    $cert2path = "\\dfs\nas\dv_shared\webapp deploy\ssl_certs\thawte\thawte EV SSL CA - G3.cer"
    #this returns the rightmost element from the path above (the cert name essentially)
    $cert1name = Split-Path -Path $cert1path -Leaf
    $cert2name = Split-Path -Path $cert2path -Leaf

    #dynatrace install
    $dynatracefileshare = "\\cbcnas04\shared\dynaTrace\Dynatrace 7\WIndows\Client\dynatrace-client-7.0.0.2469-x86-64.msi"
    $dynatracefile = Split-Path $dynatracefileshare -Leaf
    $dynatracedest = $localpath + "\" + $dynatracefile
    $dynatraceargs = "/i $dynatracedest /quiet"

    #MRTK install
    #see command line pdf help document in \\dfs\nas\DV_Shared\WebApp Deploy\MRTK\MRTK Architect US Installer Command Line.pdf
    $MRTKfulldir = "\\dfs\nas\dv_shared\WebApp Deploy\MRTK\MRTK_05_2018"
    $MRTKfileshare = "\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\MRTK_05_2018\setup.exe"
    $MRTKfile = Split-Path $MRTKfileshare -Leaf
    $MRTKfulldirleaf = Split-Path $MRTKfulldir -Leaf
    #MRTK destination variables
    $MRTKrenamepath = $localpath + "\" + $MRTKfulldirleaf
    $MRTKrenamedestpath = $localpath + "\MRTK"
    $MRTKdestfile = $localpath + "\MRTK\" + $MRTKfile
    $MRTKtestdest = $MRTKdestpath + "\" + $MRTKfile
    #MRTK setup arguments
    $MRTKsetuplog = $localpath + "\MRTKlog.txt"
    $MRTKregistrationkey = "1B6HEL3-ALS48Y-AE6E2"
    $MRTKargs = "-s -f2$MRTKsetuplog -k$MRTKregistrationkey -gC"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        <# Select the master branch and download the zip of the repository from something like: https://github.com/PowerShell/xTimeZone/tree/master
        Extract the zip file to a folder.
        Rename the folder if you need to xTimeZone for example
        Copy xTimeZone to C:\Program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules
        Verify you can discover the DSCResource:
            Get-DscResource
        #>

        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy DSC script out to hosts
        #use -force to overwrite
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -Force -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath2 -Destination $destfilepath2 -ErrorAction Stop
            #Copy-Item -Path $localdscscriptpath3 -Destination $destfilepath3 -ErrorAction Stop
            echo "DSC script copies okay on $target"
            }

        Catch {
                echo "failed copying DSC scripts on $target"
                break
                }
        #endregion

        #region DSC modules & resources for use. Copy them to the Powershell Modules folder.
        Try {
            Copy-Item -Path "C:\SVN\WindowsAdmins\DSC\Modules\xWebAdministration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xWebAdministration module copy okay on $target"

            Copy-Item -Path "C:\SVN\WindowsAdmins\DSC\Modules\cNtfsAccessControl" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "cNtfsAccessControl module copy okay on $target"

            Copy-Item -Path "C:\SVN\WindowsAdmins\DSC\Modules\xSmbShare" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xSmbShare module copy okay on $target"
            
            Copy-Item -Path "C:\SVN\WindowsAdmins\DSC\Modules\ComputerManagementDsc" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xSmbShare module copy okay on $target"
            }

        Catch {
                echo "copy of DSC modules to powershell directory failed on $target"
                break
                }
        #endregion

        #region copy .reg file
        Try {
            Copy-Item -Path $regfilesource -Destination $destpath -ErrorAction Stop
            echo ".reg file copy okay on $target"
        }

        Catch {
                echo ".reg file copy failed on $target"
                break
        }
        #endregion

        #region execute .reg file
        #invoke command on $target passing a scriptblock to execute start-process of regedit.exe with $p2 parameter where $p2 is $regfiledest which is just a .reg file we copied to c:\scripts
        Try {
             Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath "c:\windows\regedit.exe" $p2 } -ArgumentList "$regfiledest" -ErrorAction Stop
             echo ".reg file execution okay on $target"
             }

        Catch {
                echo ".reg file execution failed on $target"
                break
              }
        #endregion

        #region copy dynatrace locally & install via silent install using the path you specified above
        Try 
        {
            #copy jobs and echoes first
            echo "starting dynatrace copy to $target"
            Copy-Item -Path $dynatracefileshare -Destination $destpath -ErrorAction Stop
            echo "dynatrace copy okay on $target"

            #trigger install with echoes before and after
            echo "starting dynatrace install on $target, this takes a couple minutes"
            Invoke-Command -Computername $target -ScriptBlock { param($p5) Start-Process -Filepath msiexec $p5 -Wait } -ArgumentList "$dynatraceargs" -ErrorAction Stop
            echo "dynatrace install okay on $target"
        }
        Catch
        {
            echo "dynatrace install failed on $target"
            break
        }

        #endregion

        #comment out MRTK region
        <#
        #region copy MRTK locally & trigger MRTK install silently using the path specified above
        Try
        {
            #if file is not already copied locally, go ahead and copy the file. then trigger install
            echo "checking if MRTK install file already exists on $target"

            #if filepath does not exist, echo then create the dir and do the copy
            If(!(Test-Path $MRTKtestdest)) 
            {
                echo "$MRTKtestdest does not exist on $target."
                #Invoke-Command -Computername $target -ScriptBlock { param($p6) md $p6 } -ArgumentList $MRTKdestpath -ErrorAction Stop
                echo "MRTK full install dir copy starting. This will take awhile to copy out locally. Another echo will come up when its finished or fails."
                Copy-Item -Path $MRTKfulldir -Destination $destpath -Recurse -ErrorAction Stop
                echo "copy SUCCESS. Now rename $MRTKrenamepath to $MRTKrenamedestpath"
                Invoke-Command -Computername $target -ScriptBlock { param($p6,$p7) Rename-Item -path $p6 -NewName $p7 } -ArgumentList $MRTKrenamepath,$MRTKrenamedestpath -ErrorAction Stop
                echo "rename SUCCESS" 
            }
            #else the file exists so just echo and move on to install step
            Else 
            {
                echo "$MRTKtestdest already exists on $target. "
            }
            #trigger install
            echo "starting MRTK install on $target, this takes about 5 minutes"
            Invoke-Command -Computername $target -ScriptBlock { param ($p7,$p8) Start-Process -FilePath $p7 -ArgumentList $p8 -Wait } -ArgumentList $MRTKdestfile,$MRTKargs -ErrorAction Stop
            echo "MRTK install okay on $target"
        }
        Catch
        {
            echo "MRTK install failed on $target."
            break
        }
        
        #endregion

        #>
        
        #comment out cert install region for now
        <#
        
        #region copy certs out to server
        Try{
            Copy-Item -path $cert1path -destination $destpath -ErrorAction Stop
            Copy-Item -path $cert2path -destination $destpath -ErrorAction Stop
            echo "cert copies okay on $target"
            echo " "
            }
        Catch{
            echo "cert copies failed on $target"
            }

        #endregion

        #region install required certs $cert1,2,3 etc specify the path above and cert store location below
        Try 
        {

            #authroot = Third Part Root CA
            #reference: $cert1 | Import-Certificate -CertStoreLocation Cert:\LocalMachine\AuthRoot
            $temppath = $localpath + "\" + $cert1name
            Invoke-Command -ComputerName $target -ScriptBlock { param($p3) Import-Certificate -FilePath $p3 -CertStoreLocation Cert:\LocalMachine\AuthRoot } -ArgumentList $temppath -ErrorAction Stop

            #CA = Intermediate CA
            $temppath = $localpath + "\" + $cert2name
            #reference: $cert2 | Import-Certificate -CertStoreLocation Cert:\LocalMachine\CA
            Invoke-Command -ComputerName $target -ScriptBlock { param($p4) Import-Certificate -FilePath $p4 -CertStoreLocation Cert:\LocalMachine\AuthRoot } -ArgumentList $temppath -ErrorAction Stop
            echo " "
            echo " "
            echo "cert imports okay on $target"
        }
        Catch
        {
            echo "cert import failed on $target"
            break
        }
        #endregion 

        #>

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
}
