﻿########
# Author:               John Basso / Matt Keller
# Description:          Environment Preparation based on list of server names.
#                       Parses server name to determine environment and server type.
#                       Creates missing service accounts, adds to AD groups and adds credentials to Secret Server in preparation for DSC deployment
#                       Read computers.txt from a working path variable
#                       Output results to the working path
#                       csv file to record the state before changes are made
#                       Log.txt to log each step as a change is made
#                       Log_ChangeSummary.txt will include a short summary of changes that were made
# Changes:              10/22/2019      Initial creation
#                       10/30/2019      Added AD and Secret Server check for accounts/groups
#                       10/31/2019      Added logic to create AD account/group and adding accounts to Secret Server
#                       11/14/2019      Added DataVerify AD Group membership additions
#                       11/15/2019      Added commented out method for adding Log On To Permissions
#                       **********      LogOnTo Permissions have a limit of 64 values
########

######## ASSUMPTIONS
# This script assumes a specific naming convention applies to server names
# Server Naming Convention Format: Root Name|Number|Location|Support Team|Type|Enviroment
# First two letters are the prefix for the business line
# The letters following the prefix and before the numbers are the type of server as it applies to the business line
# The number does not have an impact
# The letters following the number include the Location, Support Team, Type and Enviroment
########

# Read list of computers for environment
$WorkingPath = "C:\GIT\DSC\DV\Environment-Prep"
$LogPath = "$WorkingPath\Logs"
$computers = Get-Content -Path "$WorkingPath\computers.txt"
# Exit script if the list is empty
if ($computers -eq $null) {
    echo "`ncomputers.txt is empty!"
    exit
}

# Report variables
$Export = @()
$ExportCreatedLog = "Summary of changes that have been made:`n"

#region LogWrite function
$logfile = "$LogPath\Log.txt"
Function LogWrite{
    Param ([string]$logstring)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp - $target - $logstring"
    Add-Content $logfile -Value $Line
}
#endregion

#region for grabbing Secrets from SecretServer

$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users

#if you're using TLS1.2 instead of 1.0, you need this
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# function that takes in a search term, finds the SecretServer ID, then uses the ID to return the password for that Secret.
Function GetSecret ($searchterm){

    #initial setup of webservice proxy using the url we set
    $proxy = New-WebServiceProxy $url -UseDefaultCredential

    #try to authenticate using the user, pass and domain we provided. this is the login to SecretServer
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0) {
            $result1.Errors[0]
            break
    } 
    else {
            #save our login session token into $token
            $token = $result1.Token
    }

    #use search term to find the ID of the Secret 
    $result2 = $proxy.SearchSecrets($token, $searchterm, $null, $null)
    if ($result2.Errors.length -gt 0) {
            $result2.Errors[0]
    }
    elseif ($result2.SecretSummaries.length -eq 0) {
            $secretname = $false
    }
    else {
        #Search each result found for an exact match
        $result2.SecretSummaries | ForEach-Object {
            If ($_.SecretName -eq $searchterm) {
                $secretname = $_.SecretName
                $secretId = $_.SecretID
            }
        }
        #use the SecretID that was an exact match to retrieve the password
        $result3 = $proxy.GetSecret($token, $secretId, $false, $null)
        #return the password
        $return = $result3.Secret.Items[2].Value
    }

    #return the username
    $return2 = $secretname
    Return $return2
}
#endregion

# function that takes in a username, creates a SecretServer ID and password, then returns the password for that Secret.
Function CreateSecret ($NewUser, $BusinessLine, $Environment){

    #initial setup of webservice proxy using the url we set
    $proxy = New-WebServiceProxy $url -UseDefaultCredential

    $msg = "Function CreateSecret: Connecting to Secret Server..."
    LogWrite $msg

    #try to authenticate using the user, pass and domain we provided. this is the login to SecretServer
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0) {
            $result1.Errors[0]
            break
    } 
    else {
            #save our login session token into $token
            $token = $result1.Token
    }

    # Find template in Secret Server
    $templateName = "Active Directory Account"
    $template = $proxy.GetSecretTemplates($token).SecretTemplates | Where {$_.Name -eq $templateName}
    if ($template.id -eq $null) {
        $msg = "Function CreateSecret: Error: Unable to find Secret Template " +  $templateName
        LogWrite $msg
        Return
    }
    # Map fields from template for new user entry
    $secretName = $NewUser
    $templateDomain = ($template.Fields | Where {$_.DisplayName -eq "Domain"}).Id
    $templateUsername = ($template.Fields | Where {$_.DisplayName -eq "Username"}).Id
    $templatePassword = ($template.Fields | Where {$_.DisplayName -eq "Password"}).Id
    $templateNotes = ($template.Fields | Where {$_.DisplayName -eq "Notes"}).Id
    $secretItemFields = ($templateDomain, $templateUsername, $templatePassword, $templateNotes)
    
    $msg = "Function CreateSecret: Creating Active Directory Account: " + $domain + "\" + $NewUser;
    LogWrite $msg

    #Password is set to null so will generate a new one based on settings on template
    $newPass = $null
    if ($newPass -eq $null) {
        $msg = "Function CreateSecret: Generating New Password for account"
        LogWrite $msg
        $secretFieldIdForPassword = $templatePassword
        $newPass = $proxy.GeneratePassword($token, $secretFieldIdForPassword).GeneratedPassword
    }

    $secretItemValues=($domain,$NewUser,$newPass, "")
    
    # Define $folderId Search based on Business Line and Environment
    # Find Parent Folder for Business Line
    $ParentFolderSearch = $proxy.SearchFolders($token,$BusinessLine)
    if ($ParentFolderSearch.Folders.Count -eq 1) {
        $ParentFolderId = $ParentFolderSearch.Folders.Id
    }
    else {
        $msg = "Function CreateSecret: Secret Server Parent Folder search failed! Either the Business Line folder does not exist or there were duplicate folders found."
        LogWrite $msg
        break
    }

    # Find Environment subfolder under the Business Line
    $EnvFolderSearch = $proxy.SearchFolders($token,$Environment)
    if ($EnvFolderSearch.Folders.Count -gt 0) {
        $EnvFolder = $EnvFolderSearch.Folders | ?{$_.ParentFolderId -eq $ParentFolderId}
        $folderId = $EnvFolder.Id
    }
    else {
        $msg = "Function CreateSecret: Secret Server Environment subfolder search failed! Make sure the folder exists as a subfolder of the Business Line."
        LogWrite $msg
        break
    }

    # Add new Secret
    $addResult = $proxy.AddSecret($token, $template.Id, $secretName, $secretItemFields, $secretItemValues, $folderId)
    if ($addResult.Errors.Count -gt 0) {
        $msg = "Function CreateSecret: Add Secret Error: " +  $addResult.Errors[0]
        LogWrite $msg
        Return
    }
    else {
        $msg = "Function CreateSecret: Successfully added Secret: " +  $addResult.Secret.Name + " (Secret Id:" + $addResult.Secret.Id + ")"
        LogWrite $msg
    }
    
    # Return the password
    Return $newPass
}
#endregion

#for each computer target in our computers.txt file
Foreach ($target in $computers) {

    #region Parse Server Name into variables

    # Example $target
    # $target = "dvweb02uwwl"
    # Parses string one character at a time
    # $target.ToCharArray()
    # Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
    $targetarray = $target -Split '(\d\d)'
    # Read the first string, which is the Root Name for the server
    $RootName = $targetarray[0]
    # Read the second string, which is the double digit number in the server name
    $Number = $targetarray[1]
    # Read the third string, which includes Location/Support Team/Type/Environment
    $Details = $targetarray[2]
    # Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
    $Prefix = $RootName[0,1] -join ''
    $Prefix = $($Prefix.ToLower())
    # Read the Root Name, starting after the second character (web from dvweb)
    $ServerType = $RootName.Substring(2)
    $ServerType = $($ServerType.ToLower())
    # Read last character for Environment
    $Environment = $Details.Substring($Details.Length-1)
    # Update Environment variable
    switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
<#
    Write-Host "Server information based on name:
    Root Name: $RootName
    Number: $Number
    Details: $Details
    Prefix: $Prefix
    Server Type: $ServerType
    Server Type in Upper Case is: $($ServerType.ToUpper())
    Environment: $Environment
    Environment in Upper Case is: $($Environment.ToUpper())
    Environment Initial Letter is: $($Environment[0])
    "
#>
    # The type of server will define the needs through flag variables
    # Currently not using these flags
    switch ($ServerType){
        "app"{$FlagAPP = $true}
        "bp"{$FlagBP = $true}
        "batch"{$FlagBATCH = $true}
        "fnma"{$FlagFNMA = $true}
        "gw"{$FlagGW = $true}
        "inapi"{$FlagINAPI = $true}
        "inet"{$FlagINET = $true}
        "intgw"{$FlagINTGW = $true}
        "mrtk"{$FlagMRTK = $true}
        "pdf"{$FlagPDF = $true}
        "score"{$FlagSCORE = $true}
        "svc"{$FlagSVC = $true}
        "task"{$FlagTASK = $true}
        "taskapi"{$FlagTASKAPI = $true}
        "web"{$FlagWEB = $true}
    }
    #endregion

    # Define service account and AD group names
    $ServerLocalAdminGroup = $target + "_admin"
    $ServerConfigGroup = $Prefix + ".serverconf." + $Environment
    $ServerLogGroup = $Prefix + ".serverlog." + $Environment
    $IISaccount = "world\svc_" + $Prefix + $ServerType + "_" + $($Environment[0])
    $SecretServerAccount = $IISaccount.Replace("world\","")

    # Check for existence of AD groups, service account and Secret Server credentials
    $ServerLocalAdminGroupExists = [bool] (Get-ADGroup -Filter { SamAccountName -eq $ServerLocalAdminGroup })
    $ServerConfigGroupExists = [bool] (Get-ADGroup -Filter { SamAccountName -eq $ServerConfigGroup })
    $ServerLogGroupExists = [bool] (Get-ADGroup -Filter { SamAccountName -eq $ServerLogGroup })
    $IISaccountExists = [bool] (Get-ADUser -Filter { SamAccountName -eq $SecretServerAccount })
    $SecretServerAccountExists = [bool] (GetSecret $SecretServerAccount)

    # Store results
    $Found = New-Object PSObject
    $Found | Add-Member -MemberType NoteProperty -Name "Server Name" -Value $target
    $Found | Add-Member -MemberType NoteProperty -Name "Service Acct" -Value $SecretServerAccount
    $Found | Add-Member -MemberType NoteProperty -Name "Acct in AD?" -Value $IISaccountExists
    $Found | Add-Member -MemberType NoteProperty -Name "Acct in SS?" -Value $SecretServerAccountExists
    $Found | Add-Member -MemberType NoteProperty -Name "Admin Group" -Value $ServerLocalAdminGroup
    $Found | Add-Member -MemberType NoteProperty -Name "A.Exists?" -Value $ServerLocalAdminGroupExists
    $Found | Add-Member -MemberType NoteProperty -Name "Config Group" -Value $ServerConfigGroup
    $Found | Add-Member -MemberType NoteProperty -Name "C.Exists?" -Value $ServerConfigGroupExists
    $Found | Add-Member -MemberType NoteProperty -Name "Log Group" -Value $ServerLogGroup
    $Found | Add-Member -MemberType NoteProperty -Name "L.Exists?" -Value $ServerLogGroupExists
    $Export += $Found
    
    # Define Business Line
    if ($Prefix -eq "dv") {
        $BusinessLine = "DataVerify"
        $DeploymentAccount = "svcDVDeploy." + $Environment
        $MaintAccount = "svc_dvRundeckMaint_p"
        $OnSiteDevProdAccessGroup = "DataVerify_Dev_Prod_Server_Access"
        $OnSiteDevTier1AccessGroup = "DataVerify_Dev_Tier1_Server_Access"
        $OffShoreDevProdAccessGroup = "DataVerify_Dev_OffShore_Prod_Server_Access"
        $OffShoreDevTier1AccessGroup = "DataVerify_Dev_OffShore_Tier1_Server_Access"
        $DV_FS_FileshareAccessGroup = "appfs.dv." + $Environment + ".dv_fs_" + $Environment + ".modify"
        $DV_Shared_FileshareAccessGroup = "appfs.dv." + $Environment + ".dv_shared_" + $Environment + ".modify"
    }
    elseif ($Prefix -eq "ib") {
        $BusinessLine = "Ibbie"
    }
    else {
        $msg = "Cannot proceed! Business Line has not been defined! Please update code."
        echo $msg
        LogWrite $msg
        break
    }
    echo " "
    echo "Server: $target"
    $msg = "Business Line: $BusinessLine"
    echo $msg
    LogWrite $msg
    $msg = "Server Type: $ServerType"
    echo $msg
    LogWrite $msg
    $msg = "Environment: $Environment"
    echo $msg
    LogWrite $msg

    # Stop script if the service account exists in one place and not the other
    if (($SecretServerAccountExists -eq $true) -and ($IISaccountExists -eq $false)) {
        $msg = "Cannot proceed! The Account already exists in Secret Server, but not in AD! Please review and fix."
        echo $msg
        LogWrite $msg
        break
    }
    if (($SecretServerAccountExists -eq $false) -and ($IISaccountExists -eq $true)) {
        $msg = "Cannot proceed! The Account already exists in AD, but not in Secret Server! Please review and fix."
        echo $msg
        LogWrite $msg
        break
    }

    # Create Account in AD and Secret Server if neither exists
    if (($SecretServerAccountExists -eq $false) -and ($IISaccountExists -eq $false)) {

        # Define Service Accounts OU based on Business Line and Environment
        $OUPath = "OU=$($Environment.ToUpper()),OU=$BusinessLine,OU=Service Accounts,DC=cbc,DC=local"

        # Check if OU exists before proceeding
        $OUExists = [bool] (Get-ADOrganizationalUnit $OUPath)
        
        if ($OUExists -eq $true) {
            
            $msg = "Calling function to Create Service Account in Secret Server..."
            echo $msg
            LogWrite $msg

            # Use Secret Server to generate a password while adding the new secret
            $AccountPassword = CreateSecret $SecretServerAccount $BusinessLine $Environment

            # Convert password to a secure string for AD Account creation
            $SSpassword = $AccountPassword | ConvertTo-SecureString -asPlainText -Force

            $msg = "Creating Service Account in Active Directory..."
            echo $msg
            LogWrite $msg

            # Create AD Account if OU exists
            $UPN = "$SecretServerAccount@cbc.local"
            New-ADUser -Name $SecretServerAccount -DisplayName $SecretServerAccount -SamAccountName $SecretServerAccount -UserPrincipalName $UPN -Path $OUPath -Enabled $true -CannotChangePassword $true -PasswordNeverExpires $true -AccountPassword $SSpassword
            $msg = "$SecretServerAccount was created in AD and Secret Server"
            $ExportCreatedLog += "`n$msg"
            LogWrite $msg
        }
        else {
            $msg = "The OU does not exist! Please create the OU for $BusinessLine under Service Accounts, then try again!"
            echo $msg
            LogWrite $msg
            break
        }
    } # End of Create Account in AD and Secret Server

    # Define Groups OU based on Business Line
    $GroupOUPath = "OU=$BusinessLine,OU=Groups,DC=cbc,DC=local"
    # Check if OU exists
    $GroupOUExists = [bool] (Get-ADOrganizationalUnit $GroupOUPath)
    if ($GroupOUExists -eq $true) {
        # Create Groups if they do not exist
        if ($ServerConfigGroupExists -eq $false) {
            New-ADGroup -Name $ServerConfigGroup -SamAccountName $ServerConfigGroup -Path $GroupOUPath -GroupCategory Security -GroupScope Global
            $msg = "$ServerConfigGroup was created"
            $ExportCreatedLog += "`n$msg"
            LogWrite $msg
        }
        if ($ServerLogGroupExists -eq $false) {
            New-ADGroup -Name $ServerLogGroup -SamAccountName $ServerLogGroup -Path $GroupOUPath -GroupCategory Security -GroupScope Global
            $msg = "$ServerLogGroup was created"
            $ExportCreatedLog += "`n$msg"
            LogWrite $msg
        }
    }
    else {
        $msg = "The OU does not exist! Please create the OU for $BusinessLine under Groups, then try again!"
        echo $msg
        LogWrite $msg
        break
    }
    
    # If Server Local Admin group exists, Add service account as member if it's not already a member
    if ($ServerLocalAdminGroupExists -eq $true) {
        $ServerLocalAdminGroupMembership = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $SecretServerAccount}
        if ($ServerLocalAdminGroupMembership -eq $null) {
            Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $SecretServerAccount
            $msg = "$SecretServerAccount was added to $ServerLocalAdminGroup"
            $ExportCreatedLog += "`n$msg"
            LogWrite $msg
        }
        # Add LogOnTo Permissions for Service Account (if already in place)
        $Workstations = (Get-ADUser $SecretServerAccount -Properties LogonWorkstations).LogonWorkstations
        if ($Workstations -ne $null) {
            $Workstations += ",$target"
            Set-ADUser $SecretServerAccount -LogonWorkstations $Workstations
        }
        # Group membership based on Business Line
        if ($BusinessLine -eq "DataVerify") {
            # Add Deployment Account as member
            $ServerLocalAdminGroupMembership_Deploy = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $DeploymentAccount}
            if ($ServerLocalAdminGroupMembership_Deploy -eq $null) {
                Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $DeploymentAccount
                $msg = "$DeploymentAccount was added to $ServerLocalAdminGroup"
                $ExportCreatedLog += "`n$msg"
                LogWrite $msg
            }
            # Add LogOnTo Permissions for Deployment Account (if already in place)
            $Workstations = (Get-ADUser $DeploymentAccount -Properties LogonWorkstations).LogonWorkstations
            if ($Workstations -ne $null) {
                $Workstations += ",$target"
                Set-ADUser $DeploymentAccount -LogonWorkstations $Workstations
            }
            # If Prod, Add specific accounts
            if ($Environment -eq "prod") {
                # Add Maintenance Account
                $ServerLocalAdminGroupMembership_Maint = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $MaintAccount}
                if ($ServerLocalAdminGroupMembership_Maint -eq $null) {
                    Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $MaintAccount
                    $msg = "$MaintAccount was added to $ServerLocalAdminGroup"
                    $ExportCreatedLog += "`n$msg"
                    LogWrite $msg
                }
                # Add LogOnTo Permissions for Maintenance Account (if already in place)
                $Workstations = (Get-ADUser $MaintAccount -Properties LogonWorkstations).LogonWorkstations
                if ($Workstations -ne $null) {
                    $Workstations += ",$target"
                    Set-ADUser $MaintAccount -LogonWorkstations $Workstations
                }
                # Add Prod Server Access Group
                $ServerLocalAdminGroupMembership_ProdAccess = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $OnSiteDevProdAccessGroup}
                if ($ServerLocalAdminGroupMembership_ProdAccess -eq $null) {
                    Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $OnSiteDevProdAccessGroup
                    $msg = "$OnSiteDevProdAccessGroup was added to $ServerLocalAdminGroup"
                    $ExportCreatedLog += "`n$msg"
                    LogWrite $msg
                }
            }
            elseif ($Environment -eq "uat") {
                # UAT - Add On-site Dev Prod Server Access Group
                $ServerLocalAdminGroupMembership_ProdAccess = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $OnSiteDevProdAccessGroup}
                if ($ServerLocalAdminGroupMembership_ProdAccess -eq $null) {
                    Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $OnSiteDevProdAccessGroup
                    $msg = "$OnSiteDevProdAccessGroup was added to $ServerLocalAdminGroup"
                    $ExportCreatedLog += "`n$msg"
                    LogWrite $msg
                }
                # UAT - Add OffShore Dev Prod Server Access Group
                $ServerLocalAdminGroupMembership_OffShoreProdAccess = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $OffShoreDevProdAccessGroup}
                if ($ServerLocalAdminGroupMembership_OffShoreProdAccess -eq $null) {
                    Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $OffShoreDevProdAccessGroup
                    $msg = "$OffShoreDevProdAccessGroup was added to $ServerLocalAdminGroup"
                    $ExportCreatedLog += "`n$msg"
                    LogWrite $msg
                }
            }
            else {
                # DEV/QA - Add On-site Dev Tier1 Access Group
                $ServerLocalAdminGroupMembership_Tier1Access = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $OnSiteDevTier1AccessGroup}
                if ($ServerLocalAdminGroupMembership_Tier1Access -eq $null) {
                    Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $OnSiteDevTier1AccessGroup
                    $msg = "$OnSiteDevTier1AccessGroup was added to $ServerLocalAdminGroup"
                    $ExportCreatedLog += "`n$msg"
                    LogWrite $msg
                }
                # DEV/QA - Add OffShore Dev Tier1 Access Group
                $ServerLocalAdminGroupMembership_OffShoreTier1Access = Get-ADGroupMember -Identity $ServerLocalAdminGroup | ? {$_.SamAccountName -eq $OffShoreDevTier1AccessGroup}
                if ($ServerLocalAdminGroupMembership_OffShoreTier1Access -eq $null) {
                    Add-ADGroupMember -Identity $ServerLocalAdminGroup -Members $OffShoreDevTier1AccessGroup
                    $msg = "$OffShoreDevTier1AccessGroup was added to $ServerLocalAdminGroup"
                    $ExportCreatedLog += "`n$msg"
                    LogWrite $msg
                }
            }
        }
    }
    # Group membership based on Business Line
    if ($BusinessLine -eq "DataVerify") {
        # Add service account to DV_FS file share modify group
        $ServerLocalAdminGroupMembership_DVFSFileShareAccess = Get-ADGroupMember -Identity $DV_FS_FileshareAccessGroup | ? {$_.SamAccountName -eq $SecretServerAccount}
        if ($ServerLocalAdminGroupMembership_DVFSFileShareAccess -eq $null) {
            Add-ADGroupMember -Identity $DV_FS_FileshareAccessGroup -Members $SecretServerAccount
            $msg = "$SecretServerAccount was added to $DV_FS_FileshareAccessGroup"
            $ExportCreatedLog += "`n$msg"
            LogWrite $msg
        }
        # Add service account to DV_Shared file share modify group
        $ServerLocalAdminGroupMembership_DVShardFileShareAccess = Get-ADGroupMember -Identity $DV_Shared_FileshareAccessGroup | ? {$_.SamAccountName -eq $SecretServerAccount}
        if ($ServerLocalAdminGroupMembership_DVSharedFileShareAccess -eq $null) {
            Add-ADGroupMember -Identity $DV_Shared_FileshareAccessGroup -Members $SecretServerAccount
            $msg = "$SecretServerAccount was added to $DV_Shared_FileshareAccessGroup"
            $ExportCreatedLog += "`n$msg"
            LogWrite $msg
        }
    }
    $ExportCreatedLog += "`n"
}

# Output results
$TimeStamp = (Get-Date).ToString("yyyyMMdd_HH-mm-ss")
$Export | Export-Csv "$LogPath\Environment-Prep_BeforeChanges_$TimeStamp.csv" -NoTypeInformation
$ExportCreatedLog | Out-File "$LogPath\Log_ChangeSummary_$TimeStamp.txt"