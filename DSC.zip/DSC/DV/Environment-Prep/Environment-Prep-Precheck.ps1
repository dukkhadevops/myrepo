﻿########
# Author:               John Basso / Matt Keller
# Description:          Environment Preparation based on list of server names.
#                       Parses server name to determine environment and server type.
#                       Checks for missing service accounts and groups in AD groups, and account credentials in Secret Server in preparation for DSC deployment
#                       Read computers.txt from a working path variable
#                       Output results to screen
# Changes:              10/22/2019      Initial creation
#                       10/30/2019      Added AD and Secret Server check for accounts/groups
########

######## ASSUMPTIONS
# This script assumes a specific naming convention applies to server names
# Server Naming Convention Format: Root Name|Number|Location|Support Team|Type|Enviroment
# First two letters are the prefix for the business line
# The letters following the prefix and before the numbers are the type of server as it applies to the business line
# The number does not have an impact
# The letters following the number include the Location, Support Team, Type and Enviroment
########

# Read list of computers for environment
$WorkingPath = "C:\GIT\DSC\DV\Environment-Prep"
$computers = Get-Content -Path "$WorkingPath\computers.txt"
# Exit script if the list is empty
if ($computers -eq $null) {
    echo "`ncomputers.txt is empty!"
    exit
}

# Report variable
$Export = @()

#region for grabbing Secrets from SecretServer

$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users

#if you're using TLS1.2 instead of 1.0, you need this
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# function that takes in a search term, finds the SecretServer ID, then uses the ID to return the password for that Secret.
Function GetSecret ($searchterm){

    #initial setup of webservice proxy using the url we set
    $proxy = New-WebServiceProxy $url -UseDefaultCredential

    #try to authenticate using the user, pass and domain we provided. this is the login to SecretServer
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0) {
            $result1.Errors[0]
            break
    } 
    else {
            #save our login session token into $token
            $token = $result1.Token
    }

    #use search term to find the ID of the Secret 
    $result2 = $proxy.SearchSecrets($token, $searchterm, $null, $null)
    if ($result2.Errors.length -gt 0) {
            $result2.Errors[0]
    }
    elseif ($result2.SecretSummaries.length -eq 0) {
            $secretname = $false
    }
    else {
        #Search each result found for an exact match
        $result2.SecretSummaries | ForEach-Object {
            If ($_.SecretName -eq $searchterm) {
                $secretname = $_.SecretName
                $secretId = $_.SecretID
            }
        }
        #use the SecretID that was an exact match to retrieve the password
        $result3 = $proxy.GetSecret($token, $secretId, $false, $null)
        #return the password
        $return = $result3.Secret.Items[2].Value
    }

    #return the username
    $return2 = $secretname
    Return $return2
}
#endregion

#for each computer target in our computers.txt file
Foreach ($target in $computers) {

    #region Parse Server Name into variables

    # Example $target
    # $target = "dvweb02uwwl"
    # Parses string one character at a time
    # $target.ToCharArray()
    # Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
    $targetarray = $target -Split '(\d\d)'
    # Read the first string, which is the Root Name for the server
    $RootName = $targetarray[0]
    # Read the second string, which is the double digit number in the server name
    $Number = $targetarray[1]
    # Read the third string, which includes Location/Support Team/Type/Environment
    $Details = $targetarray[2]
    # Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
    $Prefix = $RootName[0,1] -join ''
    $Prefix = $($Prefix.ToLower())
    # Read the Root Name, starting after the second character (web from dvweb)
    $ServerType = $RootName.Substring(2)
    $ServerType = $($ServerType.ToLower())
    # Read last character for Environment
    $Environment = $Details.Substring($Details.Length-1)
    # Update Environment variable
    switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
<#
    Write-Host "Server information based on name:
    Root Name: $RootName
    Number: $Number
    Details: $Details
    Prefix: $Prefix
    Server Type: $ServerType
    Server Type in Upper Case is: $($ServerType.ToUpper())
    Environment: $Environment
    Environment in Upper Case is: $($Environment.ToUpper())
    Environment Initial Letter is: $($Environment[0])
    "
#>
    # The type of server will define the needs through flag variables
    # Currently not using these flags
    switch ($ServerType){
        "app"{$FlagAPP = $true}
        "bp"{$FlagBP = $true}
        "batch"{$FlagBATCH = $true}
        "fnma"{$FlagFNMA = $true}
        "gw"{$FlagGW = $true}
        "inapi"{$FlagINAPI = $true}
        "inet"{$FlagINET = $true}
        "intgw"{$FlagINTGW = $true}
        "mrtk"{$FlagMRTK = $true}
        "pdf"{$FlagPDF = $true}
        "score"{$FlagSCORE = $true}
        "svc"{$FlagSVC = $true}
        "task"{$FlagTASK = $true}
        "taskapi"{$FlagTASKAPI = $true}
        "web"{$FlagWEB = $true}
    }
    #endregion

    # Define service account and AD group names
    $ServerLocalAdminGroup = $target + "_admin"
    $ServerConfigGroup = $Prefix + ".serverconf." + $Environment
    $ServerLogGroup = $Prefix + ".serverlog." + $Environment
    $IISaccount = "world\svc_" + $Prefix + $ServerType + "_" + $($Environment[0])
    $SecretServerAccount = $IISaccount.Replace("world\","")

    # Check for existence of AD groups, service account and Secret Server credentials
    $ServerLocalAdminGroupExists = [bool] (Get-ADGroup -Filter { SamAccountName -eq $ServerLocalAdminGroup })
    $ServerConfigGroupExists = [bool] (Get-ADGroup -Filter { SamAccountName -eq $ServerConfigGroup })
    $ServerLogGroupExists = [bool] (Get-ADGroup -Filter { SamAccountName -eq $ServerLogGroup })
    $IISaccountExists = [bool] (Get-ADUser -Filter { SamAccountName -eq $SecretServerAccount })
    $SecretServerAccountExists = [bool] (GetSecret $SecretServerAccount)

    # Store results
    $Found = New-Object PSObject
    $Found | Add-Member -MemberType NoteProperty -Name "Server Name" -Value $target
    $Found | Add-Member -MemberType NoteProperty -Name "Service Acct" -Value $SecretServerAccount
    $Found | Add-Member -MemberType NoteProperty -Name "Acct in AD?" -Value $IISaccountExists
    $Found | Add-Member -MemberType NoteProperty -Name "Acct in SS?" -Value $SecretServerAccountExists
    $Found | Add-Member -MemberType NoteProperty -Name "Admin Group" -Value $ServerLocalAdminGroup
    $Found | Add-Member -MemberType NoteProperty -Name "A.Exists?" -Value $ServerLocalAdminGroupExists
    $Found | Add-Member -MemberType NoteProperty -Name "Config Group" -Value $ServerConfigGroup
    $Found | Add-Member -MemberType NoteProperty -Name "C.Exists?" -Value $ServerConfigGroupExists
    $Found | Add-Member -MemberType NoteProperty -Name "Log Group" -Value $ServerLogGroup
    $Found | Add-Member -MemberType NoteProperty -Name "L.Exists?" -Value $ServerLogGroupExists
    $Export += $Found
}

# Output results
$Export | Out-GridView