########
# Author:       Matt Keller / John Basso
# Description:  Powershell DSC to configure Windows Features & setup files/folders for Servers to be used in conjunction with other Servers
# Changes:      10/29/2019      Initial creation
#
########

########
#ASSUMPTION: You are copying this script out to the server then executing it from there
########

Set-ExecutionPolicy Unrestricted -Force

# Read computer name
$target = $env:computername

#region Parse Server Name into variables
# Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
$targetarray = $target -Split '(\d\d)'
# Read the first string, which is the Root Name for the server
$RootName = $targetarray[0]
# Read the second string, which is the double digit number in the server name
$Number = $targetarray[1]
# Read the third string, which includes Location/Support Team/Type/Environment
$Details = $targetarray[2]
$ServerLocation = $($Details[0])
# Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
$Prefix = $RootName[0,1] -join ''
$Prefix = $($Prefix.ToLower())
# Read the Root Name, starting after the second character (web from dvweb)
$ServerType = $RootName.Substring(2)
$ServerType = $($ServerType.ToLower())
# Read last character for Environment
$Environment = $Details.Substring($Details.Length-1)
# Update Environment variable
switch ($Environment){
    "l"{$Environment = "lab"}
    "d"{$Environment = "dev"}
    "q"{$Environment = "qa"}
    "u"{$Environment = "uat"}
    "p"{$Environment = "prod"}
}
#endregion

$IISaccount = "world\svc_" + $Prefix + $ServerType + "_" + $($Environment[0])

# Define Business Line
if ($Prefix -eq "dv") {
    $BusinessLine = "DataVerify"
}
else {
    $msg = "Cannot proceed! Business Line has not been defined! Please update code."
    echo $msg
    break
}

#region Set up Server Type variables

# Initialize Server Type Flags
$FlagAPP = $false
$FlagBP = $false
$FlagBATCH = $false
$FlagFNMA = $false
$FlagGW = $false
$FlagINAPI = $false
$FlagINET = $false
$FlagINTGW = $false
$FlagMRTK = $false
$FlagPDF = $false
$FlagSCORE = $false
$FlagSVC = $false
$FlagTASK = $false
$FlagTASKAPI = $false
$FlagWEB = $false
$FlagDynatraceConfig = $false

switch ($ServerType){
        "app"{
            $FlagAPP = $true
            $FlagDynatraceConfig = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 4 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "bp"{
            $FlagBP = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
            )
        }
        "batch"{
            $FlagBATCH = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "FNMABatch"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "fnma"{
            $FlagFNMA = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "FNMABatch"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "gw"{
            $FlagGW = $true
            $FlagDynatraceConfig = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "FinicityListener"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "FNMAService"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "inapi"{
            $FlagINAPI = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "DVAuth"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "EarlyWarning"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "Finicity"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "IV"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
                @{ AppPool = "LOSXMLAPI"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "ReportAPI"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "UDM"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "VIEBroker"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "VOEI"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
            )
        }
        "inet"{
            $FlagINET = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "intranet"; AppPoolIdentity = $IISaccount; AppPoolMWP = 6 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "intgw"{
            $FlagINTGW = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "InternalGatewayServer"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
            )
        }
        <#"mrtk"{
            $FlagMRTK = $true
        }#>
        "pdf"{
            $FlagPDF = $true
            $FlagDynatraceConfig = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 6 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "score"{
            $FlagSCORE = $true
            $FlagDynatraceConfig = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
            )
        }
        "svc"{
            $FlagSVC = $true
        }
        "task"{
            $FlagTASK = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount ; AppPoolMWP = 2}
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
            )
        }
        "taskapi"{
            $FlagTASKAPI = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "DataVerify.PSTask.API"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "DataVerifyTaskAPI"; AppPoolIdentity = $IISaccount; AppPoolMWP = 8 }
            )
        }
        "web"{
            $FlagWEB = $true
            $FlagDynatraceConfig = $true
            $appPools = @(
                @{ AppPool = "$BusinessLine"; AppPoolIdentity = $IISaccount ; AppPoolMWP = 2}
                @{ AppPool = "AutomatedReferral"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
                @{ AppPool = "dvweb"; AppPoolIdentity = $IISaccount; AppPoolMWP = 6 }
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount; AppPoolMWP = 1 }
                @{ AppPool = "sso"; AppPoolIdentity = $IISaccount; AppPoolMWP = 2 }
            )
        }
}
#endregion

#variable that holds our config name since we'll be calling it up here and then all the way at the bottom.
$DSCconfigName = "DSC-" + $($ServerType.ToUpper()) + "-" + $($Environment.ToUpper())
# these are used for access to the shares
$SMBshareReadAccess = $Prefix + ".serverlog." + $Environment
$SMBshareChangeAccess = $Prefix + ".serverconf." + $Environment

#these are all the default pools we'll be deleting
$defaultAppPools = @(
		"DefaultAppPool",
		".NET v4.5",
		".NET v4.5 Classic"
	)

#create our configuration with the "Configuration" keyword.
#note the resources we're importing here. they must be included in the 1st scripts copy job
#also note the WebAdministration module. this should be installed by default on 2012 & up servers but not 2008 R2 etc.

Configuration $DSCconfigName {
    Import-Module WebAdministration
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName cNtfsAccessControl
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName ComputerManagementDsc											

    Node $env:computername {

        #disclaimer
        #do not reorder these sections, they build off one another

        ########
        #region Basic File & Folder section
        ########

        $PathApp = "c:\app"
        $PathAppCerts = "c:\app\certs"
        $PathAppConf = "c:\app\conf"
        $PathAppLog = "c:\app\log"
        $PathAppRequestLogs = "c:\app\requestlogs"
        $PathAppXML = "c:\app\xml"
        $PathIISLogs = "c:\inetpub\logs"
        $PathTasks = "c:\ScheduledTasks"
        $PathServices = "c:\WindowsServices"
        $PathWWW = "c:\www"


        File appDir #c:\app
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $PathApp
        }

        if (($FlagAPP -eq $true) -or ($FlagBP -eq $true) -or ($FlagGW -eq $true) -or ($FlagPDF -eq $true) -or ($FlagWEB -eq $true)) {
            File certsDir #c:\app\certs
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathAppCerts
                DependsOn = "[File]appDir"
            }
        }

        File confDir #c:\app\conf
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $PathAppConf
            DependsOn = "[File]appDir"
        }

        File logDir #c:\app\log
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $PathAppLog
            DependsOn = "[File]appDir"
        }

        if (($FlagAPP -eq $true) -or ($FlagBP -eq $true) -or ($FlagGW -eq $true) -or ($FlagPDF -eq $true) -or ($FlagWEB -eq $true)) {
            File RequestLogsDir #c:\app\requestlogs
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathAppRequestLogs
                DependsOn = "[File]appDir"
            }
        }

        if (($FlagAPP -eq $true) -or ($FlagBP -eq $true) -or ($FlagGW -eq $true) -or ($FlagINET -eq $true) -or ($FlagINTGW -eq $true) -or ($FlagPDF -eq $true) -or ($FlagTASK -eq $true) -or ($FlagWEB -eq $true)) {
            File xmlDir #c:\app\xml
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathAppXML
                DependsOn = "[File]appDir"
            }
        }

        if ($FlagTASK -eq $true) {
            File ScheduledTasksDir #c:\ScheduledTasks
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathTasks
            }
        }

        if (($FlagSVC -eq $true) -or ($FlagTASK -eq $true)) {
            File WindowsServicesDir #c:\WindowsServices
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathServices
            }
        }

        File wwwDir #c:\www
        {
            Ensure = "Present"  # You can also set Ensure to "Absent"
            Type = "Directory" # Default is "File".
            DestinationPath = $PathWWW
        }
        #endregion

        ########
        #region SMBShare creation
        ########

        xSmbShare appConfShare
        {
            Ensure = "Present"
            Name   = "AppConf"
            Path = $PathAppConf
            ChangeAccess = $SMBshareChangeAccess
            ReadAccess = $SMBshareReadAccess
            Description = "App Conf share"
        }

        xSmbShare appLogShare
        {
            Ensure = "Present"
            Name   = "AppLog"
            Path = $PathAppLog
            ReadAccess = $SMBshareReadAccess
            Description = "App Log share"
        }

        if (($FlagAPP -eq $true) -or ($FlagBP -eq $true) -or ($FlagGW -eq $true) -or ($FlagINET -eq $true) -or ($FlagINTGW -eq $true) -or ($FlagPDF -eq $true) -or ($FlagTASK -eq $true) -or ($FlagWEB -eq $true)) {
            xSmbShare appXMLShare
            {
                Ensure = "Present"
                Name   = "AppXML"
                Path = $PathAppXML
                ChangeAccess = $SMBshareChangeAccess
                Description = "App XML share"
            }
        }

        xSmbShare IISLogShare
        {
            Ensure = "Present"
            Name   = "IISLogs"
            Path = $PathIISLogs
            ReadAccess = $SMBshareReadAccess
            Description = "IIS Log share"
        }
        #endregion

        ########
        #region IIS Logging Resources
        ########

        #Get-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter "system.applicationHost/sites/siteDefaults/logFile" -name "logExtFileFlags"
        #Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter "system.applicationHost/sites/siteDefaults/logFile" -name "logExtFileFlags" -value "Date,Time,ClientIP,UserName,ServerIP,Method,UriStem,UriQuery,HttpStatus,Win32Status,BytesSent,BytesRecv,TimeTaken,ServerPort,UserAgent,Referer,ProtocolVersion,Host,HttpSubStatus"
        #Add-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter "system.applicationHost/sites/siteDefaults/logFile/customFields" -name "." -value @{logFieldName='X-Forwarded-For';sourceName='X-Forwarded-For';sourceType='RequestHeader'}

        xIISLogging IISLogging
        {
            LogPath = "%SystemDrive%\inetpub\logs\LogFiles"
            Logflags = @('Date', 'Time', 'ClientIP', 'UserName', 'ServerIP', 'ServerPort', 'Method', 'UriStem', 'UriQuery', 'HttpStatus', 'HttpSubStatus', 'Win32Status', 'BytesSent', 'BytesRecv', 'TimeTaken', 'ProtocolVersion', 'Host', 'UserAgent', 'Referer')
            LogTargetW3C = 'File'
            LogPeriod = 'Daily'
            LogFormat = 'W3C'
            LogCustomFields = @(
                MSFT_xLogCustomField
                {
                LogFieldName   = 'X-Forwarded-For'
                SourceType     = 'RequestHeader'
                SourceName     = 'X-Forwarded-For'
                }
            )
        }

        #endregion

        ########
        #region Registry Resources
        ########

        <# Syntax for Registry Resource
        Registry [string] #ResourceName
        {
            Key = [string]
            ValueName = [string]
            [ Force =  [bool]   ]
            [ Hex = [bool] ]
            [ ValueData = [string[]] ]
            [ ValueType = [string] { Binary | Dword | ExpandString | MultiString | Qword | String }  ]
            [ DependsOn = [string[]] ]
            [ Ensure = [string] { Present | Absent }  ]
            [ PsDscRunAsCredential = [PSCredential] ]
        }
        #>

        # Disable Internet Explorer Enhanced Security Configuration (ESC) - For Administrators and Users
        # This can be done Server Manager > Local Server
        # There are two Registry values to change from 1 to 0 (for Admins and Users)
        # To implement the change without logging off/rebooting, iesetup.dll needs to be called

        <# This process will disable IE ESC without logging off/rebooting
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" -Name "IsInstalled" -Value 0
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}" -Name "IsInstalled" -Value 0
        Rundll32 iesetup.dll, IEHardenLMSettings
        Rundll32 iesetup.dll, IEHardenUser
        Rundll32 iesetup.dll, IEHardenAdmin
        Write-Host "IE Enhanced Security Configuration (ESC) has been disabled."
        #>

        # IE ESC for Administrators
        Registry Disable-IE-ESC-Admin
        {
            Ensure      = "Present"
            Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
            ValueName   = "IsInstalled"
            ValueData   = "0"
        }

        # IE ESC for Users
        Registry Disable-IE-ESC-User
        {
            Ensure      = "Present"
            Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
            ValueName   = "IsInstalled"
            ValueData   = "0"
        }

        # Remove Registry Entry for IPv4 over IPv6 preference - this allows localhost to respond as ::1 instead of 127.0.0.1
        # New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisabledComponents" -Value 0x20
        # Remove-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisabledComponents"

        Registry DeleteIPv4Preference
        {
            Ensure      = "Absent"
            Key         = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters"
            ValueName   = "DisabledComponents"
            ValueData   = "0x20"
        }

        # If Dynatrace is installed, set Registry values for .Net Agent configuration, based on location/type/environment
        # Variable values needed are Agent Name, Command Line, Server and Port. The other values will be static.
        # Per AppMon team
        # Dynatrace collectors should be split up evenly
        # Odd servers pointing to 01 Collectors and Even servers pointing to 02 Collectors, with agents using Port 9997 and 9998 on each Collector
        # if($_ % 2 -eq 1 ) {"$_ is odd"}
        # if($_ % 2 -eq 0 ) {"$_ is even"}

        if ($FlagDynatraceConfig -eq $true) {
            # Define Collector server and port
            # ODD Servers
            if($Number % 2 -eq 1) {
                if (($ServerLocation -eq "m") -and ($Environment -eq "prod")) {
                    $DynatraceIntServer = "dvcollect01mwap.cbc.local" # Internal ML Prod Collector ODD
                    $DynatraceDMZServer = "dvdtz01mwap.cbc.local" # DMZ ML Prod Collector ODD
                }
                if (($ServerLocation -eq "u") -and ($Environment -eq "prod")) {
                    $DynatraceIntServer = "dvcollect01uwap.cbc.local" # Internal UA Prod Collector ODD
                    $DynatraceDMZServer = "dvdtz01uwap.cbc.local" # DMZ UA Prod Collector ODD
                }
                if (($ServerLocation -eq "u") -and ($Environment -eq "uat")) {
                    $DynatraceIntServer = "dtcollect01uwaq.cbc.local" # Internal UAT Collector ODD
                    $DynatraceDMZServer = "cbcdv-dt03ap.cbc.local" # DMZ UAT Collector ODD
                }
            }
            # EVEN Servers
            if($Number % 2 -eq 0) {
                if (($ServerLocation -eq "m") -and ($Environment -eq "prod")) {
                    $DynatraceIntServer = "dvcollect02mwap.cbc.local" # Internal ML Prod Collector EVEN
                    $DynatraceDMZServer = "dvdtz02mwap.cbc.local" # DMZ ML Prod Collector EVEN
                }
                if (($ServerLocation -eq "u") -and ($Environment -eq "prod")) {
                    $DynatraceIntServer = "dvcollect02uwap.cbc.local" # Internal UA Prod Collector EVEN
                    $DynatraceDMZServer = "dvdtz02uwap.cbc.local" # DMZ UA Prod Collector EVEN
                }
                if (($ServerLocation -eq "u") -and ($Environment -eq "uat")) {
                    $DynatraceIntServer = "dtcollect02uwaq.cbc.local" # Internal UAT Collector EVEN
                    $DynatraceDMZServer = "cbc-dt04ap.cbc.local" # DMZ UAT Collector EVEN
                }
            }
            # Define Agent Name/Port per Environment
            # UAT
            if (($ServerLocation -eq "u") -and ($Environment -eq "uat")) {
                switch ($ServerType){
                    "app" {
                        $DynatraceAgentName = "dv-dvapp"
                        $DynatraceServer = $DynatraceIntServer
                        $DynatracePort = "9997"
                    }
                    "gw" {
                        $DynatraceAgentName = "dv-gateway"
                        $DynatraceServer = $DynatraceDMZServer
                        $DynatracePort = "9998"
                    }
                    "pdf" {
                        $DynatraceAgentName = "dv-pdf"
                        $DynatraceServer = $DynatraceIntServer
                        $DynatracePort = "9998"
                    }
                    "web" {
                        $DynatraceAgentName = "Web_Tier"
                        $DynatraceServer = $DynatraceDMZServer
                        $DynatracePort = "9998"
                    }
                }
            }
            # UA PROD
            if (($ServerLocation -eq "u") -and ($Environment -eq "prod")) {
                switch ($ServerType){
                    "app" {
                        $DynatraceAgentName = "Application-DVWeb"
                        $DynatraceServer = $DynatraceIntServer
                        $DynatracePort = "9997"
                    }
                    "gw" {
                        $DynatraceAgentName = "Gateway-DVWeb"
                        $DynatraceServer = $DynatraceDMZServer
                        $DynatracePort = "9997"
                    }
                    "pdf" {
                        $DynatraceAgentName = "PDFGEN-DVWeb"
                        $DynatraceServer = $DynatraceIntServer
                        $DynatracePort = "9998"
                    }
                    "web" {
                        $DynatraceAgentName = "Web_Tier"
                        $DynatraceServer = $DynatraceDMZServer
                        $DynatracePort = "9998"
                    }
                }
            }
            # ML PROD
            if (($ServerLocation -eq "m") -and ($Environment -eq "prod")) {
                switch ($ServerType){
                    "app" {
                        $DynatraceAgentName = "Application-DVWeb"
                        $DynatraceServer = $DynatraceIntServer
                        $DynatracePort = "9997"
                    }
                    "gw" {
                        $DynatraceAgentName = "Gateway-DV"
                        $DynatraceServer = $DynatraceDMZServer
                        $DynatracePort = "9997"
                    }
                    "pdf" {
                        $DynatraceAgentName = "PDFGEN-DVWeb"
                        $DynatraceServer = $DynatraceIntServer
                        $DynatracePort = "9998"
                    }
                    "web" {
                        $DynatraceAgentName = "Web_Tier"
                        $DynatraceServer = $DynatraceDMZServer
                        $DynatracePort = "9998"
                    }
                }
            }
            # Define Registry Resource for each app pool
            $DynatraceIndexCount = 0
            foreach($webapp in $appPools) {
                if ($webapp.AppPool -ne "lbmonitor") {
                    $DynatraceIndexCount++
                    $appName = $webapp.appPool
                    $DynatraceCommandLine = "-ap `"$appName`""
                    Registry "DynatraceActive-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "active"
                        ValueData   = "True"
                    }
                    Registry "DynatraceName-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "name"
                        ValueData   = $DynatraceAgentName
                    }
                    Registry "DynatracePath-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "path"
                        ValueData   = "C:\WINDOWS\SysWOW64\inetsrv"
                    }
                    Registry "DynatraceExec-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "exec"
                        ValueData   = "w3wp.exe"
                    }
                    Registry "DynatraceLogFile-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "logfile"
                        ValueData   = ""
                    }
                    Registry "DynatraceLogLevelCon-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "loglevelcon"
                        ValueData   = "LOG_INFO"
                    }
                    Registry "DynatraceLogLevelFile-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "loglevelfile"
                        ValueData   = "LOG_INFO"
                    }
                    Registry "DynatraceServer-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "server"
                        ValueData   = $DynatraceServer
                    }
                    Registry "DynatracePort-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "port"
                        ValueData   = $DynatracePort
                    }
                    Registry "DynatraceCmdLine-$appName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "cmdline"
                        ValueData   = $DynatraceCommandLine
                    }
                } #endif
            }
        }
        #endregion

        ########
        #region Windows Roles & Features section. These should all be relatively in order based on how they appear when you do a get-windowsfeature -name *web*
        ########

        WindowsFeature Web-Server  # Web Server (IIS) base/root feature
        {
               Name = "Web-Server"
               Ensure = "Present"
        }

        WindowsFeature Web-WebServer  # Web Server continued (IIS) parent featureset
        {
               Name = "Web-WebServer"
               Ensure = "Present"
        }

        WindowsFeature Web-Common-Http  # Common Http Features parent featureset
        {
               Name = "Web-Common-Http"
               Ensure = "Present"
        }

        WindowsFeature Web-Default-Doc  # Default Document
        {
               Name = "Web-Default-Doc"
               Ensure = "Present"
        }

        WindowsFeature Web-Dir-Browsing  # Directory Browsing
        {
               Name = "Web-Dir-Browsing"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Errors  # Http Errors
        {
               Name = "Web-Http-Errors"
               Ensure = "Present"
        }

        WindowsFeature Web-Static-Content  # Static Content
        {
               Name = "Web-Static-Content"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Redirect  # Http redirection
        {
               Name = "Web-Http-Redirect"
               Ensure = "Present"
        }

        WindowsFeature Web-Health # Health and Diagnostics parent featureset
        {
               Name = "Web-Health"
               Ensure = "Present"
        }

        WindowsFeature Web-Http-Logging # Http Logging
        {
               Name = "Web-Http-Logging"
               Ensure = "Present"
        }

        WindowsFeature Web-Request-Monitor # Request Monitor
        {
               Name = "Web-Request-Monitor"
               Ensure = "Present"
        }
        
        WindowsFeature Web-Http-Tracing  # Tracing
        {
               Name = "Web-Http-Tracing"
               Ensure = "Present"
        }

        WindowsFeature Web-Performance  # Performance parent featureset
        {
               Name = "Web-Performance"
               Ensure = "Present"
        }

        WindowsFeature Web-Stat-Compression  # Static Content Compression
        {
               Name = "Web-Stat-Compression"
               Ensure = "Present"
        }

        WindowsFeature Web-Security  # Security parent featureset
        {
               Name = "Web-Security"
               Ensure = "Present"
        }

        WindowsFeature Web-Filtering  # Request Filtering
        {
               Name = "Web-Filtering"
               Ensure = "Present"
        }

        WindowsFeature Web-App-Dev  # Application Development parent featureset
        {
               Name = "Web-App-Dev"
               Ensure = "Present"
        }

        WindowsFeature Web-Net-Ext45  # .NET Extensibility 4.5
        {
             Name = "Web-Net-Ext"
             Ensure = "Present"
        }

        WindowsFeature Web-AppInit  # Application Initialization
        {
             Name = "Web-AppInit"
             Ensure = "Present"
        }

        WindowsFeature Web-Asp-Net45  # ASP.NET 4.5
        {
             Name = "Web-Asp-Net45"
             Ensure = "Present"
        }

        WindowsFeature Web-ISAPI-Ext  # ISAPI Extensions
        {
             Name = "Web-ISAPI-Ext"
             Ensure = "Present"
        }

        WindowsFeature Web-ISAPI-Filter  # ISAPI Filters
        {
             Name = "Web-ISAPI-Filter"
             Ensure = "Present"
        }

        WindowsFeature Web-Mgmt-Tools  # Management Tools parent featureset
        {
             Name = "Web-Mgmt-Tools"
             Ensure = "Present"
        }

        WindowsFeature Web-Mgmt-Console  # IIS Management Console
        {
             Name = "Web-Mgmt-Console"
             Ensure = "Present"
        }
        #endregion
        
        ########
        #region NON IIS Windows Features section
        ########
        WindowsFeature Net-Framework-Features  # .Net Framework 3.5 Features parent featureset
        {
             Name = "Net-Framework-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-Core  # .Net Framework 3.5 (.NET 2.0 and 3.0)
        {
             Name = "Net-Framework-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Features  # .Net Framework 4.5 Features parent featureset
        {
             Name = "Net-Framework-45-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Core  # .Net Framework 4.5
        {
             Name = "Net-Framework-45-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-ASPNET  # ASP.NET 4.5
        {
             Name = "Net-Framework-45-ASPNET"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-Services45  # WCF Services
        {
             Name = "Net-WCF-Services45"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-TCP-PortSharing45  # TCP Port Sharing
        {
             Name = "Net-Framework-Core"
             Ensure = "Present"
        }

        WindowsFeature RDC #Remote Differential Compression
        {
             Name = "RDC"
             Ensure = "Present"
        }

        WindowsFeature SNMP-Service #SNMP Service Parent
        {
            Name = "SNMP-Service"
            Ensure = "Present"
        }

        WindowsFeature Telnet-Client #Telnet Client
        {
            Name = "Telnet-Client"
            Ensure = "Present"
        }

        WindowsFeature PowershellRoot #Windows Powershell parent featureset
        {
            Name = "PowershellRoot"
            Ensure = "Present"
        }

        WindowsFeature Powershell #Windows Powershell
        {
            Name = "Powershell"
            Ensure = "Present"
        }

        WindowsFeature Powershell-ISE #Powershell ISE
        {
            Name = "Powershell-ISE"
            Ensure = "Present"
        }
        #endregion

        ########
        #region App Pool creation section
        ########

        #setup site folder structure & permissions
        foreach($pool in $appPools)
        {
            #if the app pool name equals $BusinessLine then create the base site folder
            If ($pool.appPool -eq "$BusinessLine") {
                $poolName = $pool.AppPool
                $permissionname = $poolname + "permissions"
                $identity = $pool.AppPoolIdentity

                File $poolName #setup site directory
                {
                    Ensure = "Present"  # You can also set Ensure to "Absent"
                    Type = "Directory" # Default is "File".
                    DestinationPath = "C:\www\$poolName"
                }
			}
            #else if the app pool name does not equal $BusinessLine, create a subfolder within the base folder
            Else {
                $poolName = $pool.AppPool
                $permissionname = $poolname + "permissions"
                $identity = $pool.AppPoolIdentity

                if (($BusinessLine -eq "DataVerify") -and ($poolName -eq "sso")) {
                    File "$poolName-content" #setup subfolder to site directory
                    {
                        Ensure = "Present"  # You can also set Ensure to "Absent"
                        Type = "Directory" # Default is "File".
                        DestinationPath = "C:\www\$BusinessLine\content"
                    }
                    File $poolName #setup subfolder to site directory
                    {
                        Ensure = "Present"  # You can also set Ensure to "Absent"
                        Type = "Directory" # Default is "File".
                        DestinationPath = "C:\www\$BusinessLine\content\$poolName"
                        DependsOn = "[File]$poolName-content"
                    }
                }
                else {
                    File $poolName #setup subfolder to site directory
                    {
                        Ensure = "Present"  # You can also set Ensure to "Absent"
                        Type = "Directory" # Default is "File".
                        DestinationPath = "C:\www\$BusinessLine\$poolName"
                    }
                }
            }
        }

        #create each app pool with particular properties
        foreach($pool in $appPools) {
            $poolName = $pool.AppPool
            if ($Environment -eq "prod") {
                $mwp = $pool.AppPoolMWP
            }
            elseif ($poolName -eq "lbmonitor") {
                $mwp = 1
            }
            else {
                $mwp = 2
            }
            # ODD Servers Recycle Time
            if($Number % 2 -eq 1) {
                $restartSched = "05:00:00"
            }
            # EVEN Servers Recycle Time
            if($Number % 2 -eq 0) {
                $restartSched = "05:30:00"
            }
            xWebAppPool "$poolName-Configure" {
                Name = $pool.AppPool
                Ensure = "Present"
                State = "Started"
                autoStart = $true
                startMode = "AlwaysRunning"
                idleTimeout = "00:00:00"
                queueLength = 4000
                maxProcesses = $mwp
                enable32BitAppOnWin64 = $true
				restartTimeLimit = "00:00:00"
                restartSchedule = $restartSched
            }

        #end foreach
        }

        #delete each app pool in defaultapppools
        foreach($pool in $defaultAppPools) {
            xWebAppPool "$pool-Delete" {
                Name = $pool
                Ensure = "Absent"
            }
        }
        #endregion

        ########
        #region Site creation section
        ########

        #setup each site
        #specify the base site name, destination and app pool names you want (make sure the app pool is still setup with app pool section)
        $sitename = "$BusinessLine"
        $sitedestination = "C:\www\$BusinessLine"
        $basesiteapppool = "$BusinessLine"
        #using an existing cert created during OSD
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My -DnsName "$env:computername.cbc.local" -eku "Server Authentication*"

        if ($FlagPDF -eq $true) {
            xWebsite $sitename
            {
                Ensure          = "Present"
                Name            = $sitename
                State           = "Started"
                PreloadEnabled  = $true
                PhysicalPath    = $sitedestination
                ApplicationPool = $basesiteapppool
                BindingInfo = 
                        @(
                            MSFT_xWebBindingInformation 
                            {
                                Protocol = "http"
                                Port = "80"
                                IPAddress = "*"
                                CertificateThumbprint = $cert.thumbprint
                                CertificateStoreName  = "My"
                            }
                        )
            }
        }
        else {
            xWebsite $sitename
            {
                Ensure          = "Present"
                Name            = $sitename
                State           = "Started"
                PreloadEnabled  = $true
                PhysicalPath    = $sitedestination
                ApplicationPool = $basesiteapppool
                BindingInfo = 
                        @(
                            MSFT_xWebBindingInformation 
                            {
                                Protocol = "https"
                                Port = "443"
                                IPAddress = "*"
                                CertificateThumbprint = $cert.thumbprint
                                CertificateStoreName  = "My"
                            }
                            # For HTTP
                            <# MSFT_xWebBindingInformation 
                            {
                                Protocol = "http"
                                Port = "80"
                                IPAddress = "*"
                            }
                            #>
                        )
            }
        }

        # Create each Application
        foreach($webapp in $appPools) {

            If ($webapp.appPool -ne "$BusinessLine") {

                #grab the correct name from the appPool array above & set a unique destination for each
                $webappname = $webapp.AppPool
                $webappdestination = $sitedestination + "\" + $webappname

                if (($BusinessLine -eq "DataVerify") -and ($webappname -eq "sso")) {
                # Application setup for SSO, which is in the content subfolder
                    xWebApplication $webappname
                    {
                        Website = $sitename
                        Ensure = "Present"
                        Name = "content/" + $webappname
                        PhysicalPath = $sitedestination + "\content\" + $webappname
                        WebAppPool = $webappname
                        AuthenticationInfo = MSFT_xWebApplicationAuthenticationInformation
                        {
                            Anonymous = $true
                            Basic     = $false
                            Digest    = $false
                            Windows   = $false
                        }
                        PreloadEnabled = $true
                        EnabledProtocols = @("http")

                        DependsOn = "[xWebsite]$sitename"
                    }
                }
                else {
                # Application setup for all apps in site folder
                    xWebApplication $webappname
                    {
                        Website = $sitename
                        Ensure = "Present"
                        Name = $webappname
                        PhysicalPath = $webappdestination
                        WebAppPool = $webappname
                        AuthenticationInfo = MSFT_xWebApplicationAuthenticationInformation
                        {
                            Anonymous = $true
                            Basic     = $false
                            Digest    = $false
                            Windows   = $false
                        }
                        PreloadEnabled = $true
                        EnabledProtocols = @("http")

                        DependsOn = "[xWebsite]$sitename"
                    }
                }
            }
        }

        #C:\inetpub\wwwroot
        # Stop the default website then remove it
        xWebsite DefaultWebSite 
        {
            State           = "Stopped"
            Ensure          = "Absent"
            Name            = "Default Web Site"
            PhysicalPath    = "C:\inetpub\wwwroot"
        }
        #endregion

        ########
        #region URL Rewrite Allowed Server Variables
        ########
        if ($FlagWEB -eq $true) {
            Script AddAllowedServerVariables {

                #get the http response web configuration property. store the value in a hashtable with key "Result"
                GetScript = {
                    $AllowedServerVariable = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -location $BusinessLine -filter "system.webServer/rewrite/allowedServerVariables/add[@name='HTTP_HOST']" -name "."
                    $AllowedServerVariableName = $AllowedServerVariable.name
                    @{ "Result" = $AllowedServerVariableName }
                }

                #use GetScript and check the "Result" key/value pair. If the value equals "" (an empty string), return false which
                #will trigger the running of SetScript
                TestScript = {
                    $AllowedServerVariable = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -location $BusinessLine -filter "system.webServer/rewrite/allowedServerVariables/add[@name='HTTP_HOST']" -name "."
                    $AllowedServerVariableName = $AllowedServerVariable.name
                    if ($AllowedServerVariableName -eq "HTTP_HOST") {
                        Write-Verbose -Message "HTTP_HOST exists. No action is required."
                        return $true
                    }
                    else {
                        Write-Verbose -Message "HTTP_HOST does not exist, running SetScript."
                        return $false
                    }
                }

                #if TestScript returns $false, add the web configuration property for "HTTP_HOST"
                SetScript = {
                    Add-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -location $BusinessLine -filter "system.webServer/rewrite/allowedServerVariables" -name "." -AtElement @{name='HTTP_HOST'}
                }
            }
        }
        #endregion

        ########
        #region HTTP Response Headers
        ########

        Script DeleteXPoweredByHttpResponseHeader {

            #get the http response web configuration property. store the value in a hashtable with key "Result"
            GetScript = {
                $HTTPResponseHeader = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST/$BusinessLine" -filter "system.webServer/httpProtocol/customHeaders/add[@name='X-Powered-By']" -name "."
                $HTTPResponseHeaderName = $HTTPResponseHeader.name
                @{ "Result" = $HTTPResponseHeaderName }
            }

            #use GetScript and check the "Result" key/value pair. If the value equals "" (an empty string), return true. Else return false which
            #will trigger the running of SetScript
            TestScript = {
                $HTTPResponseHeader = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST/$BusinessLine" -filter "system.webServer/httpProtocol/customHeaders/add[@name='X-Powered-By']" -name "."
                $HTTPResponseHeaderName = $HTTPResponseHeader.name
                if ($HTTPResponseHeaderName -eq "X-Powered-By") {
                    Write-Verbose -Message "X-Powered-By header exists, running SetScript"
                    return $false
                }
                else {
                    Write-Verbose -Message "X-Powered-By header does not exist. No action is required."
                    return $true
                }
            }

            #if TestScript returns $false, remove the web configuration property that matches name "X-Powered-By"
            SetScript = {
                Remove-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST/$BusinessLine" -filter "system.webServer/httpProtocol/customHeaders" -name "." -AtElement @{name='X-Powered-By'}
            }
        }
        #endregion
        
        ########
        #region lbmonitor page deploy
        ########
        <#
        $lbmonitorCheck = ($appPools.AppPool | ?{$_ -eq "lbmonitor"}).Count
        if ($lbmonitorCheck -eq 1) {
            $lbmonitorsourcepath = "\\dfs\nas\DV_Shared\WebApp Deploy\lbmonitor\*"
            $lbmonitordestpath = "C:\www\$sitename\lbmonitor"
            if (!(Test-Path -path $lbmonitordestpath)) {
                New-Item $lbmonitordestpath -Type Directory
            }
            Copy-Item -Path $lbmonitorsourcepath -Recurse -Force -Destination $lbmonitordestpath -ErrorAction Stop
		}
        #>
        #endregion

		########
        #region Local Configuration Manager
        ########

        #all the settings we want for the Local Configuration Manager (LCM)
        #24hrs in a day X 60mins an hour = 1440mins
        LocalConfigurationManager
        {
            ConfigurationModeFrequencyMins = 1440
            ConfigurationMode = "ApplyAndMonitor"
            RefreshMode = "Push"
            RebootNodeIfNeeded = $false
            AllowModuleOverwrite = $true
        }
        #endregion

		#end node
    }

#end configuration
}

#call the configuration we specified above which will compile it down into a .mof
#use "&" to call the variable/name of the configuration. the alternative is just specifying the whole name not in a variable like...
&$DSCconfigName -OutputPath C:\dsc-mof\$DSCconfigName
########
#region pre-config-run stuffs 
#delete IIS stuffs
########

#remove all sites
remove-website -name *

#remove all app pools
Get-ChildItem -Path IIS:\AppPools\ | ForEach-Object { Remove-WebAppPool $_.Name }

#cleanup folders?

#endregion

#cleanup is finished so now lets trigger the config
#start the configuration using the same path we just specified where the .mof is
Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\$DSCconfigName -Wait -ErrorAction Stop -Force -Verbose

#apply LCM settings
Set-DscLocalConfigurationManager -Path C:\dsc-mof\$DSCconfigName