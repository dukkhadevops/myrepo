########
# Author:       Matt Keller / John Basso
# Description:  Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:      10/29/2019      Initial creation
#
########
# $destPSModulepath should construct to = either C:\Program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

# Read list of computers for deployment
$computers = Get-Content -Path "C:\GIT\DSC\DV\V2\computers.txt"
# Exit script if the list is empty
if ($computers -eq $null) {
    echo "`ncomputers.txt is empty!"
    exit
}
else {
    Write-Host "`nDid you make sure to update the computers.txt file with the correct server names?" -ForegroundColor Yellow
    Write-Host "`nDid you run the Environment Precheck to confirm the service accounts are in place?" -ForegroundColor Yellow
    Read-Host "`nPress Enter to Continue" | Out-Null
}

#full path where we are pulling the DSC scripts from
$localdscscriptpath1 = "C:\GIT\DSC\DV\V2\2-DSC-DV-V2.ps1"
$localdscscriptpath2 = "C:\GIT\DSC\DV\V2\3-DSC-DV-V2-Final.ps1"

echo " "
echo " "
echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
echo " "
echo " "
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    #region Parse Server Name into variables
    # Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
    $targetarray = $target -Split '(\d\d)'
    # Read the first string, which is the Root Name for the server
    $RootName = $targetarray[0]
    # Read the second string, which is the double digit number in the server name
    $Number = $targetarray[1]
    # Read the third string, which includes Location/Support Team/Type/Environment
    $Details = $targetarray[2]
    $ServerLocation = $($Details[0])
    # Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
    $Prefix = $RootName[0,1] -join ''
    $Prefix = $($Prefix.ToLower())
    # Read the Root Name, starting after the second character (web from dvweb)
    $ServerType = $RootName.Substring(2)
    $ServerType = $($ServerType.ToLower())
    # Read last character for Environment
    $Environment = $Details.Substring($Details.Length-1)
    # Update Environment variable
    switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
    #endregion

    $SVCaccount = "svc_" + $Prefix + $ServerType + "_" + $($Environment[0])
        
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #where we are copying our required powershell modules
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"

    #full path to where we are copying the DSC scripts from/to
    $localfilepath1 = $localpath + "\2-DSC-V2.ps1"
    $localfilepath2 = $localpath + "\3-DSC-V2-Final.ps1"
    $destfilepath1 = $destpath + "\2-DSC-V2.ps1"
    $destfilepath2 = $destpath + "\3-DSC-V2-Final.ps1"
    
    #region Install Variables

    #7zip Install Path
    $7zipInstallPath = "\\fs\pub\collab\winsoftware\7zip\7z1900-x64.exe"

    #Debenu Quick PDF .dlls Install variables#
    $Debenufilesharepath = "\\dfs\nas\DV_Shared\WebApp Deploy\Debenu QuickPDF\DebenuPDFLibraryAX1112.dll"
    $Debenulocalpath = "C:\scripts\DebenuPDFLibraryAX1112.dll"

    #Dynatrace Install variables#
    $InstallDynatrace_modulepath = "C:\GIT\Scripts\DV\InstallDynatrace\InstallDynatrace.psm1"

    #Mailroom Toolkit Install variables#
    $InstallMailroomToolkit_modulepath = "C:\GIT\Scripts\DV\InstallMailroomToolkit\InstallMailroomToolkit.psm1"

    #NetGender Install Path
    $NetGenderInstallPath = "\\dfs\NAS\DV_Shared\WebApp Deploy\NetGender\Netgender35\NetGender35.msi"

    #RadPdf Install Path
    $RadPdfInstallPath = "\\dfs\NAS\DV_Shared\WebApp Deploy\RadPdf\RadPdfInstaller2.19.exe"

    #SOSS Client Install variables#
    $InstallSOSSClient_modulepath = "C:\Git\Scripts\DV\InstallSOSSClient\InstallSOSSClient.psm1"

    #URL Rewrite Module Install Path
    $URLrewriteInstallPath = "\\dfs\NAS\DV_Shared\WebApp Deploy\URLrewrite\URL_Rewrite_amd64.msi"

    #Certificate Install Modules
    $DataverifyCOMCertInstall_modulepath = "C:\GIT\Scripts\DV\DataverifyCOMCertInstall\DataverifyCOMCertInstall.psm1"
    $TALXCertInstall_modulepath = "C:\GIT\Scripts\DV\TALXCertInstall\TALXCertInstall.psm1"
    $TUNACertInstall_modulepath = "C:\GIT\Scripts\DV\TUNACertInstall\TUNACertInstall.psm1"
    $ThawteCertInstall_modulepath = "C:\GIT\Scripts\DV\ThawteCertInstall\ThawteCertInstall.psm1"

    #endregion

    #region Set up Server Type Flags

    # Initialize Server Type Flags
    $Flag7zip = $false
    $FlagDebenu = $false
    $FlagDynatrace = $false
    $FlagDynatraceIISmodule = $false
    $FlagMRTKfull = $false
    $FlagMRTKcom = $false
    $FlagNetGender = $false
    $FlagRadPdf = $false
    $FlagSOSSclient = $false
    $FlagURLrewrite = $false
    $FlagCertDataverifyCOM = $false
    $FlagCertTALX = $false
    $FlagCertTUNA = $false
    $FlagCertThawte = $false

    switch ($ServerType){
        "app"{
            $FlagDynatrace = $true
            $FlagMRTKfull = $true
            $FlagNetGender = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "bp"{
            $Flag7zip = $true
            $FlagMRTKfull = $true
            $FlagNetGender = $true
            $FlagCertTUNA = $true
        }
        "batch"{
            # No Flags
        }
        "fnma"{
            # No Flags
        }
        "gw"{
            $FlagDynatrace = $true
            $FlagMRTKcom = $true
            $FlagNetGender = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "inapi"{
            $FlagCertTALX = $true
            $FlagCertThawte = $true
        }
        "inet"{
            $FlagRadPdf = $true
            $FlagSOSSclient = $true # Do not set unless client license is available
            $FlagCertDataverifyCOM = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "intgw"{
            $FlagDebenu = $true
            $FlagMRTKfull = $true
            $FlagNetGender = $true
        }
        "mrtk"{
            $FlagMRTKfull = $true
        }
        "pdf"{
            $FlagDebenu = $true
            $FlagDynatrace = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "score"{
            $FlagMRTKcom = $true
        }
        "svc"{
            # No Flags
        }
        "task"{
            $FlagCertTUNA = $true
        }
        "taskapi"{
            $FlagMRTKcom = $true
            $FlagNetGender = $true
            $FlagCertDataverifyCOM = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "web"{
            $FlagDynatrace = $true
            $FlagDynatraceIISmodule = $true # Need INI Config
            $FlagMRTKcom = $true
            $FlagNetGender = $true
            $FlagSOSSclient = $true # Do not set unless client license is available
            $FlagURLrewrite = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
    }
    #endregion

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose) {

        # Start PSSession with $target computer
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
            If (!(test-path $destpath)) {
                Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
            }
            echo " "
            echo "c:\scripts exists or was created on $target"
        }
        Catch {
            echo "failed creating c:\scripts on $target"
            break
        }
        #endregion

        #region copy DSC script out to hosts
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -Force -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath2 -Destination $destfilepath2 -Force -ErrorAction Stop
            echo "DSC script copies okay on $target"
        }
        Catch {
                echo "failed copying DSC scripts on $target"
                break
        }
        #endregion

        #region DSC modules & resources for use. Copy them to the Powershell Modules folder.
        Try {
            Copy-Item -Path "C:\Git\DSC\Modules\xWebAdministration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xWebAdministration module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\cNtfsAccessControl" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "cNtfsAccessControl module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\xSmbShare" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xSmbShare module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\ComputerManagementDsc" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "ComputerManagementDSC module copy okay on $target"
        }
        Catch {
              echo "copy of DSC modules to powershell directory failed on $target"
              break
        }
        #endregion

        #region Disable Internet Explorer Enhanced Security Configuration (ESC) - For Administrators and Users
        # This can be done Server Manager > Local Server
        # There are two Registry values to change from 1 to 0 (for Admins and Users)
        # To implement the change without logging off/rebooting, iesetup.dll needs to be called
        Try {
            Invoke-Command -ComputerName $target -ScriptBlock {
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" -Name "IsInstalled" -Value 0
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}" -Name "IsInstalled" -Value 0
                Rundll32 iesetup.dll, IEHardenLMSettings
                Rundll32 iesetup.dll, IEHardenUser
                Rundll32 iesetup.dll, IEHardenAdmin
            }
            echo "IE Enhanced Security Configuration (ESC) has been disabled on $target."
        }
        Catch {
            echo "Failed to disable IE Enhanced Security Configuration (ESC) on $target."
            break
        }
        #endregion

        # Quick pause for C:\scripts folder creation
        Start-Sleep -Seconds 3

        #region install 7zip
        if ($Flag7zip -eq $true) {
            # Confirm 7zip does not exist before installing
            if (!(Test-Path "\\$target\c$\Program Files\7-Zip\7z.exe")) {
                echo "Installing 7zip..."
                Copy-Item -Path $7zipInstallPath -Destination $destpath -ErrorAction Stop
                Invoke-Command -ComputerName $target -ScriptBlock {cmd /c "C:\scripts\7z1900-x64.exe /S"} -ErrorAction Stop
            }
            else {
                echo "7zip already exists"
            }
        }
        #endregion

        #region install NetGender
        if ($FlagNetGender -eq $true) {
            # Confirm NetGender does not exist before installing
            if (!(Test-Path "\\$target\c$\Program Files (x86)\The Software Company\NetGender 3.5\NetGender.dll")) {
                echo "Installing NetGender..."
                Copy-Item -Path $NetGenderInstallPath -Destination $destpath -ErrorAction Stop
                Invoke-Command -ComputerName $target -ScriptBlock {Start-Process -Filepath msiexec "/i C:\scripts\NetGender35.msi /qn" -Wait} -ErrorAction Stop
            }
            else {
                echo "NetGender already exists"
            }
        }
        #endregion

        #region install RadPdf
        if ($FlagRadPdf -eq $true) {
            # Confirm RadPdf does not exist before installing
            if (!(Test-Path "\\$target\c$\Program Files\RAD PDF\Service\RadPdfService.exe")) {
                echo "Installing RadPdf..."
                Copy-Item -Path $RadPdfInstallPath -Destination $destpath -ErrorAction Stop
                Invoke-Command -ComputerName $target -ScriptBlock {cmd /c "C:\scripts\RadPdfInstaller2.19.exe /quiet"} -ErrorAction Stop
            }
            else {
                echo "RadPdf already exists"
            }
        }
        #endregion

        #region install MailroomToolkit using InstallMailroomToolkit.psm1
        if ($FlagMRTKfull -eq $true) {
            $MRTK_installtype = "Full"
        }
        if ($FlagMRTKcom -eq $true) {
            $MRTK_installtype = "COM"
        }
        if (($FlagMRTKfull -eq $true) -or ($FlagMRTKcom -eq $true)) {
            Import-Module -Name $InstallMailroomToolkit_modulepath -Verbose
            InstallMailroomToolkit $target $MRTK_installtype
        }
        #endregion

        #region install SOSS client
        if ($FlagSOSSclient -eq $true) {
            Import-Module -Name $InstallSOSSClient_modulepath -Verbose
            if ($Environment -eq "prod") {
                if ($ServerLocation -eq "u") {
                    InstallSOSSClient $target "PRODUA"
                }
                if ($ServerLocation -eq "m") {
                    InstallSOSSClient $target "PRODML"
                }
            }
            else {
                InstallSOSSClient $target $Environment
            }
        }
        #endregion

        #region install IIS feature remotely first, then trigger reboot if needed
        echo "starting IIS feature install. This takes a couple minutes the very first time. Should be faster on subsequent runs"
        $windowsfeature1 = Get-WindowsFeature -ComputerName $target -Name Web-Server
        $windowsfeature2 = Get-WindowsFeature -ComputerName $target -Name Web-Mgmt-Console

        If ($windowsfeature1.Installed) {
            echo "IIS already installed"
        }
        Else {
            Install-WindowsFeature -Name Web-Server -ComputerName $target -ErrorAction Stop -Verbose
            echo "IIS installed"
        }

        If ($windowsfeature2.Installed) {
            echo "Web MGT Console already installed"
        }
        Else {
            Install-WindowsFeature -Name Web-Mgmt-Console -ComputerName $target -ErrorAction Stop -Verbose
            echo "Web MGT Console installed"
        }

        #if either $windowsfeature1 or $windowsfeature2 are false, reboot server to take effect then wait for server to come back online
        If (-Not ($windowsfeature1.Installed -OR $windowsfeature2.Installed)) {
            echo "At least one of IIS or Web MGT Console were not installed so lets reboot"
            Restart-Computer -ComputerName $target -Wait -For PowerShell -Timeout 300 -Delay 10 -Force
            # recreate session after reboot (the reboot will break the existing session)
            Remove-PSSession $session
            $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        }
        Else {
            echo "Both windows features were already installed so no reboot required"
        }
        #endregion

        #region install URL Rewrite Module
        if ($FlagURLrewrite -eq $true) {
            # Confirm URL Rewrite Module does not exist before installing
            if (!(Test-Path "C:\Windows\System32\inetsrv\rewrite.dll")) {
                echo "Installing URL Rewrite Module..."
                Copy-Item -Path $URLrewriteInstallPath -Destination $destpath -ErrorAction Stop
                Invoke-Command -ComputerName $target -ScriptBlock {Start-Process -Filepath msiexec "/i C:\scripts\URL_Rewrite_amd64.msi /qn" -Wait} -ErrorAction Stop
            }
            else {
                echo "URL Rewrite Module already exists"
            }
        }
        #endregion

        #region install Dynatrace using InstallDynatrace.psm1
        if ((($FlagDynatrace -eq $true) -and ($Environment -eq "prod")) -or (($FlagDynatrace -eq $true) -and ($Environment -eq "uat"))) {
            Import-Module -Name $InstallDynatrace_modulepath -Verbose
            InstallDynatrace $target $FlagDynatraceIISmodule
        }
        #endregion

        #region install & register Debenu Quick PDF
        if ($FlagDebenu -eq $true) {
            Try {
                Copy-Item -Path $DebenuFilesharepath -Destination $destpath -Force -ErrorAction Stop
                echo "Debenu.dll copy okay on $target"
            }    
            Catch {
                echo "failed copying Debenu to $target"
                break
            }
            Try {
                Invoke-Command -Session $session -ScriptBlock {param($Debenulocalpath) regsvr32 /s $Debenulocalpath} -ArgumentList $Debenulocalpath
                echo "Registered Debenu.dll..."
            }
            Catch {
                echo "failed registering Debenu.dll on $target"
                break
            }
        }
        #endregion

        #region install certificates
        if ($FlagCertDataverifyCOM -eq $true) {
            Import-Module -Name $DataverifyCOMCertInstall_modulepath -Verbose
            DataverifyCOMCertInstall $target $SVCaccount
        }
        if ($FlagCertTALX -eq $true) {
            if ($Environment -eq "prod") {
                $TALX_Env = "prod"
            }
            Else {
                $TALX_Env = "test"
            }
            Import-Module -Name $TALXCertInstall_modulepath -Verbose
            TALXCertInstall $target $SVCaccount $TALX_Env
        }
        if ($FlagCertTUNA -eq $true) {
            Import-Module -Name $TUNACertInstall_modulepath -Verbose
            TUNACertInstall $target $SVCaccount
        }
        if ($FlagCertThawte -eq $true) {
            Import-Module -Name $ThawteCertInstall_modulepath -Verbose
            ThawteCertInstall $target
        }
        #endregion

        #region start #2 script
        Try {
            echo " "
            echo "starting #2 DSC script run. This compiles the script into a .mof and runs the entire script. Its slow on first run but should be faster on subsequent runs"

            #invoke command to execute a ps1 script with $p6 parameter($p6 is the path argument for the script being called). -Argumentlist specifies $p6 parameter becomes $localfilepath1
            Invoke-Command -Session $session -scriptblock {
                param($p6) . $p6
                Remove-Item $p6
            } -ArgumentList $localfilepath1 -ErrorAction Stop
            echo " "
            echo "#2 DSC script finished running."
        }
        Catch {
            echo " "
            echo "#2 DSC script failed. try running it locally first"
            break
        }
        #endregion

        #region start #3 script
        Try {
            echo " "
            echo "starting #3 script run. This script is just assigning app pool identities for the most part so it should be fast."

            #invoke command to execute a ps1 script with $p7 parameter($p7 is the path argument for the script being called). -Argumentlist specifies $p7 parameter becomes $localfilepath2
            Invoke-Command -Session $session -scriptblock {
                param($p7) . $p7
                Remove-Item $p7
            } -ArgumentList $localfilepath2 -ErrorAction Stop
            echo " "
            echo "#3 script finished running."
        }
        Catch {
            echo " "
            echo "#3 script failed. try running it locally first"
            break
        }
        #endregion

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }
    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
    Remove-PSSession $session
}
# To clear leftover session if script fails
Remove-PSSession $session