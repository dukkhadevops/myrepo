########
# Author:       Matt Keller / John Basso
# Description:  Creates C:\scripts and copies DSC modules out to the server before DSC configs are executed
# Changes:      10/29/2019      Initial creation
#
########
# $destPSModulepath should construct to = either C:\Program Files\WindowsPowerShell\Modules or C:\Windows\system32\WindowsPowershell\v1.0\Modules

# Read list of computers for deployment
$computers = Get-Content -Path "C:\GIT\DSC\ibbie\V2\computers.txt"
# Exit script if the list is empty
if ($computers -eq $null){echo "`ncomputers.txt is empty!";exit}

#full path where we are pulling the DSC scripts from
$localdscscriptpath1 = "C:\GIT\DSC\ibbie\V2\2-DSC-V2.ps1"
$localdscscriptpath2 = "C:\GIT\DSC\ibbie\V2\3-DSC-V2-Final.ps1"

echo " "
echo " "
echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
echo " "
echo " "
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
#region Parse Server Name into variables
# Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
$targetarray = $target -Split '(\d\d)'
# Read the first string, which is the Root Name for the server
$RootName = $targetarray[0]
# Read the second string, which is the double digit number in the server name
$Number = $targetarray[1]
# Read the third string, which includes Location/Support Team/Type/Environment
$Details = $targetarray[2]
# Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
$Prefix = $RootName[0,1] -join ''
$Prefix = $($Prefix.ToLower())
# Read the Root Name, starting after the second character (web from dvweb)
$ServerType = $RootName.Substring(2)
$ServerType = $($ServerType.ToLower())
# Read last character for Environment
$Environment = $Details.Substring($Details.Length-1)
# Update Environment variable
switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
#endregion

#region Set up Server Type variables

# Initialize Server Type Flags
#flagDynatrace is for the dynatrace base install in script 1
#flagdynatraceiismodule is for enabling the iis modules in script 1 (only web servers in DV)
#flagdynatraceconfig is for setting up the registry entries for configuring .net agent in script 2 (all servers in DV)
$FlagADMIN = $false
$FlagASSETS = $false
$FlagINTEG = $false
$FlagRVPROXY = $false
$FlagWEB = $false
$FlagWIDGET = $false
$FlagIIS = $false
$FlagDynatrace = $false
$FlagDynatraceIISmodule = $false

if ($target -eq "dvweb01uwwl"){
    $ServerType = "web"
}

switch ($ServerType){
        "admin"{
            $FlagADMIN = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "admin"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "admin-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "assets"{
            $FlagASSETS = $true
            $FlagIIS = $true
            $sitePools = @(
                @{ AppPool = "assets"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "assets-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "integ"{
            $FlagINTEG = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "integ"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "integ-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "rvproxy"{
            $FlagRVPROXY = $true
            $FlagNginx = $true
        }
        "web"{
            $FlagWEB = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $FlagDynatraceIISmodule = $false
            $sitePools = @(
                @{ AppPool = "web"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "web-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "widget"{
            $FlagWIDGET = $true
            $FlagIIS = $true
            $sitePools = @(
                @{ AppPool = "widget"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "widget-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
}

#endregion
        
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #where we are copying our required powershell modules
    $destPSModulepath = "\\" + $target + "\c$\Program Files\WindowsPowerShell\Modules"

    #full path to where we are copying the DSC scripts from/to
    $localfilepath1 = $localpath + "\2-DSC-V2.ps1"
    $localfilepath2 = $localpath + "\3-DSC-V2-Final.ps1"
    $destfilepath1 = $destpath + "\2-DSC-V2.ps1"
    $destfilepath2 = $destpath + "\3-DSC-V2-Final.ps1"

    #Dynatrace Install variables
    $InstallDynatrace_modulepath = "C:\GIT\Scripts\IB\InstallDynatrace\InstallDynatrace.psm1"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose) {

        # Start PSSession with $target computer
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
        }
        Catch {
                echo "failed creating c:\scripts on $target"
                break
        }
        #endregion

        #region copy DSC script out to hosts
        Try {
            Copy-Item -Path $localdscscriptpath1 -Destination $destfilepath1 -Force -ErrorAction Stop
            Copy-Item -Path $localdscscriptpath2 -Destination $destfilepath2 -Force -ErrorAction Stop
            echo "DSC script copies okay on $target"
        }
        Catch {
                echo "failed copying DSC scripts on $target"
                break
        }
        #endregion

        #region DSC modules & resources for use. Copy them to the Powershell Modules folder.
        Try {
            Copy-Item -Path "C:\Git\DSC\Modules\xWebAdministration" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xWebAdministration module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\cNtfsAccessControl" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "cNtfsAccessControl module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\xSmbShare" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "xSmbShare module copy okay on $target"

            Copy-Item -Path "C:\Git\DSC\Modules\ComputerManagementDsc" -Recurse -Force -Destination $destPSModulepath -ErrorAction Stop
            echo "ComputerManagementDSC module copy okay on $target"
        }
        Catch {
              echo "copy of DSC modules to powershell directory failed on $target"
              break
        }
        #endregion

        # Quick pause for C:\scripts folder creation
        Start-Sleep -Seconds 3

        #region install IIS feature remotely first, then trigger reboot if needed

        if ($FlagIIS -eq $true) {

            echo "starting IIS feature install. This takes a couple minutes the very first time. Should be faster on subsequent runs"
            $windowsfeature1 = Get-WindowsFeature -ComputerName $target -Name Web-Server
            $windowsfeature2 = Get-WindowsFeature -ComputerName $target -Name Web-Mgmt-Console
            $windowsfeature3 = Get-WindowsFeature -ComputerName $target -Name Bitlocker
            $windowsfeature4 = Get-WindowsFeature -ComputerName $target -Name EnhancedStorage

                    If ($windowsfeature1.Installed) {
                        echo "IIS already installed"
                    }

                    Else {
                        Install-WindowsFeature -Name Web-Server -ComputerName $target -ErrorAction Stop -Verbose
                        echo "IIS installed"
                    }

                    If ($windowsfeature2.Installed) {
                        echo "Web MGT Console already installed"
                    }

                    Else {
                        Install-WindowsFeature -Name Web-Mgmt-Console -ComputerName $target -ErrorAction Stop -Verbose
                        echo "Web MGT Console installed"
                    }

                    If ($windowsfeature3.Installed) {
                        echo "Bitlocker already installed"
                    }

                    Else {
                        Install-WindowsFeature -Name Bitlocker -ComputerName $target -ErrorAction Stop -Verbose
                        echo "Bitlocker installed"
                    }

                    If ($windowsfeature4.Installed) {
                        echo "EnhancedStorage already installed"
                    }

                    Else {
                        Install-WindowsFeature -Name EnhancedStorage -ComputerName $target -ErrorAction Stop -Verbose
                        echo "EnhancedStorage installed"
                    }

            #if either $windowsfeature1 or $windowsfeature2 are false, reboot server to take effect then wait for server to come back online
            If (-Not ($windowsfeature1.Installed -OR $windowsfeature2.Installed -OR $windowsfeature3.Installed -OR $windowsfeature4.Installed)) {
                echo "At least one of pre-req windows features were not installed so lets reboot"
                Restart-Computer -ComputerName $target -Wait -For PowerShell -Timeout 300 -Delay 10 -Force
                # recreate session after reboot (the reboot will break the existing session)
                Remove-PSSession $session
                $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
            }

            Else {
            echo "windows features were already installed so no reboot required"
            }

        #endif
        }

        #endregion

        #region install Dynatrace using InstallDynatrace.psm1
        if ($FlagDynatrace -eq $true) {
            Import-Module -Name $InstallDynatrace_modulepath -Verbose
            InstallDynatrace $target $FlagDynatraceIISmodule
        }
        #endregion

        #region install nginx
        $NGINX_AppPath = "\\fs\cbc\dept\windows\nginx-1.13.8"
        $NGINX_DestInstallPath = "\\" + $target + "\e$"
        $NGINX_testpath = $NGINX_DestInstallPath + "\nginx-1.13.8"
        $NGINX_LocalInstallPath = "E:\nginx-1.13.8"
        $sourceconfpath = "\\fs\cbc\dept\windows\nginx-1.13.8\cbc configs\ibbie.conf"
        $destconfpath = $NGINX_DestInstallPath + "\nginx-1.13.8\conf\nginx.conf"

        if ($FlagRVProxy -eq $true) {
            #test if path exists
              #if exists then do not install
              #else it does not exist
                #install
                #copy config

            If(test-path $NGINX_testpath){
                #Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $NGINX_LocalInstallPath -ErrorAction Stop
                echo " "
                echo "$NGINX_LocalInstallPath exists already on $target so no NGINX install needed"
            }
            Else{
                echo "$NGINX_LocalInstallPath does NOT exist on $target so triggering NGINX install"
                #Copy NGINX to local server         
                Copy-Item -Path $NGINX_AppPath -Recurse -Force -Destination $NGINX_DestInstallPath -ErrorAction Stop
                echo "NGINX copy okay from $NGINX_AppPath to $NGINX_DestInstallPath"
                Start-Sleep -Seconds 5
                #Copy NGINX config to local server
                Copy-Item -Path $sourceconfpath -Recurse -Force -Destination $destconfpath -ErrorAction Stop
                echo "NGINX conf copy okay on $target"
            }
            
        }

        #endregion

        #region certificates for securing website
        <#
        #1 check if cert exists in either mmc or in c:\scripts\certs
        #2 if not create cert request
        #3 get certreq fulfilled,
        #4 store the thumbprint for script #2

        Try {
            
        }

        Catch {

        }

        #copy scripts needed to generate certs
        #use -force to overwrite
        $certscript1 = "C:\git\scripts\NewCertificateSigningRequest\New-CertificateSigningRequest.ps1"
        $destcertpath = "C:\scripts\certs"
        Try {
            Copy-Item -Path $certscript1 -Destination $destcertpath -Force -ErrorAction Stop
            echo " "
            echo "cert script copy okay on $target"
        }
        Catch {
            echo "failed copying cert script on $target"
            break
        }

        Try 
        {
            echo " "
            echo "starting commands to generate cert request and fulfill it on CBCCA"

            #set location to the folder where everything is. import the module which has our function to create cert req.
            #submit the certreq to cbcca using the template we want. import the certificate into the location machine store
            Invoke-Command -Session $session -scriptblock {

                Set-Location C:\scripts\certs
                Import-Module .\New-CertificateSigningRequest.ps1
                New-CertificateSigningRequest -SubjectHost $env:computername -FilePath "c:\scripts\certs\certreq.csr" -ComputerName $env:computername
                certreq -submit -config "cbcca.cbc.local\CBCCA" -attrib "CertificateTemplate:WebServerSHA256" "C:\scripts\certs\certreq.csr" "C:\scripts\certs\cert.cer"
                Import-Certificate -CertStoreLocation Cert:\LocalMachine\My -FilePath "c:\scripts\certs\cert.cer"
            }

            echo " "
            echo "cert request fulfilled"
            echo "cleaning up cert stuffs"
            Remove-Item $destcertpath -Recurse 
            echo "c:\scripts\certs removed"
        }
        Catch
        {
            echo " "
            echo "cert request commands failed"
            break
        } 

        #>
        #endregion

        #region start #2 script
        Try {
            Start-Sleep -Seconds 30
            echo " "
            echo "starting #2 DSC script run. This compiles the script into a .mof and runs the entire script. Its slow on first run but should be faster on subsequent runs"

            #invoke command to execute a ps1 script with $p6 parameter($p6 is the path argument for the script being called). -Argumentlist specifies $p6 parameter becomes $localfilepath1
            Invoke-Command -Session $session -scriptblock {
                param($p6) . $p6
                Remove-Item $p6
            } -ArgumentList $localfilepath1 -ErrorAction Stop
            echo " "
            echo "#2 DSC script finished running."
        }
        Catch {
            echo " "
            echo "#2 DSC script failed. try running it locally first"
            Remove-PSSession $session
            break
        }
        #endregion

        #region start #3 script
        if ($FlagIIS -eq $true) {
            Try {
            <#
                echo " "
                echo "starting #3 script run. wait 30s"
                Start-Sleep -Seconds 30
                $retrycounter = 0

                while ($retrycounter -le 5){
                    echo "counter = $retrycounter"
                    $test = Test-WSMan -ComputerName $target
                    #if connection returns null then result=false. else connection returns something so $result=true
                    If ($test -eq $null){$result = $false}
                    Else {$result = $true}
                    echo "result of test = $result. If the server is up script 3 should run."
                
                    #if $result = false, increment counter, sleep
                    If ($result -eq $false) {
                        $retrycounter ++
                        echo "connection failed. counter = $retrycounter. exit when 4 or more"
                        echo "starting sleep for 30s - waiting to see if machine has rebooted yet"
                        Start-Sleep -seconds 30
                    }

                    Else {
                        echo "starting sleep for 30s"
                        Start-Sleep -Seconds 30
                        #invoke command to execute a ps1 script with $p7 parameter($p7 is the path argument for the script being called). -Argumentlist specifies $p7 parameter becomes $localfilepath2
                        Invoke-Command -Session $session -scriptblock {
                            param($p7) . $p7
                            Remove-Item $p7
                        } -ArgumentList $localfilepath2 -ErrorAction Inquire  -Verbose
                        #if test is true then set retry to 4 so it wont retry again
                        $retrycounter = 6
                        #break to exit while
                        #break
                    }
                }
                echo " "
                echo "#3 script finished running."

                #>

            echo " "
            echo "starting #3 script run. This script is just assigning app pool identities for the most part so it should be fast."

            #invoke command to execute a ps1 script with $p7 parameter($p7 is the path argument for the script being called). -Argumentlist specifies $p7 parameter becomes $localfilepath2
            Invoke-Command -Session $session -scriptblock {
                param($p7) . $p7
                Remove-Item $p7
            } -ArgumentList $localfilepath2 -ErrorAction Stop
            echo " "
            echo "#3 script finished running."

            }
            Catch {
                echo " "
                echo "#3 script failed. try running it locally first"
                break
            }
        }
        #endregion

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
    Remove-PSSession $session
}
# To clear leftover session if script fails
Remove-PSSession $session