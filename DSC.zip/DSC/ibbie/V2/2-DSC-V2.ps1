########
# Author:       Matt Keller / John Basso
# Description:  Powershell DSC to configure Windows Features & setup files/folders for Servers to be used in conjunction with other Servers
# Changes:      10/29/2019      Initial creation
#
########

########
#ASSUMPTION: You are copying this script out to the server then executing it from there
########

Set-ExecutionPolicy Unrestricted -Force

# Read computer name
$target = $env:computername

#region Parse Server Name into variables
# Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
$targetarray = $target -Split '(\d\d)'
# Read the first string, which is the Root Name for the server
$RootName = $targetarray[0]
# Read the second string, which is the double digit number in the server name
$Number = $targetarray[1]
# Read the third string, which includes Location/Support Team/Type/Environment
$Details = $targetarray[2]
$ServerLocation = $($Details[0])
# Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
$Prefix = $RootName[0,1] -join ''
$Prefix = $($Prefix.ToLower())
# Read the Root Name, starting after the second character (web from dvweb)
$ServerType = $RootName.Substring(2)
$ServerType = $($ServerType.ToLower())
# Read last character for Environment
$Environment = $Details.Substring($Details.Length-1)
# Update Environment variable
switch ($Environment){
    "l"{$Environment = "lab"}
    "d"{$Environment = "dev"}
    "q"{$Environment = "qa"}
    "u"{$Environment = "uat"}
    "p"{$Environment = "prod"}
}
#endregion

#$IISaccount = "world\svc_" + $Prefix + $ServerType + "_" + $($Environment[0])
$IISaccount = "world\svcsqlibbie_qa"

#region Set up Server Type variables

# Initialize Server Type Flags
#flagDynatrace is for the dynatrace base install in script 1
#flagdynatraceiismodule is for enabling the iis modules in script 1 (only web servers in DV)
#flagdynatraceconfig is for setting up the registry entries for configuring .net agent in script 2 (all servers in DV)
$FlagADMIN = $false
$FlagASSETS = $false
$FlagINTEG = $false
$FlagRVPROXY = $false
$FlagWEB = $false
$FlagWIDGET = $false
$FlagIIS = $false
$FlagDynatrace = $false
$FlagDynatraceIISmodule = $false

if ($target -eq "dvweb01uwwl"){
    $ServerType = "web"
}

switch ($ServerType){
        "admin"{
            $FlagADMIN = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "admin"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "admin-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "assets"{
            $FlagASSETS = $true
            $FlagIIS = $true
            $sitePools = @(
                @{ AppPool = "assets"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "assets-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "integ"{
            $FlagINTEG = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "integ"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "integ-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "rvproxy"{
            $FlagRVPROXY = $true
        }
        "web"{
            $FlagWEB = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $FlagDynatraceIISmodule = $false
            $sitePools = @(
                @{ AppPool = "web"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "web-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "widget"{
            $FlagWIDGET = $true
            $FlagIIS = $true
            $sitePools = @(
                @{ AppPool = "widget"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "widget-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
}

#endregion

#variable that holds our config name since we'll be calling it up here and then all the way at the bottom.
$DSCconfigName = "DSC-" + $($ServerType.ToUpper()) + "-" + $($Environment.ToUpper())
# these are used for access to the shares
$SMBshareReadAccess = "world\$prefix.serverlog.$Environment"
$SMBshareChangeAccess = "world\$prefix.serverconf.$Environment"

#these are all the default pools we'll be deleting
$defaultAppPools = @(
		"DefaultAppPool",
		".NET v4.5",
		".NET v4.5 Classic"
	)

#unlock section so we can apply config
if ($FlagIIS -eq $true) {
    C:\windows\system32\inetsrv\appcmd.exe unlock config -section:system.webServer/security/authentication/windowsAuthentication
}

#create our configuration with the "Configuration" keyword.
#note the resources we're importing here. they must be included in the 1st scripts copy job
#also note the WebAdministration module. this should be installed by default on 2012 & up servers but not 2008 R2 etc.

Configuration $DSCconfigName {
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName cNtfsAccessControl
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName ComputerManagementDsc
    if ($FlagIIS -eq $true){
        Import-Module WebAdministration		
    }									

    Node $env:computername {

        #disclaimer
        #do not reorder these sections, they build off one another

        ########
        #region Local Configuration Manager & Pending Reboot handling
        ########

        #all the settings we want for the Local Configuration Manager (LCM)
        #24hrs in a day X 60mins an hour = 1440mins
        LocalConfigurationManager
        {
            ConfigurationModeFrequencyMins = 1440
            ConfigurationMode = "ApplyAndMonitor"
            RefreshMode = "Push"
            ActionAfterReboot = "ContinueConfiguration"
            RebootNodeIfNeeded = $false
            AllowModuleOverwrite = $true
        }

        #from the ComputerManagementDSC resource - required to help handle the RebootIfNeeded flag above
        PendingReboot ConfigMgrReboot
        {
            Name                        = 'ConfigMgr'
            SkipComponentBasedServicing = $true
            SkipWindowsUpdate           = $true
            SkipPendingFileRename       = $true
            SkipPendingComputerRename   = $false
            SkipCcmClientSDK            = $true
        }
        #endregion

        ########
        #region Basic File & Folder section
        ########
        if ($FlagIIS -eq $true){
            $PathWWW = "e:\www"
            $PathLogs = "e:\logs"
            $PathAppLogs = "e:\logs\app"
            $PathIISLogs = "e:\logs\IISlogs"

        <#
        if (($FlagAPP = $true) -or ($FlagBP = $true) -or ($FlagGW = $true) -or ($FlagPDF = $true) -or ($FlagWEB = $true)) {
            File certsDir #c:\app\certs
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathAppCerts
                DependsOn = "[File]appDir"
            }
        }
        #>

            File wwwDir 
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathWWW
            }

            File LogsDir 
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathLogs
            }

            File AppLogsDir 
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathAppLogs
                DependsOn = "[File]LogsDir"
            }
        
            File IISLogsDir
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                DestinationPath = $PathIISLogs
                DependsOn = "[File]LogsDir"
            }

            xIisLogging IISLogs
            {
                LogPath              = $PathIISLogs
                Logflags             = @('Date', 'Time', 'ClientIP', 'UserName', 'ServerIP', 'ServerPort', 'Method', 'UriStem', 'UriQuery', 'HttpStatus', 'HttpSubStatus', 'Win32Status', 'TimeTaken', 'UserAgent', 'Referer')
                LoglocalTimeRollover = $true
                LogPeriod            = 'Daily'
                LogFormat            = 'W3C'
            }
        }
        #endregion

        ########
        #region SMBShare creation
        ########
        if ($FlagIIS -eq $true){
            xSmbShare appLogsShare
            {
                Ensure = "Present"
                Name   = "AppLog"
                Path = $PathAppLogs
                ReadAccess = $SMBshareReadAccess
                Description = "App Log share"
            }

            xSmbShare IISLogsShare
            {
                Ensure = "Present"
                Name   = "IISLogs"
                Path = $PathIISLogs
                ReadAccess = $SMBshareReadAccess
                Description = "IIS Log share"
            }
        }
        #endregion

        ########
        #region Registry Resources
        ########

        <# Syntax for Registry Resource
        Registry [string] #ResourceName
        {
            Key = [string]
            ValueName = [string]
            [ Force =  [bool]   ]
            [ Hex = [bool] ]
            [ ValueData = [string[]] ]
            [ ValueType = [string] { Binary | Dword | ExpandString | MultiString | Qword | String }  ]
            [ DependsOn = [string[]] ]
            [ Ensure = [string] { Present | Absent }  ]
            [ PsDscRunAsCredential = [PSCredential] ]
        }
        #>

        # If Dynatrace is installed, set Registry values for .Net Agent configuration, based on location/type/environment
        # Variable values needed are Agent Name, Command Line, Server and Port. The other values will be static.
        if ($FlagDynatrace -eq $true) {
            # Define Collector server and port
            if (($ServerLocation -eq "m") -and ($Environment -eq "prod")) {
                $DynatraceIntServer = "dvdr-collector4.cbc.local" # Internal ML Prod Collector
                $DynatraceDMZServer = "dvdr-collector3.cbc.local" # DMZ ML Prod Collector
                $DynatracePort = "9998"
            }
            if (($ServerLocation -eq "u") -and ($Environment -eq "prod")) {
                $DynatraceIntServer = "dvdtcol01uwap.cbc.local" # Internal UA Prod Collector
                $DynatraceDMZServer = "dvdtdmz01.cbc.local" # DMZ UA Prod Collector
                $DynatracePort = "9998"
            }
            if (($ServerLocation -eq "u") -and ($Environment -eq "qa")) {
                $DynatraceIntServer = "ibdt01uwaq.cbc.local" # Internal UAT Collector
                $DynatraceDMZServer = "ibdt01uwaq.cbc.local" # DMZ UAT Collector
                $DynatracePort = "9998"
            }
            if (($ServerLocation -eq "u") -and ($Environment -eq "lab")) {
                $DynatraceIntServer = "ibdt01uwaq.cbc.local" # Internal UAT Collector
                $DynatraceDMZServer = "ibdt01uwaq.cbc.local" # DMZ UAT Collector
                $DynatracePort = "9998"
            }
            # Define Agent Name
            switch ($ServerType){
                "admin" {
                    $DynatraceAgentName = "ibbie"
                    $DynatraceServer = "ibdt01uwaq.cbc.local"
                }
                "assets" {
                    $DynatraceAgentName = "ibbie"
                    $DynatraceServer = "ibdt01uwaq.cbc.local"
                }
                "integ" {
                    $DynatraceAgentName = "ibbie"
                    $DynatraceServer = "ibdt01uwaq.cbc.local" 
                }
                "web" {
                    $DynatraceAgentName = "ibbie"
                    $DynatraceServer = "ibdt01uwaq.cbc.local"
                }
                "widget" {
                    $DynatraceAgentName = "ibbie"
                    $DynatraceServer = "ibdt01uwaq.cbc.local"
                }
            }
            # Define Registry Resource for each app pool
            $DynatraceIndexCount = 0
            foreach($site in $sitePools) {
                #if ($webapp.AppPool -ne "lbmonitor") {
                    $DynatraceIndexCount++
                    $siteName = $site.appPool
                    $DynatraceCommandLine = "-ap `"$siteName`""
                    Registry "DynatraceActive-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "active"
                        ValueData   = "True"
                    }
                    Registry "DynatraceName-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "name"
                        ValueData   = $DynatraceAgentName
                    }
                    Registry "DynatracePath-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "path"
                        ValueData   = "C:\\WINDOWS\\SysWOW64\\inetsrv"
                    }
                    Registry "DynatraceExec-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "exec"
                        ValueData   = "w3wp.exe"
                    }
                    Registry "DynatraceLogFile-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "logfile"
                        ValueData   = ""
                    }
                    Registry "DynatraceLogLevelCon-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "loglevelcon"
                        ValueData   = "LOG_INFO"
                    }
                    Registry "DynatraceLogLevelFile-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "loglevelfile"
                        ValueData   = "LOG_INFO"
                    }
                    Registry "DynatraceServer-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "server"
                        ValueData   = $DynatraceServer
                    }
                    Registry "DynatracePort-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "port"
                        ValueData   = $DynatracePort
                    }
                    Registry "DynatraceCmdLine-$siteName"
                    {
                        Ensure      = "Present"  # You can also set Ensure to "Absent"
                        Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Dynatrace\Agent\Whitelist\$DynatraceIndexCount"
                        ValueName   = "cmdline"
                        ValueData   = $DynatraceCommandLine
                    }
                #} #endif
            }
        }
        #endregion

        ########
        #region Windows Roles & Features section. These should all be relatively in order based on how they appear when you do a get-windowsfeature -name *web*
        ########
        if ($FlagIIS -eq $true) {
            WindowsFeature Web-Server  # Web Server (IIS) base/root feature
            {
                   Name = "Web-Server"
                   Ensure = "Present"
            }

            WindowsFeature Web-WebServer  # Web Server continued (IIS) parent featureset
            {
                   Name = "Web-WebServer"
                   Ensure = "Present"
            }

            WindowsFeature Web-Common-Http  # Common Http Features parent featureset
            {
                   Name = "Web-Common-Http"
                   Ensure = "Present"
            }

            WindowsFeature Web-Default-Doc  # Default Document
            {
                   Name = "Web-Default-Doc"
                   Ensure = "Present"
            }

            WindowsFeature Web-Dir-Browsing  # Directory Browsing
            {
                   Name = "Web-Dir-Browsing"
                   Ensure = "Present"
            }

            WindowsFeature Web-Http-Errors  # Http Errors
            {
                   Name = "Web-Http-Errors"
                   Ensure = "Present"
            }

            WindowsFeature Web-Static-Content  # Static Content
            {
                   Name = "Web-Static-Content"
                   Ensure = "Present"
            }

            WindowsFeature Web-Http-Redirect  # Http redirection
            {
                   Name = "Web-Http-Redirect"
                   Ensure = "Present"
            }

            WindowsFeature Web-DAV-Publishing  # WebDAV Publishing
            {
                   Name = "Web-DAV-Publishing"
                   Ensure = "Present"
            }

            WindowsFeature Web-Health # Health and Diagnostics parent featureset
            {
                   Name = "Web-Health"
                   Ensure = "Present"
            }

            WindowsFeature Web-Http-Logging # Http Logging
            {
                   Name = "Web-Http-Logging"
                   Ensure = "Present"
            }

            WindowsFeature Web-Request-Monitor # Request Monitor
            {
               Name = "Web-Request-Monitor"
               Ensure = "Present"
            }

            WindowsFeature Web-Http-Tracing  # Tracing
            {
                   Name = "Web-Http-Tracing"
                   Ensure = "Present"
            }

            WindowsFeature Web-Performance  # Performance parent featureset
            {
                   Name = "Web-Performance"
                   Ensure = "Present"
            }

            WindowsFeature Web-Stat-Compression  # Static Content Compression
            {
                   Name = "Web-Stat-Compression"
                   Ensure = "Present"
            }

            WindowsFeature Web-Dyn-Compression  # Dynamic Content Compression
            {
                   Name = "Web-Dyn-Compression"
                   Ensure = "Present"
            }

            WindowsFeature Web-Security  # Security parent featureset
            {
                   Name = "Web-Security"
                   Ensure = "Present"
            }

            WindowsFeature Web-Filtering  # Request Filtering
            {
                   Name = "Web-Filtering"
                   Ensure = "Present"
            }

            WindowsFeature Web-Basic-Auth  # Basic Authentication
            {
                   Name = "Web-Basic-Auth"
                   Ensure = "Present"
            }

            WindowsFeature Web-Windows-Auth  # Windows Authentication
            {
                   Name = "Web-Windows-Auth"
                   Ensure = "Present"
            }

            WindowsFeature Web-IP-Security  # IP and Domain Restrictions
            {
                   Name = "Web-IP-Security"
                   Ensure = "Present"
            }

            WindowsFeature Web-App-Dev  # Application Development parent featureset
            {
                   Name = "Web-App-Dev"
                   Ensure = "Present"
            }

            WindowsFeature Web-Net-Ext45  # .NET Extensibility 4.6
            {
                 Name = "Web-Net-Ext45"
                 Ensure = "Present"
            }

            WindowsFeature Web-AppInit  # Application Initialization
            {
                 Name = "Web-AppInit"
                 Ensure = "Present"
            }

            WindowsFeature Web-Asp-Net45  # ASP.NET 4.6
            {
                 Name = "Web-Asp-Net45"
                 Ensure = "Present"
            }

            WindowsFeature Web-ISAPI-Ext  # ISAPI Extensions
            {
                 Name = "Web-ISAPI-Ext"
                 Ensure = "Present"
            }

            WindowsFeature Web-ISAPI-Filter  # ISAPI Filters
            {
                 Name = "Web-ISAPI-Filter"
                 Ensure = "Present"
            }

            WindowsFeature Web-Mgmt-Tools  # Management Tools parent featureset
            {
                 Name = "Web-Mgmt-Tools"
                 Ensure = "Present"
            }

            WindowsFeature Web-Mgmt-Console  # IIS Management Console
            {
                 Name = "Web-Mgmt-Console"
                 Ensure = "Present"
            }
        }
        #endregion
        
        ########
        #region NON IIS Windows Features section
        ########
        WindowsFeature Net-Framework-45-Features  # .Net Framework 4.5 Features parent featureset
        {
             Name = "Net-Framework-45-Features"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-Core  # .Net Framework 4.5
        {
             Name = "Net-Framework-45-Core"
             Ensure = "Present"
        }

        WindowsFeature Net-Framework-45-ASPNET  # ASP.NET 4.5
        {
             Name = "Net-Framework-45-ASPNET"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-Services45  # WCF Services
        {
             Name = "Net-WCF-Services45"
             Ensure = "Present"
        }

        WindowsFeature Net-WCF-TCP-PortSharing45  # TCP Port Sharing
        {
             Name = "Net-WCF-TCP-PortSharing45"
             Ensure = "Present"
        }

        WindowsFeature BitLocker  # BitLocker Drive Encryption
        {
             Name = "BitLocker"
             Ensure = "Present"
        }

        WindowsFeature EnhancedStorage  # Enhanced Storage
        {
             Name = "EnhancedStorage"
             Ensure = "Present"
        }

        WindowsFeature Telnet-Client #Telnet Client
        {
            Name = "Telnet-Client"
            Ensure = "Present"
        }

        WindowsFeature PowershellRoot #Windows Powershell parent featureset
        {
            Name = "PowershellRoot"
            Ensure = "Present"
        }

        WindowsFeature Powershell #Windows Powershell
        {
            Name = "Powershell"
            Ensure = "Present"
        }

        WindowsFeature Powershell-ISE #Powershell ISE
        {
            Name = "Powershell-ISE"
            Ensure = "Present"
        }

        WindowsFeature Wow64-Support #Wow64-Support
        {
            Name = "Wow64-Support"
            Ensure = "Present"
        }
        #endregion

        ########
        #region App Pool & Site creation section
        ########
        if ($FlagIIS -eq $true) {
            #setup site folder structure & permissions + setup each app pool
            $portnumber = 443

            foreach($site in $sitePools)
            {
                #identity for the server
                $identity = $site.AppPoolIdentity

                #pool, destination, site name for site 1
                $SitePoolName = $site.AppPool
                $DestinationSitePath = $PathWWW + "\" + $SitePoolName
                $sitename = $SitePoolName

                File $SitePoolName #setup site directory
                {
                    Ensure = "Present"  # You can also set Ensure to "Absent"
                    Type = "Directory" # Default is "File".
                    DestinationPath = "$DestinationSitePath"
                    DependsOn = "[File]wwwDir"
                }

                #create each app pool with particular properties
                xWebAppPool "$SitePoolName-Configure" {
                    Name = $SitePoolName
                    Ensure = "Present"
                    State = "Started"
                    autoStart = $true
				    restartTimeLimit = "00:00:00"
                    restartSchedule = ""
			    }

                #using an existing cert created during OSD
                $cert = Get-ChildItem -Path Cert:\LocalMachine\My -DnsName "$env:computername.cbc.local" -eku "Server Authentication*"
            
                xWebsite $sitename
                {
                    Ensure          = "Present"
                    Name            = $sitename
                    State           = "Started"
                    PreloadEnabled  = $true
                    PhysicalPath    = $DestinationSitePath
                    ApplicationPool = $SitePoolName
                    BindingInfo = 
                                @(
                                    MSFT_xWebBindingInformation 
                                    {
                                        Protocol = "https"
                                        Port = "$portnumber"
                                        IPAddress = "*"
                                        CertificateThumbprint = $cert.thumbprint
                                        CertificateStoreName  = "My"
                                    }
                                )
                }
                
                #now create the webapps for each site
                $AppPoolName = $AppPools.AppPool + $site.AppPool
                $AppPoolName1 = $AppPools.AppPool
                $DestinationAppPath = $DestinationSitePath + "\" + $AppPoolName

                File $AppPoolName #setup site directory
                {
                    Ensure = "Present"  # You can also set Ensure to "Absent"
                    Type = "Directory" # Default is "File".
                    DestinationPath = "$DestinationAppPath"
                }

                xWebApplication "$AppPoolName-WebApplication"
                    {
                        Website = $sitename
                        Ensure = "Present"
                        Name = $AppPoolName1
                        PhysicalPath = $DestinationAppPath
                        WebAppPool = $AppPoolName
                        AuthenticationInfo = MSFT_xWebApplicationAuthenticationInformation
                        {
                            Anonymous = $true
                            Basic     = $false
                            Digest    = $false
                            Windows   = $false
                        }
                        PreloadEnabled = $true
                        EnabledProtocols = @("http")

                        DependsOn = "[xWebsite]$sitename"
                    }

                xWebAppPool "$AppPoolName-WebAppPool" {
                    Name = $AppPoolName
                    Ensure = "Present"
                    State = "Started"
                    autoStart = $true
				    restartTimeLimit = "00:00:00"
                    restartSchedule = ""
			    }

                #now deploy lbmonitor to our folders
                $lbmonitorsourcepath = "\\dfs\nas\DV_Shared\WebApp Deploy\lbmonitor\*"
                $lbmonitordestpath = $DestinationAppPath
                if (!(Test-Path -path $lbmonitordestpath)) {New-Item $lbmonitordestpath -Type Directory}
                Copy-Item -Path $lbmonitorsourcepath -Recurse -Force -Destination $lbmonitordestpath -ErrorAction Stop

                #increment the port number so we can iterate multiple sites
                $portnumber ++

            #endforeach
            }

            #delete each app pool in defaultapppools
            foreach($pool in $defaultAppPools) {
                xWebAppPool "$pool-Delete" {
                    Name = $pool
                    Ensure = "Absent"
                }
            }

            #C:\inetpub\wwwroot
            # Stop the default website then remove it
            xWebsite DefaultWebSite 
            {
                State           = "Stopped"
                Ensure          = "Absent"
                Name            = "Default Web Site"
                PhysicalPath    = "C:\inetpub\wwwroot"
            }
        }

        #endregion

        ########
        #region enable Windows Authentication
        ########
        #Set-WebConfigurationProperty -filter "system.webServer/security/authentication/windowsAuthentication" -name "enabled" -value "True" -pspath IIS:\ -location 'Dataverify'
        if ($FlagIIS -eq $true) {
             foreach($site in $sitePools)
             {
                #pool, destination, site name for site 1
                $SitePoolName = $site.AppPool
                $sitename = $SitePoolName

                xWebConfigProperty "$sitename-EnableWindowsAuthentication"
                {
                    WebsitePath = "IIS:\Sites\$sitename"
                    Filter = 'system.webServer/security/authentication/windowsAuthentication'
                    PropertyName = 'enabled'
                    Value        = 'True'
                    Ensure       = 'Present'
                }
            
             }
        }
        #endregion
        
        ########
        #region HTTP Response Headers
        ########
        if ($FlagIIS -eq $true) {
            Script DeleteXPoweredByHttpResponseHeader {

                #get the http response web configuration property. store the value in a hashtable with key "Result"
                GetScript = {
                    $HTTPResponseHeader = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/httpProtocol/customHeaders/add[@name='X-Powered-By']" -name "."
                    $HTTPResponseHeaderName = $HTTPResponseHeader.name
                    @{ "Result" = $HTTPResponseHeaderName }
                }

                #use GetScript and check the "Result" key/value pair. If the value equals "" (an empty string), return true. Else return false which
                #will trigger the running of SetScript
                TestScript = {
                    $HTTPResponseHeader = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/httpProtocol/customHeaders/add[@name='X-Powered-By']" -name "."
                    $HTTPResponseHeaderName = $HTTPResponseHeader.name
                    if( $HTTPResponseHeaderName -eq "X-Powered-By")
                    {
                        Write-Verbose -Message "X-Powered-By header exists, running SetScript"
                        return $false
                    }
                    else
                    {
                        Write-Verbose -Message "X-Powered-By header does not exist. No action is required."
                        return $true
                    }
                }

                #if TestScript returns $false, remove the web configuration property that matches name "X-Powered-By"
                SetScript = {
                    Remove-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/httpProtocol/customHeaders" -name "." -AtElement @{name='X-Powered-By'}
                }
            }
        }
        #endregion
        
        ########
        #region Scheduled Tasks
        ########
        if ($FlagRVProxy -eq $true) {
            ScheduledTask NGINX
            {
                TaskName                = "NGINX"
                ActionExecutable        = 'E:\nginx-1.13.8\nginxstart.bat'
                ScheduleType            = 'Daily'
                DaysInterval            = 1
                RepeatInterval          = '00:05:00'
                RepetitionDuration      = 'Indefinitely'
                StartTime               = "00:00:00"
            }
        }
        <#
        ScheduledTask NGINX
        {
            TaskName                = NGINX
            ActionExecutable        = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments         = "-File `"E:\nginx-1.13.8\nginxstart.bat`""
            ScheduleType            = 'Daily'
            DaysInterval            = 1
            RepeatInterval          = '00:05:00'
            RepetitionDuration      = 'Indefinitely'
            StartTime               = "00:00:00"
        }
        #>


        #endregion

		#end node
    }

#end configuration
}

#call the configuration we specified above which will compile it down into a .mof
#use "&" to call the variable/name of the configuration. the alternative is just specifying the whole name not in a variable like...
&$DSCconfigName -OutputPath C:\dsc-mof\$DSCconfigName
########
#region pre-config-run stuffs 
#delete IIS stuffs
########
if ($FlagIIS -eq $true) {
    #remove all sites
    remove-website -name *

    #remove all app pools
    Get-ChildItem -Path IIS:\AppPools\ | ForEach-Object { Remove-WebAppPool $_.Name }

}

#endregion

#cleanup is finished so now lets trigger the config
#start the configuration using the same path we just specified where the .mof is
Start-DscConfiguration -ComputerName $env:computername -Path C:\dsc-mof\$DSCconfigName -Wait -ErrorAction Stop -Force -Verbose

#apply LCM settings
Set-DscLocalConfigurationManager -Path C:\dsc-mof\$DSCconfigName