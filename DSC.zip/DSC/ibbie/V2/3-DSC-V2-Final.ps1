########
# Author:       Matt Keller / John Basso
# Description:  Powershell DSC to configure credentials for APP Pools & Sites in IIS
# Changes:      10/29/2019      Initial creation
#
########

##########
#ASSUMPTION: You are copying this script out to the server then executing it from there
#            *The service account must have permissions to view the secret.
##########

# Read computer name
$target = $env:computername

#region Parse Server Name into variables
# Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
$targetarray = $target -Split '(\d\d)'
# Read the first string, which is the Root Name for the server
$RootName = $targetarray[0]
# Read the second string, which is the double digit number in the server name
$Number = $targetarray[1]
# Read the third string, which includes Location/Support Team/Type/Environment
$Details = $targetarray[2]
# Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
$Prefix = $RootName[0,1] -join ''
$Prefix = $($Prefix.ToLower())
# Read the Root Name, starting after the second character (web from dvweb)
$ServerType = $RootName.Substring(2)
$ServerType = $($ServerType.ToLower())
# Read last character for Environment
$Environment = $Details.Substring($Details.Length-1)
# Update Environment variable
switch ($Environment){
    "l"{$Environment = "lab"}
    "d"{$Environment = "dev"}
    "q"{$Environment = "qa"}
    "u"{$Environment = "uat"}
    "p"{$Environment = "prod"}
}
#endregion

#$IISaccount = "world\svc_" + $Prefix + $ServerType + "_" + $($Environment[0])
$IISaccount = "world\svcsqlibbie_qa"

#region Set up Server Type variables

# Initialize Server Type Flags
$FlagADMIN = $false
$FlagASSETS = $false
$FlagINTEG = $false
$FlagRVPROXY = $false
$FlagWEB = $false
$FlagWIDGET = $false

switch ($ServerType){
        "admin"{
            $FlagADMIN = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "admin"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "admin-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "assets"{
            $FlagASSETS = $true
            $FlagIIS = $true
            $sitePools = @(
                @{ AppPool = "assets"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "assets-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "integ"{
            $FlagINTEG = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "integ"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "integ-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "rvproxy"{
            $FlagRVPROXY = $true
        }
        "web"{
            $FlagWEB = $true
            $FlagIIS = $true
            $FlagDynatrace = $true
            $sitePools = @(
                @{ AppPool = "web"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "web-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
        "widget"{
            $FlagWIDGET = $true
            $FlagIIS = $true
            $sitePools = @(
                @{ AppPool = "widget"; AppPoolIdentity = $IISaccount }
                @{ AppPool = "widget-Prerelease"; AppPoolIdentity = $IISaccount }
            )
            $appPools = @(
                @{ AppPool = "lbmonitor"; AppPoolIdentity = $IISaccount }
            )
        }
}
#endregion

#########
#region for functions for grabbing Secrets from SecretServer
#########
$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users

#if you're using TLS1.2 instead of 1.0, you need this
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#we need this module in order to use set-itemproperty below
Import-Module WebAdministration

# function that takes in a search term, finds the SecretServer ID, then uses the ID to return the password for that Secret.
Function GetSecret ($searchterm){

    #initial setup of webservice proxy using the url we set
    $proxy = New-WebServiceProxy $url -UseDefaultCredential

    #try to authenticate using the user, pass and domain we provided. this is the login to SecretServer
    $result1 = $proxy.Authenticate($username, $password, '', $domain)
    if ($result1.Errors.length -gt 0){
            $result1.Errors[0]
            exit
    } 
    else{
            #save our login session token into $token
            $token = $result1.Token
    }
        
    #use search term to find the ID of the Secret 
    $result2 = $proxy.SearchSecrets($token, $searchterm, $null, $null)
    if ($result2.Errors.length -gt 0){
            $result2.Errors[0]
    }
    else{
        #Search each result found for an exact match
        $result2.SecretSummaries | ForEach-Object {
            If ($_.SecretName -eq $searchterm){
                $secretname = $_.SecretName
                $secretId = $_.SecretID
            }
        }
    }

    #use the SecretID that was an exact match to retrieve the password
    $result3 = $proxy.GetSecret($token, $secretId, $false, $null)

    #return the password
    $return = $result3.Secret.Items[2].Value
    Return $return
}

#########
#endregion function stuffs
#########

foreach($pool in $sitePools) {
    $poolidentity = $pool.AppPoolIdentity
    $poolname = $pool.AppPool
    #create our searchterm by removing the world\ in front of the app pool identity
    $searchterm = $poolidentity.Replace("world\","")
    #call our function to find the ID based on the search term, then return the password
    $poolpass = GetSecret $searchterm
    #set the app pool properties to have the identity we want with the password
    Set-ItemProperty "IIS:\AppPools\$poolName" -Name processModel -Value @{ userName=$pool.AppPoolIdentity; password=$poolpass; identitytype=3 }

    #Ensure $pool.AppPoolIdentity has access to \\dfs\nas\dv_shared\webapp deploy\ssl_certs
}