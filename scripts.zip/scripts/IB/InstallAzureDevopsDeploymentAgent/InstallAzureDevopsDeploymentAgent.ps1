﻿####################################################################################################
#change this value to whatever you want it to be
#ex $deploymentgroupname = "QA-Web"
#ex $deploymentgroupname = "QA-Admin"
#ex $deploymentgroupname = "QA-Integ"
#ex $deploymentgroupname = "QA-Widget"
$deploymentgroupname = "QA-Widget"
$computers = Get-Content -Path "C:\GIT\scripts\IB\InstallAzureDevopsDeploymentAgent\$deploymentgroupname.txt"
####################################################################################################

echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose) {

        #run winrm quickconfig on each target
        echo " "
        echo "starting commands on new host $target"
        echo "running winrm /quickconfig on $target"
        echo "IGNORE THE PSEXEC ERROR. ITS WORKING"
        C:\Windows\System32\PsExec.exe \\$target PowerShell.exe -c "winrm /quickconfig"
        echo " "
        echo "IGNORE THE PSEXEC ERROR. ITS WORKING"
        echo "creating pssession to $target"
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        echo "pssession created on $target"

        $destpath = "\\" + $target + "\e$\azagent"
        $localpath = "e:\azagent"
        $deployagentpath = "\\fs\cbc\dept\windows\Visual Studio & Azure DevOps\Azure Devops Express\Deploy Agent\azagent"

        Try {
            If (test-path $destpath) {
                echo "$destpath already exists on $target - the agent may not need to be installed. try removing the directory/&/or service and run again"
            }

            Else {
                echo "$destpath did not exist so agent must not be installed. creating $localpath on $target"
                #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
                Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                echo " "
                echo "creating path succeeded"

                echo "starting copy of azagent out to $target"
                Copy-Item -Path $deployagentpath -Destination $destpath -Recurse -Force -ErrorAction Stop
                echo "azagent copies okay to $target"

                #region start install script
                echo " "
                echo "starting powershell install & configure commands on $target for deploymentgroup $deploymentgroupname"
                echo "###################################################################################"

                #invoke command to execute a ps1 script with $p6 parameter($p6 is the path argument for the script being called). -Argumentlist specifies $p6 parameter becomes $localfilepath1
                Invoke-Command -Session $session -scriptblock {
                    param($p1)
                    cd e:\azagent\A1\agent
                    .\config.cmd --deploymentgroup --deploymentgroupname $p1 --agent $env:COMPUTERNAME --runasservice --work '_work' --url 'http://ibtfs01uwaq/' --collectionname 'DefaultCollection' --projectname 'ibbie' --auth integrated
                } -ArgumentList $deploymentgroupname -ErrorAction Stop
                echo " "
                echo "###################################################################################"
                echo "finished powershell install & configure commands on $target"
                #endregion

            #endelse
            }

        #endtry
        }
        Catch {
            echo "failed creating $destpath on $target or copying azagent"
            break
        }

    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }

echo "removing pssession on $target"
Remove-PSSession $session

#endforeach
}