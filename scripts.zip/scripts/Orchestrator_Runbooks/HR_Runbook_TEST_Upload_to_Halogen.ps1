﻿
# TEST VERSION of HR Runbook Upload to Halogen
# This reads a local report file, then exports a local results file
# The exported file is what the production script would upload to Halogen

        $users = get-aduser -properties * -filter {(employeetype -eq "F")} # -and (enabled -eq $true)} 
        $users = $users | where-object {($_.distinguishedname -notlike "*OU=Z_Test,OU=Users and Workstations,DC=cbc,DC=local") -and ($_.employeeid -ne $null)}

        $export = @()

        # local copy of payroll report from "\\fs\cbc\dept\hr\AD Payroll Upload\report.csv"
        $userreport = import-csv "C:\Temp\HalogenScriptTest_report_20191206.csv"

        foreach ($user in $users) {
            $row = new-object System.Object

            $row | add-member -MemberType NoteProperty -name "Subject Username" -value $user.samaccountname
            # Find current user in report.csv, then save their Supervisor's ID
            foreach ($person in $userreport){
            [int]$PersonID = $person."Empl ID"
            [int]$UserID = $user.employeeid
                if ($PersonID -eq $UserID){
                    [int]$PersonSupervisorID = $person."Supervisor ID - Employment Dta"
                    # Exception for Bob Miller (Employee ID 1676) - Use Self Service Mgr instead of Supervisor ID
                    if ($PersonSupervisorID -eq 1676){
                        [int]$SupervisorID = $person."SS Mgr ID"
                    }else{
                        [int]$SupervisorID = $person."Supervisor ID - Employment Dta"
                    }
                    $Supervisor = Get-ADUser -Filter {EmployeeID -eq $SupervisorID}
                }
            }
            $row | add-member -MemberType NoteProperty -name "Manager Username" -value $Supervisor.samaccountname
            # $row | add-member -MemberType NoteProperty -name "Manager Username" -value (get-aduser $user.manager).samaccountname
            switch ($user.office) {
                "Phoenix" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "lauren.davis"}
                "Pittsburgh" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "lauren.davis"}
                "Loveland.5100" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "sage.mullen"}
                "Loveland.5200" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "sage.mullen"}
                "Loveland" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "sage.mullen"}
                default {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "jacqueline.doone"}
            }
            $row | add-member -MemberType NoteProperty -name "Career Coach Username" -value ""
            $row | add-member -MemberType NoteProperty -name "Password" -value ""
            $row | add-member -MemberType NoteProperty -name "First Name" -value $user.givenname
            $row | add-member -MemberType NoteProperty -name "Last Name" -value $user.surname
            $row | add-member -MemberType NoteProperty -name "Email Address" -value $user.emailaddress
            $row | add-member -MemberType NoteProperty -name "Do Not Send Email" -value "no"
            $row | add-member -MemberType NoteProperty -name "Employee ID" -value $user.employeeid
            $row | add-member -MemberType NoteProperty -name "Hire Date" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Appraisal Date" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Promotion Date" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Appraisal Score" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Appraisal Scale" -value ""
            $row | add-member -MemberType NoteProperty -name "Job Title" -value $user.title
            $row | add-member -MemberType NoteProperty -name "Department" -value $user.department
            $row | add-member -MemberType NoteProperty -name "Division" -value ""
            $row | add-member -MemberType NoteProperty -name "Company" -value $user.company
            $row | add-member -MemberType NoteProperty -name "Location" -value $user.office
            $row | add-member -MemberType NoteProperty -name "Job Code" -value ""
            $row | add-member -MemberType NoteProperty -name "Base Salary" -value ""
            $row | add-member -MemberType NoteProperty -name "Variable Pay/Bonus Target" -value ""
            $row | add-member -MemberType NoteProperty -name "Hours Worked Per Year" -value ""
            $row | add-member -MemberType NoteProperty -name "Hourly Rate" -value ""
            $row | add-member -MemberType NoteProperty -name "Hourly Base Salary Pay Type" -value ""
            $row | add-member -MemberType NoteProperty -name "Currency ISO Code" -value ""
            if ($user.enabled -eq $false) {
                $row | add-member -MemberType NoteProperty -name "Deactivate User" -value "Y"
            }
            else {
                $row | add-member -MemberType NoteProperty -name "Deactivate User" -value ""
            }
            $row | add-member -MemberType NoteProperty -name "Job Description ID" -value ""
            $row | add-member -MemberType NoteProperty -name "Dates Job Description Assigned" -value ""
            $row | add-member -MemberType NoteProperty -name "Evaluator Name" -value ""
            $row | add-member -MemberType NoteProperty -name "Form Code" -value ""

            $export += $row
        }

        $tempfile = "C:\Temp\HalogenScriptTest_UploadFile_20191211.csv"
        $export | export-csv $tempfile -notypeinformation