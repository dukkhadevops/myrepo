﻿# HR Runbook
# Synchronize Payroll to AD

# !!! Copy this into Powershell ISE to edit !!!

# Set the computer you want this to run on below. Use localhost to have it run directly on the runbook servers unless you need it to run elsewhere.
$computername = "localhost"

# Set the user and password to run the powershell as below
$credusername = "world\svchradsync"
$credpassword = "PrymCsgrqAmU36bFaCQr"

<#
QUICK HOWTO
1. Insert your custom code in between the lines that contain 'CustomCodeStartsHere' and 'CustomCodeEndsHere'.
2. You should not modify the rest of the script outside of the area between those two lines and the variables above specifying computername and credentials.
3. See Confluence for more detailed instructions
#>

function AppendLog ([string]$Message) {
    $script:CurrentAction = $Message
    write-host ((Get-Date).ToString() + "   " + $Message + " `r`n")
    add-content -path "c:\runbooklogs\running.log" -value ("`n" + ((Get-Date).ToString() + "`t" + $Message + " `r`n"))
}

$transcriptfilename = [guid]::NewGuid().ToString() + ".log"
$transcriptpath = "C:\runbooklogs\" + $transcriptfilename
$transcriptdate = get-date -format yyyyMMdd_hhmmtt
Start-Transcript -Path $transcriptpath -IncludeInvocationHeader

$runninglogfilename = "c:\runbooklogs\running.log"

$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername,$credpasswordss)
$DataBusInput1 = "\`d.T.~Ed/{C553A8CF-8E08-48EF-90DD-4E2D57DC9A23}.{284D1F1D-3F3D-4729-8A31-75A14C5F5110}\`d.T.~Ed/"
$DataBusInput2 = "\`d.T.~Ed/{C553A8CF-8E08-48EF-90DD-4E2D57DC9A23}.{C0C89852-048F-4530-8A71-E8289E520DEE}\`d.T.~Ed/"
if ($DataBusInput1 -eq "") { $DataBusInput1 = "undefined" }
if ($DataBusInput2 -eq "") { $DataBusInput2 = "undefined" }
$argsArray = @()
$argsArray += $DataBusInput1
$argsArray += $DataBusInput2
$ResultStatus = ""
$ErrorMessage = ""
$CurrentAction = ""
$Trace = @()
$Session = New-PSSession -ComputerName $computername -Credential $credentials -Authentication Credssp -ErrorAction Stop

AppendLog "Runbook activity script started"

$ReturnArray = Invoke-Command -Session $Session -Argumentlist $argsArray -ScriptBlock {
    Param(
        [ValidateNotNullOrEmpty()]
        [string]$DataBusInput1,

        [ValidateNotNullOrEmpty()]
        [string]$DataBusInput2
    )
    function AppendLog ([string]$Message) {
        $script:CurrentAction = $Message
        write-host ((Get-Date).ToString() + "`t" + $Message + " `r`n")
        add-content -path "c:\runbooklogs\running.log" -value ("`n" + ((Get-Date).ToString() + "`t" + $Message + " `r`n"))
    }
    $ResultStatus = ""
    $ErrorMessage = ""
    
    try 
    {
        AppendLog "Script now executing in external PowerShell version [$($PSVersionTable.PSVersion.ToString())] session in a [$([IntPtr]::Size * 8)] bit process"
        AppendLog "Running as user [$([Environment]::UserDomainName)\$([Environment]::UserName)] on host [$($env:COMPUTERNAME)]"
        AppendLog "Parameter values received: DataBusInput1=[$DataBusInput1]; DataBusInput2=[$DataBusInput2]"

        ### CustomCodeStartsHere ###
        #  -Make sure to add proper AppendLog entries at each step of whatever you're doing to make logs easier to read when there is a failure.
        #
        # - If you're calling an executable, rather than a non-powershell function, you need to do the following two things:
        #   1. Pipe the executable to out-null (i.e. 'robocopy c: e: | out-null')
        #   2. Add the following line after each executable to caputre errors:
        #        if ($LASTEXITCODE -gt 0) { $ResultStatus = "Failed" }
        #
        # - There's special error handling needed for robocopy; duplicate one of the existing robocopy Runbooks rather than starting from scratch
        #
        # - If you passed data in via the Initialize Data action, it's available here in $DataBusInput1 and $DataBusInput2

        $userreport = import-csv "\\fs\cbc\dept\hr\AD Payroll Upload\report.csv"
        $userswithoutad = get-content "\\fs\cbc\dept\hr\AD Payroll Upload\supportfiles\users_ids_without_ad_accounts.txt"
        $userswithoutad = foreach ($number in $userswithoutad) {([int]::parse($number))}
        $companyhash = Import-Clixml "\\fs\cbc\dept\hr\AD Payroll Upload\supportfiles\companies.xml"
        $officehash = Import-Clixml "\\fs\cbc\dept\hr\AD Payroll Upload\supportfiles\offices.xml"
        $adusers = Get-ADUser -Properties EmployeeID,employeetype -Filter * -resultsetsize $null
        $standardadusers = get-aduser -Properties employeeid -SearchBase "OU=Users and Workstations,DC=cbc,DC=local" -Filter * -resultsetsize $null
        $standardadusers = $standardadusers | ? {($_.distinguishedname -notlike "*Z_Test*") -and ($_.distinguishedname -notlike "*Z_Shared*") -and ($_.distinguishedname -notlike "*Outsourcers*") -and ($_.distinguishedname -notlike "*Contractors*")}
        $exiterror = 0

        AppendLog "info: Begin verifying Employee IDs only match a single user."
        foreach ($user in $userreport) {
            [int]$rptidint = $user."Empl ID"
            $idmatches = 0
            foreach ($aduser in $adusers) {
                [int]$adidint = $aduser.employeeid
                if ($adidint -eq $rptidint) {
                    $idmatches++
                }
            }
            if ($idmatches -gt 1) {
                AppendLog "ERROR: EmployeeID $rptidint matches multiple users in AD. Please fix and rerun."
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying Employee IDs only match a single user."


        AppendLog "info: Begin verifying Employee IDs only occur once in source report."
        foreach ($user in $userreport) {
            [int]$rptidint = $user."Empl ID"
            $idmatches = 0
            foreach ($user2 in $userreport) {
                [int]$rptidint2 = $user2."empl id"
                if ($rptidint2 -eq $rptidint) {
                    $idmatches++
                }
            }
            if ($idmatches -gt 1) {
                AppendLog "ERROR: EmployeeID $rptidint exists multiple times in the source report. Please fix and rerun."
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying Employee IDs only occur once in source report."


        AppendLog "info: Begin verifying all employees in source report exist in AD."
        foreach ($user in $userreport) {
            [int]$id = $user."Empl ID"
            $idmatches = 0
            if ($userswithoutad -notcontains $id) {
                foreach ($aduser in $adusers) {
                    if ([int]$aduser.EmployeeID -eq $id) {
                        $idmatches++
                    }
                }
                if ($idmatches -eq 0) {
                    AppendLog "ERROR: Employee ID $id is in the source report, but not in AD. Please fix and rerun."
                    $exiterror = 1
                }
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all employees in source report exist in AD."

        AppendLog "info: Begin verifying all 'Supervisor ID - Employment Dta's in the source report exist in AD."
        foreach ($user in $userreport) {
            [int]$supid = $user."Supervisor ID - Employment Dta"
            $supidmatches = 0
            foreach ($aduser in $adusers) {
                if ([int]$aduser.EmployeeID -eq $supid) {
                    $supidmatches++
                }
            }
            if ($supidmatches -eq 0) {
                AppendLog "ERROR: 'Supervisor ID - Employment Dta' $supid is in the source report, but not in AD. Please fix and rerun."
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all 'Supervisor ID - Employment Dta's in the source report exist in AD."


        AppendLog "info: Begin verifying all AD users have employee ids set."
        foreach ($user in $standardadusers) {
            if (($user.employeeid -eq $null) -and (($user.employeetype -eq "C") -or ($user.employeetype -eq "T"))) {
                AppendLog "ERROR: User '$($user.name)' is missing employeeid AD attribute. Please fix and rerun."
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all AD users have employee ids set."

        AppendLog "info: Begin verifying all AD users exist in the source report."
        foreach ($user in $standardadusers) {
            $idmatches = 0
            if ($user.employeeid -ne $null) {
                foreach ($rptuser in $userreport) {
                    [int]$rptidint = $rptuser."Empl ID"
                    if ($user.EmployeeID -eq $rptidint) {
                        $idmatches++
                    }
                }
                if ($idmatches -eq 0) {
                    AppendLog "WARNING: EmployeeID $($user.employeeid) ($($user.name)) exists in AD, but not in the source report."
                }
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all AD users exist in the source report."

        AppendLog "info: Begin verifying all companies in the source report are known."
        foreach ($user in $userreport) {
            [int]$id = $user."Empl ID"
            $companyname = $user."Company Name"

            if ($companyhash.keys -notcontains $companyname) {
                AppendLog "ERROR: Unknown company '$companyname' for Employee ID $id."
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all companies in the source report are known."

        AppendLog "info: Begin verifying all addresses in the source report are known."
        foreach ($user in $userreport) {
            [int]$id = $user."Empl ID"
            $officename = $user."Work Address #1"

            if ($officehash.keys -notcontains $officename) {
                AppendLog "ERROR: Unknown address '$officename' for Employee ID $id."
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all addresses in the source report are known."

        AppendLog "info: Begin verifying all OUs exist for offices listed in the source report."
        foreach ($user in $userreport) {
            $dn = "OU=Users,OU=" + $officehash.$($user."Work Address #1") + ",OU=" + $companyhash.$($user."Company Name") + ",OU=Users and Workstations,DC=cbc,DC=local"
            $obj = $null
            $obj = get-adobject -filter {distinguishedname -eq $dn}
            if ($obj -eq $null) {
                AppendLog "ERROR: OU Not Found: $dn. Please create the OU and rerun"
                $exiterror = 1
            }
        }
        if ($exiterror -eq 1) {
            AppendLog "ERROR: Aborting due to critical error."
            throw "ERROR: Aborting due to critical error."
        }
        AppendLog "info: End verifying all OUs exist for offices listed in the source report."

        AppendLog "info: Begin processing users for updates."
        foreach ($user in $userreport) {
            if ($user.'Empl ID' -notin $userswithoutad) {
                $dn = "OU=Users,OU=" + $officehash.$($user."Work Address #1") + ",OU=" + $companyhash.$($user."Company Name") + ",OU=Users and Workstations,DC=cbc,DC=local"
                [int]$id = $user."Empl ID"
                [int]$supid = $user."Supervisor ID - Employment Dta"
                $dnmatch = "*" + $dn
                $adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                if ($adobj.distinguishedname -notlike "*OU=Disabled,DC=cbc,DC=local") {
                    # Update user's office attribute
                    $adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                    if ($adobj.office -ne $officehash.$($user."Work Address #1")) {
                        AppendLog "info: Changing '$($adobj.name)' location from '$($adobj.office)' to '$($officehash.$($user."Work Address #1"))'"
                        $adobj | set-aduser -office $officehash.$($user."Work Address #1")

                    }

                    # Update user's title attribute
                    $adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                    if ($adobj.title -ne $user."Title") {
                        AppendLog "info: Changing '$($adobj.name)' title from '$($adobj.title)' to '$($user."Title")'"
                        $adobj | set-aduser -title $user."Title"
                    }

                    # Update user's manager attribute
                    $adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                    if ($adobj.manager -ne (get-aduser -filter {employeeid -eq $supid}).distinguishedname) {
                        AppendLog "info: Changing '$($adobj.name)' manager from '$($adobj.manager)' to '$((get-aduser -filter {employeeid -eq $supid}).distinguishedname)'"
                        $adobj | set-aduser -manager (get-aduser -filter {employeeid -eq $supid}).distinguishedname
                    }
                    # Update user's company attribute
                    $adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                    if ($adobj.company -ne $companyhash.$($user."Company Name")) {
                        AppendLog "info: Changing '$($adobj.name)' company from '$($adobj.company)' to '$($companyhash.$($user."Company Name"))'"
                        $adobj | set-aduser -company $companyhash.$($user."Company Name")
                    }

                    # Update user's department attribute
                    #$adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                    #if ($adobj.department -ne $user."Description - Dept Info") {
                    #    AppendLog "info: Changing '$($adobj.name)' department from '$($adobj.department)' to '$($user."Description - Dept Info")'"
                    #    $adobj | set-aduser -department $user."Description - Dept Info"
                    #}

                    # Move user between OUs
                    $adobj = get-aduser -filter {employeeid -eq $id} -Properties *
                    if ($adobj.distinguishedname -notlike $dnmatch) {
                        AppendLog "info: Moving '$($adobj.userprincipalname)' ($id) from '$sourceou' to '$dn'"
                        try {
                            $adobj | Move-ADObject -TargetPath $dn
                        }
                        catch {
                            AppendLog "WARNING: Error trying to move '$($adobj.userprincipalname)'. Windows Administration should move user manually."
                            Continue
                        }
                    }
                }
            }
        }
        AppendLog "info: End processing users for updates."

        ### CustomCodeEndsHere ###
        
        if($ResultStatus -eq "") { $ResultStatus = "Success" }
    }
    catch {
        # Catch any errors thrown above here, setting the result status and recording the error message to return to the activity for data bus publishing
        $ResultStatus = "Failed"
        $ErrorMessage = $error[0].Exception.Message
        AppendLog "Exception caught during action [$CurrentAction]: $ErrorMessage"
    }
    finally
    {
        if($ErrorMessage.Length -gt 0) {
            AppendLog "Exiting external session with result [$ResultStatus] and error message [$ErrorMessage]"
        }
        else {
            AppendLog "Exiting external session with result [$ResultStatus]"
        }
        
    }
    $resultArray = @()
    $resultArray += $ResultStatus
    $resultArray += $ErrorMessage
    $resultArray += $ActionOutput
    return $resultArray
}

AppendLog "Script finished"

foreach ($line in $(get-content $transcriptpath)) { $Trace += $line + " `r`n" }

[string]$TraceStringExternal = $Trace
$ResultStatusExternal = $ReturnArray[0]
$ErrorMessageExternal = $ReturnArray[1]
$ActionOutputExternal = $ReturnArray[2]

Remove-PSSession $Session
Stop-Transcript