﻿# HR Runbook
# Upload to Halogen

# !!! Copy this into Powershell ISE to edit !!!

# Set the computer you want this to run on below. Use localhost to have it run directly on the runbook servers unless you need it to run elsewhere.
$computername = "localhost"

# Set the user and password to run the powershell as below
$credusername = "world\svcscorchestrator"
$credpassword = "AhOIt8EymEbLQS2KzlQ0"

<#
QUICK HOWTO
1. Insert your custom code in between the lines that contain 'CustomCodeStartsHere' and 'CustomCodeEndsHere'.
2. You should not modify the rest of the script outside of the area between those two lines and the variables above specifying computername and credentials.
3. See Confluence for more detailed instructions
#>

function AppendLog ([string]$Message) {
    $script:CurrentAction = $Message
    write-host ((Get-Date).ToString() + "`t" + $Message + " `r`n")
}

$transcriptfilename = [guid]::NewGuid().ToString() + ".log"
$transcriptpath = "C:\runbooklogs\" + $transcriptfilename
$transcriptdate = get-date -format yyyyMMdd_hhmmtt
Start-Transcript -Path $transcriptpath -IncludeInvocationHeader

$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername,$credpasswordss)
$DataBusInput1 = "\`d.T.~Ed/{2A574A25-C00A-4296-85CE-C810ABB4A83A}.{6C1DE476-5775-4576-A388-E14FE6AF85AD}\`d.T.~Ed/"
$DataBusInput2 = "\`d.T.~Ed/{2A574A25-C00A-4296-85CE-C810ABB4A83A}.{929EDCED-5215-4926-AF9D-7A58E408A7C4}\`d.T.~Ed/"
if ($DataBusInput1 -eq "") { $DataBusInput1 = "undefined" }
if ($DataBusInput2 -eq "") { $DataBusInput2 = "undefined" }
$argsArray = @()
$argsArray += $DataBusInput1
$argsArray += $DataBusInput2
$ResultStatus = ""
$ErrorMessage = ""
$CurrentAction = ""
$Trace = @()
$Session = New-PSSession -ComputerName $computername -Credential $credentials -Authentication Credssp -ErrorAction Stop

AppendLog "Runbook activity script started"

$ReturnArray = Invoke-Command -Session $Session -Argumentlist $argsArray -ScriptBlock {
    Param(
        [ValidateNotNullOrEmpty()]
        [string]$DataBusInput1,

        [ValidateNotNullOrEmpty()]
        [string]$DataBusInput2
    )
    function AppendLog ([string]$Message) {
        $script:CurrentAction = $Message
        write-host ((Get-Date).ToString() + "`t" + $Message + " `r`n")
    }
    $ResultStatus = ""
    $ErrorMessage = ""
    
    try 
    {
        AppendLog "Script now executing in external PowerShell version [$($PSVersionTable.PSVersion.ToString())] session in a [$([IntPtr]::Size * 8)] bit process"
        AppendLog "Running as user [$([Environment]::UserDomainName)\$([Environment]::UserName)] on host [$($env:COMPUTERNAME)]"
        AppendLog "Parameter values received: DataBusInput1=[$DataBusInput1]; DataBusInput2=[$DataBusInput2]"

        ### CustomCodeStartsHere ###
        #  -Make sure to add proper AppendLog entries at each step of whatever you're doing to make logs easier to read when there is a failure.
        #
        # - If you're calling an executable, rather than a non-powershell function, you need to do the following two things:
        #   1. Pipe the executable to out-null (i.e. 'robocopy c: e: | out-null')
        #   2. Add the following line after each executable to caputre errors:
        #        if ($LASTEXITCODE -gt 0) { $ResultStatus = "Failed" }
        #
        # - There's special error handling needed for robocopy; duplicate one of the existing robocopy Runbooks rather than starting from scratch
        #
        # - If you passed data in via the Initialize Data action, it's available here in $DataBusInput1 and $DataBusInput2

        $users = get-aduser -properties * -filter {(employeetype -eq "F") -and (enabled -eq $true)} 
        $users = $users | where-object {($_.distinguishedname -notlike "*OU=Z_Test,OU=Users and Workstations,DC=cbc,DC=local") -and ($_.employeeid -ne $null)}

        $export = @()

        foreach ($user in $users) {
            $row = new-object System.Object

            $row | add-member -MemberType NoteProperty -name "Subject Username" -value $user.samaccountname
            $row | add-member -MemberType NoteProperty -name "Manager Username" -value (get-aduser $user.manager).samaccountname
            switch ($user.office) {
                "Phoenix" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "lauren.davis"}
                "Pittsburgh" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "lauren.davis"}
                "Loveland.5100" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "sage.mullen"}
                "Loveland.5200" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "sage.mullen"}
                "Loveland" {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "sage.mullen"}
                default {$row | add-member -MemberType NoteProperty -name "HR Rep Username" -value "nathan.bradish"}
            }
            $row | add-member -MemberType NoteProperty -name "Career Coach Username" -value ""
            $row | add-member -MemberType NoteProperty -name "Password" -value ""
            $row | add-member -MemberType NoteProperty -name "First Name" -value $user.givenname
            $row | add-member -MemberType NoteProperty -name "Last Name" -value $user.surname
            $row | add-member -MemberType NoteProperty -name "Email Address" -value $user.emailaddress
            $row | add-member -MemberType NoteProperty -name "Do Not Send Email" -value "no"
            $row | add-member -MemberType NoteProperty -name "Employee ID" -value $user.employeeid
            $row | add-member -MemberType NoteProperty -name "Hire Date" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Appraisal Date" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Promotion Date" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Appraisal Score" -value ""
            $row | add-member -MemberType NoteProperty -name "Last Appraisal Scale" -value ""
            $row | add-member -MemberType NoteProperty -name "Job Title" -value $user.title
            $row | add-member -MemberType NoteProperty -name "Department" -value $user.department
            $row | add-member -MemberType NoteProperty -name "Division" -value ""
            $row | add-member -MemberType NoteProperty -name "Company" -value $user.company
            $row | add-member -MemberType NoteProperty -name "Location" -value $user.office
            $row | add-member -MemberType NoteProperty -name "Job Code" -value ""
            $row | add-member -MemberType NoteProperty -name "Base Salary" -value ""
            $row | add-member -MemberType NoteProperty -name "Variable Pay/Bonus Target" -value ""
            $row | add-member -MemberType NoteProperty -name "Hours Worked Per Year" -value ""
            $row | add-member -MemberType NoteProperty -name "Hourly Rate" -value ""
            $row | add-member -MemberType NoteProperty -name "Hourly Base Salary Pay Type" -value ""
            $row | add-member -MemberType NoteProperty -name "Currency ISO Code" -value ""
            $row | add-member -MemberType NoteProperty -name "Deactivate User" -value ""
            $row | add-member -MemberType NoteProperty -name "Job Description ID" -value ""
            $row | add-member -MemberType NoteProperty -name "Dates Job Description Assigned" -value ""
            $row | add-member -MemberType NoteProperty -name "Evaluator Name" -value ""
            $row | add-member -MemberType NoteProperty -name "Form Code" -value ""

            $export += $row
        }

        $tempfile = [System.IO.Path]::GetTempFileName()
        $newtemp = (split-path $tempfile) + "\" + (get-date -format yyyyMMdd) + ".csv"

        write-host $newtemp

        $export | export-csv $tempfile -notypeinformation

        move-item $tempfile $newtemp

        $username = "cbc_companies"
        $Password = ConvertTo-SecureString "FPqKpFIOqg4l" -AsPlainText -Force
        $Credential = New-Object System.Management.Automation.PSCredential ($username, $Password)

        AppendLog "Uploading to Halogen"

        new-sftpsession -computername sftp.na1.hgncloud.com -credential $Credential -AcceptKey | out-null

        try {
            Set-SFTPFile -SessionId 0 -LocalFile $newtemp -RemotePath "/"
        } catch {
            $ResultStatus = $_
        }

        (Get-SFTPSession -SessionId 0).Disconnect()

        remove-item $newtemp

        ### CustomCodeEndsHere ###
        
        if($ResultStatus -eq "") { $ResultStatus = "Success" }
    }
    catch {
        # Catch any errors thrown above here, setting the result status and recording the error message to return to the activity for data bus publishing
        $ResultStatus = "Failed"
        $ErrorMessage = $error[0].Exception.Message
        AppendLog "Exception caught during action [$CurrentAction]: $ErrorMessage"
    }
    finally
    {
        if($ErrorMessage.Length -gt 0) {
            AppendLog "Exiting external session with result [$ResultStatus] and error message [$ErrorMessage]"
        }
        else {
            AppendLog "Exiting external session with result [$ResultStatus]"
        }
        
    }
    $resultArray = @()
    $resultArray += $ResultStatus
    $resultArray += $ErrorMessage
    $resultArray += $ActionOutput
    return $resultArray
}

AppendLog "Script finished"

foreach ($line in $(get-content $transcriptpath)) { $Trace += $line + " `r`n" }

AppendLog $ReturnArray

[string]$TraceStringExternal = $Trace
$ResultStatusExternal = $ReturnArray[0]
$ErrorMessageExternal = $ReturnArray[1]
$ActionOutputExternal = $ReturnArray[2]

Remove-PSSession $Session
Stop-Transcript