﻿# Setting File and Folder Permissions

$InheritanceFlag = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
$PropagationFlag = [System.Security.AccessControl.PropagationFlags]::None
$objType = [System.Security.AccessControl.AccessControlType]::Allow

<#
╔═════════════╦═════════════╦═══════════════════════════════╦════════════════════════╦══════════════════╦═══════════════════════╦═════════════╦═════════════╗
║             ║ folder only ║ folder, sub-folders and files ║ folder and sub-folders ║ folder and files ║ sub-folders and files ║ sub-folders ║    files    ║
╠═════════════╬═════════════╬═══════════════════════════════╬════════════════════════╬══════════════════╬═══════════════════════╬═════════════╬═════════════╣
║ Propagation ║ none        ║ none                          ║ none                   ║ none             ║ InheritOnly           ║ InheritOnly ║ InheritOnly ║
║ Inheritance ║ none        ║ Container|Object              ║ Container              ║ Object           ║ Container|Object      ║ Container   ║ Object      ║
╚═════════════╩═════════════╩═══════════════════════════════╩════════════════════════╩══════════════════╩═══════════════════════╩═════════════╩═════════════╝
#>

$F = "FullControl"
$M = "Modify"
$R = "Read"
$RX = "ReadAndExecute"
$W = "Write"

$Path = "\\dfs\nas\DV_Shared\TEST\Permission Test" #"\\appfs\DV\prod\dv_dfsarchive_prod"
$acl=get-acl $Path
# Example: New-Object System.Security.AccessControl.FileSystemAccessRule("Domain\User","ReadAndExecute","ContainerInherit, ObjectInherit","None","Allow")
$AccessRule0 = New-Object System.Security.AccessControl.FileSystemAccessRule("Owner Rights",$RX,$InheritanceFlag,$PropagationFlag,$objType)
$AccessRule1 = New-Object System.Security.AccessControl.FileSystemAccessRule("WORLD\FS Global Admins",$F,$InheritanceFlag,$PropagationFlag,$objType)
$AccessRule2 = New-Object System.Security.AccessControl.FileSystemAccessRule("WORLD\appfs.dv.prod.dv_dfsarchive_prod.modify",$M,$InheritanceFlag,$PropagationFlag,$objType)
$AccessRule3 = New-Object System.Security.AccessControl.FileSystemAccessRule("WORLD\appfs.dv.prod.dv_dfsarchive_prod.read",$RX,$InheritanceFlag,$PropagationFlag,$objType)
$acl.SetAccessRule($AccessRule0)
$acl.SetAccessRule($AccessRule1)
$acl.SetAccessRule($AccessRule2)
$acl.SetAccessRule($AccessRule3)
#$acl.SetAccessRuleProtection($false,$false)
#$acl | fl 
Set-Acl $Path -AclObject $acl