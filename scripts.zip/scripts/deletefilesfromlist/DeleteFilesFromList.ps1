########################################################################################################################################################################
##Script Created By: Paul Fox and Google            
##Created: 03/05/2019                               
##                                                  
##edited by Matt Keller                   
##date: 3/11/2019
##comment: added logwrite function so we know exactly what files/folders we are operating on. changing the script to delete files from a list instead of move files
##
##
##Description: For each file in the list of files ($list) delete the file and write to log what was deleted          
########################################################################################################################################################################

$list = Get-Content C:\temp\list.txt
$root = "\\DFS\NAS\DV_FS\WebClusterFiles\1\VOE"
#$destinationDir = "C:\temp\test"

$logpath = "c:\temp"
$logfile = "C:\temp\deletefilesfromlist.txt"


Function LogWrite
{
   Param ([string]$message)

   $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
   $Line = "$Stamp $message"
   Add-content -path $logfile -value $Line
}


#see if the old log file is there, if it is, remove it
if (Test-Path $logfile)
    {
        Remove-Item $logfile
    } 
    Else 
    {
        New-Item -path $logpath -name "deletefilesfromlist.txt" -type "file"
    }


## This moves only the files specified in your input file (When first created, this was a .txt file). It will leave any files not specified in $GetTXT. These must be just filenames. No full file paths.
##      The foreach statement as required. All files get moved if the Get-ChildItem and Move-Item and not inside the foreach statement.
foreach ($file in $list)
    {
        #Get-ChildItem -Path $root -Recurse -Filter $file | Remove-Item -Path "$root\$file" -WhatIf
        Get-ChildItem -Path $root -Recurse -Filter $file | Remove-Item -Force
        LogWrite "Deleted $root\$file"
    }