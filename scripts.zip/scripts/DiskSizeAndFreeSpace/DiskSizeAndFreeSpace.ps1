﻿# Get Server Disk Size and Free Space

$servers = Get-Content -Path "C:\Git\Scripts\DiskSizeAndFreeSpace\dvdr.txt" # Prod list is dvprod.txt
$result = @()

foreach ($server in $servers){
    $disk = Get-WmiObject Win32_LogicalDisk -ComputerName $server -Filter DriveType=3 | Select DeviceID,@{N='Size(GB)';E={[Math]::Round($_.Size/1GB)}},@{N='FreeSpace(GB)';E={[Math]::Round($_.FreeSpace/1GB)}}
    $disk | foreach {
                $export = New-Object PSObject
                $export | Add-Member -MemberType NoteProperty -Name "Server" -Value $server
                $export | Add-Member -MemberType NoteProperty -Name "DeviceID" -Value $_.DeviceID
                $export | Add-Member -MemberType NoteProperty -Name "Size(GB)" -Value $_.'Size(GB)'
                $export | Add-Member -MemberType NoteProperty -Name "FreeSpace(GB)" -Value $_.'FreeSpace(GB)'
                $result += $export
            }
}

$result
