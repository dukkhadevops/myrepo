﻿
# Script to Add a list of Servers to a service account's "Log On To..." Permission list
# Update $SVCAccount as needed

$computers = Get-Content -Path "C:\Git\Scripts\AddServerToLogOnPermissions\computers.txt"

#$SVCAccount = "svc_dvRundeckMaint_p"

Foreach ($target in $computers) {
    $Workstations = (Get-ADUser $SVCAccount -Properties LogonWorkstations).LogonWorkstations
    $Workstations += ",$target"
    Set-ADUser $SVCAccount -LogonWorkstations $Workstations
}