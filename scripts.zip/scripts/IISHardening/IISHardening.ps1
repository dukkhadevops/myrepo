$hardeniis = invoke-command -computername $vmname -ScriptBlock{
    Import-module webadministration
    $rulename = "UpdateServerResponseHeader"
    $errorarray = @()
            try{
Add-WebConfigurationProperty -PSPath MACHINE/WEBROOT/APPHOST -Name . -Filter system.webServer/httpProtocol/customHeaders -AtElement @{name="X-Xss-Protection" ; value="1;mode=block"} -ErrorAction Stop
start-sleep -s 2}catch{$errorarray += "Error: X-Xss-Protection Header"}
            try{
Add-WebConfigurationProperty -PSPath MACHINE/WEBROOT/APPHOST -Name . -Filter system.webServer/httpProtocol/customHeaders -AtElement @{name="X-Content-Type-Options" ; value="nosniff"} -ErrorAction Stop
start-sleep -s 2}catch{$errorarray += "Error: X-Content-Type-Options Header"}
            try{
remove-WebConfigurationProperty -PSPath MACHINE/WEBROOT/APPHOST -Name . -Filter system.webServer/httpProtocol/customHeaders -AtElement @{name="x-powered-by" ; value='ASP.NET'} -ErrorAction Stop
start-sleep -s 2}catch{$errorarray += "Error: X-powered-by Header"}
            try{
set-WebConfiguration system.web/httpRuntime -value @{enableVersionHeader = "False"} -PSPath MACHINE/WEBROOT -ErrorAction Stop
start-sleep -s 2}catch{$errorarray += "Error: httpRuntime VersionHeader"}
            try{
Remove-WebConfigurationProperty //defaultDocument 'IIS:\' -name files -erroraction Stop
start-sleep -s 2}catch{$errorarray += "Error: Remove defaultDocument Files"}
            try{
add-WebConfigurationProperty -PSPath "IIS:\"  -Filter "/system.webServer/rewrite/outboundRules" -Name "." -Value @{name='UpdateServerResponseHeader';patternSyntax='Wildcard'} -erroraction Stop
start-sleep -s 2}catch{$errorarray += "Error: Update Server Response Header"}
            try{
Set-WebConfigurationProperty -pspath "IIS:\"  -filter "system.webServer/rewrite/outboundRules/rule[@name='$ruleName']/match" -name "serverVariable" -value "RESPONSE_SERVER" -erroraction Stop
start-sleep -s 2}catch{$errorarray += "Error: Update Server Response Header - ServerVariable"}
            try{
Set-WebConfigurationProperty -pspath "IIS:\"  -filter "system.webServer/rewrite/outboundRules/rule[@name='$ruleName']/match" -name "pattern" -value "*" -erroraction Stop
start-sleep -s 2}catch{$errorarray += "Error: Update Server Response Header - pattern"}
            try{
Set-WebConfigurationProperty -pspath "IIS:\"  -filter "system.webServer/rewrite/outboundRules/rule[@name='$ruleName']/action" -name "type" -value "Rewrite" -erroraction Stop
start-sleep -s 2}catch{$errorarray += "Error: Update Server Response Header - type"}

    #add X-Robots header to app level

    $websitename = "Default Web Site"
    $HeaderName = "X-Robots-Tag"
    $HeaderValue = "noindex,nofollow"
    [System.Reflection.Assembly]::LoadWIthPartialName("Microsoft.web.administration")

    $PSPath =  'MACHINE/WEBROOT/APPHOST/' + $WebSiteName 
                   
        $iis = new-object Microsoft.Web.Administration.ServerManager 
        $config = $iis.GetWebConfiguration($WebSiteName) #i.e. "Default Web Site" 
        $httpProtocolSection = $config.GetSection("system.webServer/httpProtocol")
        $customHeadersCollection = $httpProtocolSection.GetCollection("customHeaders") 
 
        $addElement = $customHeadersCollection.CreateElement("add") 
        $addElement["name"] = $HeaderName 
        $addElement["value"] = $HeaderValue 
 
        $customHeadersCollection.Add($addElement) 
 
        $iis.CommitChanges()
        start-sleep -s 5

        #add X-Frame_options header to App level

        $websitename = "Default Web Site"
        $HeaderName = "X-Frame-Options"
        $HeaderValue = "SAMEORIGIN"
        [System.Reflection.Assembly]::LoadWIthPartialName("Microsoft.web.administration")

        $PSPath =  'MACHINE/WEBROOT/APPHOST/' + $WebSiteName 
                   
            $iis = new-object Microsoft.Web.Administration.ServerManager 
            $config = $iis.GetWebConfiguration($WebSiteName) #i.e. "Default Web Site" 
            $httpProtocolSection = $config.GetSection("system.webServer/httpProtocol") 
            $customHeadersCollection = $httpProtocolSection.GetCollection("customHeaders") 
 
            $addElement = $customHeadersCollection.CreateElement("add") 
            $addElement["name"] = $HeaderName 
            $addElement["value"] = $HeaderValue 
 
            $customHeadersCollection.Add($addElement) 
 
            $iis.CommitChanges()  

        return $errorarray
} 
