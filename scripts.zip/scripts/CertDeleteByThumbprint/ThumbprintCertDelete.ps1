﻿#Create Array of objs
$objs = @()

#Create new objects in the array for each type of certificate store
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("TrustedPublisher","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("ClientAuthIssuer","LocalMachine")
$objs += New-Object System.Security.Cryptography.x509Certificates.x509Store("Remote Desktop","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("Root","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("TrustedDevices","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("CA","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("Windows Live ID Token Issuer","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("REQUEST","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("AuthRoot","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("AAD Token Issuer","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("FlightRoot","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("SmartCardRoot","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("TrustedPeople","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("AddressBook","LocalMachine")
$objs += New-Object System.Security.Cryptography.x509Certificates.x509Store("My","LocalMachine")
$objs += New-Object System.Security.Cryptography.X509Certificates.X509Store("CertificateAuthority","LocalMachine")
$objs += New-Object System.Security.Cryptography.x509Certificates.x509Store("Trust","LocalMachine")
$objs += New-Object System.Security.Cryptography.x509Certificates.x509Store("Homegroup Machine Certificates","LocalMachine")
$objs += New-Object System.Security.Cryptography.x509Certificates.x509Store("SMS","LocalMachine")

# Replace with thumbprints to be removed
# $cert_thumbs = @("23D10E891D0B611E49E0BB765BAA7E399B715D86","F96A5EB0CEEBA0F20CDAA5F2B5D2E1A4645CA8FC")

#For each store object in the array, open them all for read/write, look at the certificates and match the thumbprint to remove the certificate
ForEach ($obj in $objs)
{
    $obj.Open("ReadWrite")

    ForEach ($cert in $obj.certificates)
    {
      ForEach ($thumb in $cert_thumbs){
        if ($cert.thumbprint -eq $thumb)
        {
            $obj.Remove($cert)
        }
      }
    }

    $obj.Close()
}
