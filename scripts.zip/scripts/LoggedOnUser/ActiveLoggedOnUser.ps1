﻿# Get Active Logged On Users from List of Servers

$servers = Get-Content -Path "C:\Temp\computers.txt"
$export = @()
$export+="Updated: "+(Get-Date)
foreach ($server in $servers){
    $result=query user /server:$server
    if ($result -eq $null){
            $timestamp = (Get-Date)
            $export += $server+" "+$timestamp+" "+"NO ACTIVE SESSIONS FOUND"
    }else{
        $export+="`t"+"`t"+"`t"+"`t"+$result.GetValue(0)
        foreach ($i in $result) {
            if ($i -like "*Active*"){
                $timestamp = (Get-Date)
                $export += $server+" "+$timestamp+" "+$i
            }
        }
    }
}
# $timestamp = (Get-Date -Format s).Replace(":","-")
$export | Out-File C:\Temp\DVQA_LoggedOnUsers.txt
