﻿# Get Logged On Users from List of Servers
# This does not distinguish Active vs Disconnected

$servers = Get-Content -Path "C:\Temp\computers.txt"
$export = @()
$export+="Updated: "+(Get-Date)

foreach ($server in $servers){
    $GetLoggedOnUser = Get-WmiObject Win32_Process -Filter 'name="explorer.exe"' -ComputerName $server | foreach {$owner = $_.GetOwner(); '{0}\{1}' -f $owner.Domain, $owner.User} | Sort | Get-Unique
    If ($GetLoggedOnUser -eq $null){
        $export += $server + "`t" + (Get-Date) + "`t" + "NO SESSIONS FOUND"
    }else{
    $export+=$server + "`t" + (Get-Date) + "`t" + $GetLoggedOnUser
    }
}

$export