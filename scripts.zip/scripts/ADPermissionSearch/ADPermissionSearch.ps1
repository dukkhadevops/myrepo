﻿# AD Permission Search

Import-Module ActiveDirectory
$Results = @()
# Set location for command prompt
cd 'AD:\DC=cbc,DC=local'

# Get all OUs recursively 
$OUs = Get-ChildItem -Recurse | where ObjectClass -eq organizationalUnit

# Loop through each OU
foreach($OU in $OUs){

    $Path = "AD:\" + $OU.DistinguishedName # An alternative is $OU.PSPath

    # Get permissions, excluding the accounts with multiple entries
    $Perms = Get-Acl $Path | Select -ExpandProperty Access | ?{($_.IdentityReference -notlike "NT AUTHORITY\*") -and ($_.IdentityReference -notlike "*Exchange*")}

    # Loop through each permission to find a specific group
    foreach ($Perm in $Perms){
        # Check each identity to match group
        if($Perm.IdentityReference -eq "WORLD\Global AD Object Admins"){
            # Create an object for each match found and add all values to it
            $Found = New-Object PSObject
            $Found | Add-Member -MemberType NoteProperty -Name "DistinguishedName" -Value $OU.DistinguishedName
            $Found | Add-Member -MemberType NoteProperty -Name "ActiveDirectoryRights" -Value $Perm.ActiveDirectoryRights
            $Found | Add-Member -MemberType NoteProperty -Name "InheritanceType" -Value $Perm.InheritanceType
            $Found | Add-Member -MemberType NoteProperty -Name "ObjectType" -Value $Perm.ObjectType
            $Found | Add-Member -MemberType NoteProperty -Name "InheritedObjectType" -Value $Perm.InheritedObjectType
            $Found | Add-Member -MemberType NoteProperty -Name "ObjectFlags" -Value $Perm.ObjectFlags
            $Found | Add-Member -MemberType NoteProperty -Name "AccessControlType" -Value $Perm.AccessControlType
            $Found | Add-Member -MemberType NoteProperty -Name "IdentityReference" -Value $Perm.IdentityReference
            $Found | Add-Member -MemberType NoteProperty -Name "IsInherited" -Value $Perm.IsInherited
            $Found | Add-Member -MemberType NoteProperty -Name "InheritanceFlags" -Value $Perm.InheritanceFlags
            $Found | Add-Member -MemberType NoteProperty -Name "PropagationFlags" -Value $Perm.PropagationFlags
            # Add the object to the results
            $Results += $Found
        }
    }
}
# Export Results to CSV
$Results | Export-Csv C:\Temp\ADPermissionSearch.csv -NoTypeInformation