﻿# Create the scripting object
$TaskScheduler = New-Object -ComObject Schedule.Service

# Connect to the task scheduler library on the local machine
$TaskScheduler.Connect('localhost')

# Retrieve all (non-hidden) tasks from the root folder
$RootFolder = $TaskScheduler.GetFolder('\')
$Tasks = $RootFolder.GetTasks(0)

# Iterate over each task and delete it
foreach($Task in $Tasks){
    $RootFolder.DeleteTask($Task.Name,$null)
}