#ifyouwanttotestfirst
#change test lstn record around � swap the ttl & record to point to something else � then run this to change it to 1min ttl & points to blah.cbc.local

$OldObj = Get-DnsServerResourceRecord -ComputerName "uadc01uwcp"-Name "LSTNMattTest" -ZoneName "cbc.local"
$NewObj = $OldObj.Clone()
$NewObj.TimeToLive = [System.TimeSpan]::FromMinutes(1)
$NewObj.RecordData.HostNameAlias = "blah.cbc.local."
Set-DnsServerResourceRecord -ComputerName "uadc01uwcp" -NewInputObject $NewObj -OldInputObject $OldObj -ZoneName "cbc.local" -PassThru 