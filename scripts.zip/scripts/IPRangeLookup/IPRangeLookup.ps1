﻿# IP Range Lookup

#$outpath = "C:\GIT\Scripts\IPRangeLookup\output.txt"
#$subnet = "10.255.102"

$subnet = "10.255.15"
$date = Get-Date -Format MM-dd-yyyy
$outpath = "C:\Temp\" + $subnet.Replace(".","-") + "_" + $date + ".txt"

$stuff = 1..254 | ForEach-Object {Get-WmiObject Win32_PingStatus -Filter "Address='$subnet.$_' and Timeout=200 and ResolveAddressNames='true' and StatusCode=0" | select ProtocolAddress*}
$stuff | Format-Table | Out-File $outpath
