﻿# Disk Online and Initialize

[int]$i=1 # Starting Disk #
do{
    Set-Disk -Number $i -IsOffline $false
    $size = [Math]::Round(((Get-Disk -Number $i).Size/1GB))
    if ($size -lt 1){
        Initialize-Disk -Number $i -PartitionStyle MBR
        Write-host "Disk $i is MBR - Size = $size"
    }else{
        Initialize-Disk -Number $i -PartitionStyle GPT
        Write-host "Disk $i is GPT - Size = $size"
    }
    $i++
}while($i -lt 20) # Change value depending on how many disks