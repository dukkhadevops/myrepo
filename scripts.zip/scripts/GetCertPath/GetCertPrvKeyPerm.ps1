﻿
Function Get-CertPrvKeyPerm {

    $Result = @()
    $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\"
    $localcerts = Get-ChildItem -Path cert:\LocalMachine\My
    foreach ($cert in $localcerts){
        $keyName = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
        $keyFullPath = $keyPath + $keyName
        #$acl = (Get-Item $keyFullPath).GetAccessControl('Access')
        $acl = Get-Acl $keyFullPath | Select -ExpandProperty Access | ?{($_.IdentityReference -notlike "BUILTIN\Administrators") -and ($_.IdentityReference -notlike "NT AUTHORITY\SYSTEM")}
        $Result += $acl
    }
    $Result
}

Get-CertPrvKeyPerm
