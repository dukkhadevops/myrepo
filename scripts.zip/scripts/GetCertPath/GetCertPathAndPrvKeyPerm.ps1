﻿# Customized by J.Basso and M.Keller

Function Get-CertificatePath {
    <#
    .SYNOPSIS
        Function to get all certificate in in a certificate path (chain)
 
    .DESCRIPTION
        Function to get and display all the properties of the certificates in a certificate path (chain) until the Root CA.
 
            The Function would use Authority Key Identifier and the Subject Key Identifier to determine the certificate path
 
    .PARAMETER CertificateName
        Pass the certificate name you are looking for. This can be a exact match with wildcard
 
    .PARAMETER ParentAKI
        Not available for the user to use via the pipeline, this parameter is used internally to look for the certificates in the validation chain recursively
    
    .PARAMETER Recurse
        If this switch is ON, the function will recusivley call itself through the certificate chain until it gets to the Root CA. 
    
    .PARAMETER CertificateStore
        Pass the certificateStore name to search for certificate only in certain Store. Default is "My" and you can pass "" to search in all stores. 
    
            
    .EXAMPLE
        Get-CertificatePath -CertificateName "mywebsite*" -Recurse -CertificateStore ""
 
            Searchs all certificates on the local machine and filter them out to find the certificate that matches the name passed (using the "Subject" property).
            If more than one certificate matches, they will be looped into individually 
            The function will call itself recursively until the issuer and the subject are the same - which means we have reached the Root CA.
    
    .EXAMPLE
        $Computername = "Computer1","Computer2","Computer3"
        $CertificateName = "Mywebsite.MyDomain.com" 
        
        $res = @()         
        $getVert_Def = "Function Get-CertificatePath { ${function:Get-CertificatePath}} "
        $Computername | % {
            $res += icm -ComputerName $_ -ArgumentList $getVert_Def -ScriptBlock {
            Param($getVert_Def)
            .([scriptblock]::Create($getVert_Def)) 
            Get-CertificatePath -CertificateName $using:CertificateName 
            } 
        }
        $res
    
        Runs the Function on remote computers using invoke-command 
        Starts by creating an array of computer names which you would like to remotely run the function against. 
        Creates a parameter to pass the certificate you are looking for
        Create a definition to the function so we can pass it to each remote invoke-command 
        Loop inside the array of computers and pass the function and run it against each one of them using invoke-command. 
 
   
    .FUNCTIONALITY
        PowerShell Language
 
    .NOTES
        Credit to Splunk Base for Certificate Authority Situational Awareness
            https://splunkbase.splunk.com/app/3113/       
            https://github.com/nsacyber/Certificate-Authority-Situational-Awareness    
        Author: Amir Joseph Sayes
                www.Ninaronline.com 
        Version: 1.0
        
 
    .LINK
        https://ninaronline.com/2019/01/01/certificate-trust-issue-when-setting-ssl-relay-with-citrix-xml-service/
 
    #>
    
    [cmdletbinding()]
    Param ( 
    [parameter(ValueFromPipeline = $True,ValueFromPipeLineByPropertyName = $True)] 
    [string]$CertificateName = "*", 
 
    [parameter(ValueFromPipeline = $False,ValueFromPipeLineByPropertyName = $True)] 
    [string]$ParentAKI,
 
    [switch]$Recurse,
 
    [parameter(ValueFromPipeline = $True,ValueFromPipeLineByPropertyName = $True)] 
    [ValidateSet("TrustedPublisher","Remote Desktop","Root","TrustedDevices","CA","REQUEST","AuthRoot","TrustedPeople","addressbook","My","SmartCardRoot","Trust","Disallowed","SMS","")]
    [string]$CertificateStore = "My"
    )

    $Called_Cert = @()
    $Certificates = Get-ChildItem -Path Cert:\LocalMachine\$CertificateStore -Recurse | Where {-not $_.PSIsContainer} | 
    Select PSParentPath,FriendlyName,Subject,Issuer,Thumbprint,NotAfter,PrivateKey,    
    @{Name='Template';Expression={($_.Extensions | Where {$_.Oid.FriendlyName -match 'Template'}).Format(0) -replace "(.+)?=(.+)\((.+)?", '$2'}},
    @{Name='Authority_Key_Identifier';Expression={($_.Extensions | Where {$_.Oid.FriendlyName -eq 'Authority Key Identifier'}).Format(0)}},
    @{Name='Subject_Key_Identifier';Expression={($_.Extensions | Where {$_.Oid.FriendlyName -eq 'Subject Key Identifier'}).Format(0)}},
    @{Name='CertShortName';Expression={($_.Subject.split(",")[0]).trimstart("CN=")}} | Sort Thumbprint -Unique

    $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\"
    ForEach ($Cert in $Certificates) {
        $keyName = $Cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
        $keyFullPath = $keyPath + $keyName
        $acl = Get-Acl $keyFullPath | Select -ExpandProperty Access | ?{($_.IdentityReference -notlike "BUILTIN\Administrators") -and ($_.IdentityReference -notlike "NT AUTHORITY\SYSTEM")}
        $Cert | Add-Member -MemberType NoteProperty -Name 'FileSystemRights' -Value $acl.FileSystemRights
        $Cert | Add-Member -MemberType NoteProperty -Name 'AccessControlType' -Value $acl.AccessControlType
        $Cert | Add-Member -MemberType NoteProperty -Name 'IdentityReference' -Value $acl.IdentityReference
        $Cert | Add-Member -MemberType NoteProperty -Name 'IsInherited' -Value $acl.IsInherited
        $Cert | Add-Member -MemberType NoteProperty -Name 'InheritanceFlags' -Value $acl.InheritanceFlags
        $Cert | Add-Member -MemberType NoteProperty -Name 'PropagationFlags' -Value $acl.PropagationFlags
        $Called_Cert += $Cert | Select PSParentPath,FriendlyName,Subject,Issuer,Thumbprint,NotAfter,
        @{Name='Template';Expression={(($_.Template.Split(','))[0]) -replace "Template=",""}},
        Authority_Key_Identifier,Subject_Key_Identifier,CertShortName,PrivateKey,FileSystemRights,AccessControlType,IdentityReference,IsInherited,InheritanceFlags,PropagationFlags
    }
        
        if (!($ParentAKI)) { 
        $Called_Cert = $Called_Cert | Where {$_.CertShortName -like "$CertificateName"} 
        }
        elseif ($ParentAKI) {
        $Called_Cert = $Called_Cert | Where {$_.Subject_Key_Identifier -eq $ParentAKI} | Select -First 1
        }
 
        If ($Recurse) {
            #Loop and recursively retrieve the certificates in the chain until Root CA 
            $Called_Cert | % { 
                if ($_.Authority_Key_Identifier -ne $null) {
                    $CertParentAKI = ($_.Authority_Key_Identifier.split("=")[1])
                    #Adding the Cert name as a member in the original object 
                    $_ | Add-Member -MemberType NoteProperty -Name 'CertParentAKI' -Value $CertParentAKI 
                }
                else {
                    $CertParentAKI = 0 
                    $_ | Add-Member -MemberType NoteProperty -Name 'CertParentAKI' -Value $CertParentAKI 
                }
            #Output the results 
            $_ 
            #If recurse switch was On and we have not reached the Root CA then call the function and pass the AKI of the issure of the current certificate
            if ($_.CertParentAKI -ne $_.Subject_Key_Identifier -and $_.CertParentAKI -ne 0) 
            {
                Get-CertificatePath -ParentAKI $_.CertParentAKI -Recurse -CertificateStore "" 
            } 
 
                } #End Loop
                } 
        else {
        # if no recurse was chosen then just show the results without looping
        $Called_Cert
        }# End If 
}

$Computers = Get-Content -Path "C:\GIT\Scripts\GetCertPath\computers.txt"
$CertificateName = "*"
$Result = @()
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"
$getFunction = "Function Get-CertificatePath { ${function:Get-CertificatePath}} "

Foreach ($target in $computers){
    $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
    $localcerts = Invoke-Command -Session $session -ArgumentList $getFunction -ScriptBlock {
    Param($getFunction)
    .([scriptblock]::Create($getFunction))
    Get-CertificatePath -CertificateName $using:CertificateName -Recurse | Select PSParentPath,FriendlyName,Subject,Issuer,Thumbprint,NotAfter,Template,PrivateKey,FileSystemRights,AccessControlType,IdentityReference,IsInherited,InheritanceFlags,PropagationFlags
    }
    Remove-PSSession $session
    $Result += $localcerts | Select @{Name='Server';Expression={$_.PSComputerName}},@{Name='Path';Expression={$_.PSParentPath.Substring(43)}},FriendlyName,Thumbprint,@{Name='Expiration';Expression={$_.NotAfter}},Subject,Issuer,Template,PrivateKey,FileSystemRights,AccessControlType,IdentityReference,IsInherited,InheritanceFlags,PropagationFlags
}
$Result | Export-Csv C:\Git\scripts\GetCertPath\LocalCertsAndPerms.csv -NoTypeInformation