﻿# Script to copy IISCredentials script out to server and run it locally

$computers = Get-Content -Path "C:\GIT\Scripts\DV\IISCredentials\computers.txt"

$localdscscriptpath = "C:\GIT\Scripts\DV\IISCredentials\IISCredentials.ps1"

echo " "
echo " "
echo "USE YOUR .1/ADMIN CREDENTIAL HERE"
echo " "
echo " "
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"
    
Foreach ($target in $computers) {
    # Start PSSession with $target computer
    $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"
    #full path to where we are copying the DSC scripts from/to
    $localfilepath = $localpath + "\IISCredentials.ps1"
    $destfilepath = $destpath + "\IISCredentials.ps1"
    #region copy DSC script out to hosts
        Try {
            Copy-Item -Path $localdscscriptpath -Destination $destfilepath -Force -ErrorAction Stop
            echo "DSC script copies okay on $target"
        }
        Catch {
                echo "failed copying DSC scripts on $target"
                break
        }
        #endregion

        #region start IISCredentials script
        Try {
            echo " "
            echo "starting IISCredentials script run. This script is just resetting and assigning app pool identities for the most part so it should be fast."

            #invoke command to execute a ps1 script with $p7 parameter($p7 is the path argument for the script being called). -Argumentlist specifies $p7 parameter becomes $localfilepath2
            Invoke-Command -Session $session -scriptblock {
                param($p7) . $p7
                Remove-Item $p7
            } -ArgumentList $localfilepath -ErrorAction Stop
            echo " "
            echo "IISCredentials script finished running."
        }
        Catch {
            echo " "
            echo "IISCredentials script failed. try running it locally first"
            break
        }
        #endregion
        Remove-PSSession $session
}