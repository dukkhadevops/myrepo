﻿# 7zip Silent/Remote Install

$target = "dvweb02uwwl"

$7zipInstallPath = "\\fs\pub\collab\winsoftware\7zip\7z1900-x64.exe"

$LocalPath = "\\dvweb02uwwl\C$\scripts"

Copy-Item -Path $7zipInstallPath -Destination $LocalPath -ErrorAction Stop

Invoke-Command -ComputerName $target -ScriptBlock {cmd /c "C:\scripts\7z1900-x64.exe /S"} -ErrorAction Stop
