﻿# Processor Signatures - Runs at 8am everyday
# Robocopy from network share to local images (dvweb/intranet on PDF/WEB/INET)
# If the ProcessorSignatures folder exists, it will copy from the network share

# Rundeck server variable, if needed when running locally
#$server = "@node.hostname@"

# Create session for Rundeck to use Maintenance Account for script to run locally (target node = rundeck01uwap)
$credusername = "world\svc_dvRundeckMaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername,$credpasswordss)
$session = New-PSSession -ComputerName "rundeck01uwap" -Authentication Credssp -Credential $credential
Invoke-Command -Session $session -scriptblock {

    # Rundeck server list variable, manually added to job
    $nodeList = "@option.nodeList@"
    $nodes = $nodeList.split(",")

    # For loop to copy to each server
    Foreach ($node in $nodes) {
        #	Set up Log file with date
        $logpath = "\\$node\C$\scripts\logs"
        if (!(Test-Path $logpath)) {
            New-Item $logpath -ItemType Directory
        }
        $date = get-date -format MMddyy
        $dvweblogfile = "$logpath\DV-ProcessorSignatures-DVWEB-LOG-$date.txt"
        $inetlogfile = "$logpath\DV-ProcessorSignatures-INET-LOG-$date.txt"

        # Check for dvweb path
        if (Test-Path "\\$node\C$\www\dataverify\dvweb\images\ProcessorSignatures") {
            #	Robocopy Command line for dvweb images:
            robocopy "\\appfs\dv\prod\dv_shared_prod\WebApp Deploy\ProcessorSignatures" "\\$node\C$\www\dataverify\dvweb\images\ProcessorSignatures" /e /R:2 /W:2 /NP /LOG:$dvweblogfile
        }

        # Check for intranet path
        if (Test-Path "\\$node\C$\www\dataverify\intranet\images\ProcessorSignatures") {
            #	Robocopy Command line for intranet images:
            robocopy "\\appfs\dv\prod\dv_shared_prod\WebApp Deploy\ProcessorSignatures" "\\$node\C$\www\dataverify\intranet\images\ProcessorSignatures" /e /R:2 /W:2 /NP /LOG:$inetlogfile
        }
    }
}
Remove-PSSession $session