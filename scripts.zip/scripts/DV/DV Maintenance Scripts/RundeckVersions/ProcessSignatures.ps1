Function copyLogs {
    $credusername = "world\svc_dvrundeckmaint_p"
    $credpassword = "@option.Password@"
    $credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
    $credentials = New-Object System.Management.Automation.PSCredential($credusername, $credpasswordss)
    $session = New-PSSession -ComputerName "rundeck01uwap" -Authentication Credssp -Credential $credentials
    Invoke-Command -Session $session -scriptblock {
        $nodeList = "@option.nodeList@"
        $nodes = $nodeList.split(",")
        $date = get-date -format MMddyy
        ForEach ($node in $nodes) {
            # Processor Signatures - Runs at 8am everyday
            # Robocopy from network share to local images (dvweb/intranet on PDF/WEB/INET)
            $logPath = "\\$node\C$\scripts\logs"
            if (!(Test-Path $logpath)) {
                New-Item $logpath -ItemType Directory | Out-Null
            }
            $dvweblogfile = "$logPath\DV-ProcessorSignatures-DVWEB-LOG-$date.txt"
            $inetlogfile = "$logPath\DV-ProcessorSignatures-INET-LOG-$date.txt"

            if (Test-Path "\\$node\C$\www\dataverify\dvweb\images\ProcessorSignatures") {
                #  Robocopy Command line for dvweb images:
                robocopy "\\appfs\dv\prod\dv_shared_prod\WebApp Deploy\ProcessorSignatures" "\\$node\C$\www\dataverify\dvweb\images\ProcessorSignatures" /e /R:2 /W:2 /NP /LOG:$dvweblogfile
                if ($lastExitCode -eq 16) {
                    Write-Host "RoboCopy failed with exit code: $($lastExitCode)"
                    exit 1
                }
                else {
                    Write-Host "RoboCopy Succeeded"
                }
            }

            if (Test-Path "\\$node\C$\www\dataverify\intranet\images\ProcessorSignatures") {
                #  Robocopy Command line for intranet images:
                robocopy "\\appfs\dv\prod\dv_shared_prod\WebApp Deploy\ProcessorSignatures" "\\$node\C$\www\dataverify\intranet\images\ProcessorSignatures" /e /R:2 /W:2 /NP /LOG:$inetlogfile
                if ($lastExitCode -eq 16) {
                    Write-Host "RoboCopy failed with exit code: $($lastExitCode)"
                    exit 1
                }
                else {
                    Write-Host "RoboCopy Succeeded"
                }
            } 
        }
    }
    Remove-PSSession $session
}

copyLogs