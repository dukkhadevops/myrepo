# Archive File Share Maintenance – Runs at 5am everyday
# Cleans up specific folders on the Archive File Share

# Rundeck server variable, if needed when running locally
#$server = "@node.hostname@"

# Create session for Rundeck to use Maintenance Account for script to run locally (target node = rundeck01uwap)
$credusername = "world\svc_dvrundeckmaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername, $credpasswordss)
$session = New-PSSession -ComputerName "rundeck01uwap" -Authentication Credssp -Credential $credentials
Invoke-Command -Session $session -scriptblock {
    Function setVars {
        # Root File Share
        $Script:DVDFSArchiveWebClusterFiles = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles"
        $Script:DVDFSArchiveWebClusterFilesDrive = "\\?\R:\"
        $Script:batchQue = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles\4506SSA\BatchQue"
        $Script:deleteFax = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles\4506SSA\DeleteFax"
        $Script:drivePdf = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles\drivepdf"
        $Script:incomingFax = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles\fax\inbound\SSA\INCOMINGFAX"
        $Script:temp = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles\temp"
        $Script:watchlistAuthRequests = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles\watchlistauthrequests"

        # Set up Log file with date
        $Script:logPath = "\\appfs\dv\prod\dv_shared_prod\Logs\MaintenanceLogs"
        $Script:date = get-date -format MMddyy
        $Script:logFile = "$Script:logPath\DV-ArchiveMaintenance-LOG-$Script:date.txt"
        New-Item $Script:logFile -Type "file" -Force | Out-Null
        logWrite "Created logfile - $($Script:logFile)"
        Write-Host "Created logfile - $($Script:logFile)"
    }

    Function CreateSMBDrive {
        try {
            New-SmbMapping -LocalPath R: -RemotePath "$Script:DVDFSArchiveWebClusterFiles" -Persistent $true -ErrorAction Stop | Out-Null
            Write-Host "Created drives."
        }
        catch {
            Write-Host "Failed to create SMBDrive: please investigate."
            ## Needs to exit as with no drive the rest will fail
            exit 1
        }
    }

    Function RemoveSMBDrive {
        try {
            Remove-SmbMapping -LocalPath R: -UpdateProfile -Force | Out-Null
            Write-Host "Removed drives."
        }
        catch { 
            Write-Host "Failed to remove SMBDrive: Drive is probably in use."
        }
    }

    Function logWrite {
        # Function to write to log file
        Param ([string]$message)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $Line = "$Stamp - $message"
        Add-content -path $Script:logFile -value $Line
    }

    Function CleanUp ($Folder, $Days, $Type) {
        if (Test-Path -LiteralPath $Folder) {
            logWrite "Running cleanup in $($Folder)."
            Write-Host "Running cleanup in $($Folder)."
            # Function to delete files based on number of days and log each delete
            #Get-ChildItem $Folder -Recurse -Force -include $Type | Where-Object { 
            #    $File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false } | 
            #try {
            #    Remove-Item -Force -Recurse 
            #    logWrite "Deleted Files"
            #    Write-Host "Deleted Files"
            #}
            #catch {
            #    logWrite "Failed to Delete Files"
            #    Write-Host "Failed to Delete Files"
            #}
            Get-ChildItem -LiteralPath $Folder -Recurse -Force -include $Type | ForEach-Object {
                if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false) {
                    try {
                        Remove-Item $File.FullName -Force -Recurse
                        logWrite "Deleted - $($File.FullName)"
                        Write-Host "Deleted - $($File.FullName)"
                    }
                    catch {
                        logWrite "Failed to Delete - $($File.FullName)"
                        Write-Host "Failed to Delete - $($File.FullName)"
                    }
                }
            }
        }
        else {
            logWrite "$($Folder) does not exist yet, moving on."
            Write-Host "$($Folder) does not exist yet, moving on."
        }
        logWrite "Cleanup in $($Folder) complete."
        Write-Host "Cleanup in $($Folder) complete."
    }

    setVars
    LogWrite "Starting Cleanup"
    Write-Host "Starting Cleanup"
    #CreateSMBDrive
    Cleanup "$Script:batchQue" 1 '*'
    Cleanup "$Script:deleteFax" 1 '*'
    Cleanup "$Script:drivePdf" 30 '*.enc'
    Cleanup "$Script:incomingFax" 1 '*.pdf'
    Cleanup "$Script:temp" 1 '*'
    Cleanup "$Script:watchlistAuthRequests" 1 '*'
    #Cleanup "$Script:DVDFSArchiveWebClusterFilesDrive" 1825 '*'
    Cleanup "$Script:DVDFSArchiveWebClusterFiles" 1825 '*'
    logWrite "Cleanup Complete"
    Write-Host "Cleanup Complete"
    #RemoveSMBDrive
}
Remove-PSSession $session