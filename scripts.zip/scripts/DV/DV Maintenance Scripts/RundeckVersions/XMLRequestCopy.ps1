# XMLRequestMove – Runs at 4am everyday
# Moves XML Requests from C:\app\requestlogs and C:\app\XmlReq to a network share (APP/GW/WEB Servers)
# The network share is organized with folders by server names and dates
# Script must log into each APP/GW/WEB server and run locally
$credusername = "world\svc_dvrundeckmaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername, $credpasswordss)
$nodeList = "@option.nodeList@"
$nodes = $nodeList.split(",")
ForEach ($node in $nodes) {
    $session = New-PSSession -ComputerName "$node" -Authentication Credssp -Credential $credentials
    Invoke-Command -Session $session -scriptblock {

        Function setVars {
            $Script:date = get-date -format MMddyy
            # Network share for XML Requests
            $Script:xmlReqShare = "\\appfs\dv\prod\dv_shared_prod\xmlreqs"
            # Local server running the script (Used to define the folder on the share, noting where the files are moved from)
            $Script:server = $env:COMPUTERNAME
            $Script:logpath = "C:\scripts\logs"
            $Script:logfile = "$Script:logpath\DV-XMLRequestMove-LOG-$Script:date.txt"
            $Script:reqLogs = "C:\app\requestlogs"
            $Script:xmlReq = "C:\app\XmlReq"
        }

        Function logWrite {
            # Function to write to log file
            Param ([string]$message)
            $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
            $Line = "$Stamp - $message"
            Add-content -path $logfile -value $Line
        }

        Function setupLogging {
            # Set up Log file with date
            if (!(Test-Path $Script:logpath)) {
                try {
                    New-Item $Script:logpath -ItemType Directory -Force -ErrorAction Stop | Out-Null
                    logWrite "Created $($Script:logpath)"
                    Write-Host "Created $($Script:loglogpathfile)"
                }
                catch {
                    logWrite "Failed to create $($Script:logpath)"
                    Write-Host "Failed to create $($Script:logpath)"
                }
            }
            try { 
                New-Item $Script:logfile -ItemType File -Force -ErrorAction Stop | Out-Null
                logWrite "Created $($Script:logfile)"
                Write-Host "Created $($Script:logfile)"
            }
            catch {
                logWrite "Failed to create $($Script:logfile)"
                Write-Host "Failed to create $($Script:logfile)"
            }
        }
    
        Function copyFiles {
            # Copy each file from C:\app\XmlReq to network share using server name and date
            if (Test-Path "$Script:xmlReq") {
                LogWrite "Starting Copy for $($Script:xmlReq)"
                Write-Host "Starting Copy for $($Script:xmlReq)"
                Foreach ($File in Get-ChildItem "$Script:xmlReq") {   
                    If ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1))) {
                        $filedate = $File.lastwritetime.tostring("MM-dd-yyyy")
                        If ((Test-Path "$Script:xmlReqShare\$Script:server\xmlreq\$filedate") -eq $False) {
                            try {                
                                New-Item -ItemType Directory "$Script:xmlReqShare\$Script:server\xmlreq\$filedate"
                                LogWrite "Created Folder - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                                Write-Host "Created Folder - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                            }
                            catch {
                                LogWrite "Failed to Create Folder - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                                Write-Host "Failed to Create Folder - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                            }
                        }
                        try {
                            if (!(Test-Path "$Script:xmlReqShare\$Script:server\xmlreq\$filedate\$($File.Name)")) {
                                Copy-Item $File.FullName "$Script:xmlReqShare\$Script:server\xmlreq\$filedate" -Force -ErrorAction Stop
                                LogWrite "Copied - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                                Write-Host "Copied - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                            }
                        }
                        catch {
                            LogWrite "Failed to Copy - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                            Write-Host "Failed to Copy - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\xmlreq\$($filedate)"
                        }
                    }
                }
                LogWrite "Completed Copy for $($Script:xmlReq)"
                Write-Host "Completed Copy for $($Script:xmlReq)"
            }
            else {
                LogWrite "$($Script:xmlReq) does not exist"
                Write-Host "$($Script:xmlReq) does not exist"
            }

            # Copy each file from C:\app\requestlogs to network share using server name and date
            if (Test-Path "$Script:reqLogs") {
                LogWrite "Starting Copy for $($Script:reqLogs)"
                Write-Host "Starting Copy for $($Script:reqLogs)"
                Foreach ($File in Get-ChildItem "$Script:reqLogs") {   
                    If ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1))) {
                        $filedate = $File.lastwritetime.tostring("MM-dd-yyyy")
                        If ((Test-Path "$Script:xmlReqShare\$Script:server\requestlogs\$filedate") -eq $False) {
                            try {                
                                New-Item -ItemType Directory "$Script:xmlReqShare\$Script:server\requestlogs\$filedate"
                                LogWrite "Created Folder - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                                Write-Host "Created Folder - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                            }
                            catch {
                                LogWrite "Failed to Create Folder - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                                Write-Host "Failed to Create Folder - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                            }
                        }
                        try {
                            if (!(Test-Path "$Script:xmlReqShare\$Script:server\requestlogs\$filedate\$($File.Name)")) {
                                Copy-Item $File.FullName "$Script:xmlReqShare\$Script:server\requestlogs\$filedate" -Force -ErrorAction Stop
                                LogWrite "Copied - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                                Write-Host "Copied - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                            }
                        }
                        catch {
                            LogWrite "Failed to Copy - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                            Write-Host "Failed to Copy - $($File) - TO - $($Script:xmlReqShare)\$($Script:server)\requestlogs\$($filedate)"
                        }
                    }
                }
                LogWrite "Completed Copy for $($Script:reqLogs)"
                Write-Host "Completed Copy for $($Script:reqLogs)"
            }
            else {
                LogWrite "$($Script:reqLogs) does not exist"
                Write-Host "$($Script:reqLogs) does not exist"
            }
        }

        setVars
        setupLogging
        copyFiles
    }
    Remove-PSSession $session
}