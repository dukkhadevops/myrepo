# Local File Maintenance – Runs weekly, every Sunday, 5am for ODD servers, 5:30am for EVEN servers
# Cleans up specific folders on the local server
# Script must log into each server and run locally
# Applies to ALL DataVerify servers

Function setVArs {
    $Script:Restart = "shutdown -r -f -t 5"

    # Set up Log file with date
    $logpath = "C:\scripts\logs"
    if (!(Test-Path $logpath)) {
        New-Item $logpath -ItemType Directory
    }
    $date = get-date -format MMddyy
    $logfile = "$logpath\DV-LocalFileMaintenance-LOG-$date.txt"
    New-Item $logfile -Type "file" -Force | Out-Null
    Write-Host "$($logfile) created successfully."

    # Paths
    $Script:P1 = "C:\app\log"
    $Script:P2 = "C:\app\XmlReq"
    $Script:P3 = "C:\app\requestlogs"
    $Script:P4 = "C:\scripts\logs"
    $Script:P5 = "C:\Program Files (x86)\dynaTrace"
    $Script:P6 = "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files"
    $Script:P7 = "C:\ProgramData\Microsoft\Windows\WER"
    $Script:P8 = "Running cleanup in C:\inetpub\logs"

}

Function stopIIS {
    & iisreset /stop 2>&1>null
    if (-not $?) {
        logWrite "An error occured stopping IIS."
        throw "An error occured stopping IIS."
        exit 1
    }
    else {
        logWrite "Stopped IIS with no errors."
        Write-Output "Stopped IIS with no errors."
    }
    if ((Get-Process | Where-Object { $_.ProcessName -eq "w3wp" }).Length -gt 0) {
        $processes = (Get-Process | Where-Object { $_.ProcessName -eq "w3wp" })
        for ($i = 0; $i -le $processes.length; $i++) {
            try {
                Stop-Process -Id $processes[$i].Id -ErrorAction Stop
            }
            catch {
                logWrite "An error occured stopping IIS, exiting."
                Write-output "An error occured stopping IIS, exiting."
                exit 1
            }
        }
    }
}

Function LogWrite {
    # Function to write to log file
    Param ([string]$message)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp - $message"
    Add-content -path $logfile -value $Line
}

Function CleanUp ($Folder, $Days, $Type) {
    if (Test-Path $Folder) {
        logWrite "Running cleanup in $($Folder)."
        Write-Host "Running cleanup in $($Folder)."
        # Function to delete files based on number of days and log each delete
        foreach ($File in Get-ChildItem $Folder -Recurse -include $Type) {
            if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false) {
                try {
                    Remove-Item $File.FullName -Force -ErrorAction Stop
                    LogWrite "Deleted - $($File.FullName)"
                    Write-Host "Deleted - $($File.FullName)"
                }
                catch {
                    LogWrite "Failed to Delete - $($File.FullName)"
                    Write-Host "Failed to Delete - $($File.FullName)"
                }
            }
        }
    }
    else {
        logWrite "Cannot find $($Folder), moving on."
        Write-Host "Cannot find $($Folder), moving on."
    }
    logWrite "Cleanup in $($Folder) complete."
    Write-Host "Cleanup in $($Folder) complete."
}

setVArs
stopIIS
Start-Sleep -Seconds 5

# Start the cleanup job write a log after each cleanup with a timestamp
LogWrite "Starting Cleanup." 
Write-Host "Starting Cleanup."

# Application Logs (Changed from 5 to 7)
CleanUp "$Script:P1" 7 '*'
# XML Requests
CleanUp "$Script:P2" 7 '*'
# Request Logs (Changed from 5 to 7)
CleanUp "$Script:P3" 7 '*'
# Maintenance Logs
CleanUp "$Script:P4" 7 '*'
# Dynatrace Logs (Changed from 5 to 7)
CleanUp "$Script:P5" 7 '*.log*'
# ASP.NET Temporary Files
CleanUp "$Script:P6" 0 '*'   
# Windows Error Reporting Logs
CleanUp "$Script:P7" 3 '*'
# IIS Logs (Changed from 5 to 7)
CleanUp "$Script:P8" 7 '*'
    
LogWrite "Cleanup Complete"
Write-Host "Cleanup Complete"

# Restart the machine
Invoke-Expression -Command $Script:Restart | Out-Null

LogWrite "Restarting the server."
Write-Host "Restarting the server."