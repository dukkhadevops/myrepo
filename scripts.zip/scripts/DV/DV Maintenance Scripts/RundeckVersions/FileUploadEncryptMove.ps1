# FileUploadEncryptMove - Runs at 3am everyday
# Encrypt and Move user uploaded files from C:\app\TempUpload to network share (only on WEB Servers)
# Script must log into each WEB server and run locally
$credusername = "world\svc_dvrundeckmaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername, $credpasswordss)
$nodeList = "@option.nodeList@"
$nodes = $nodeList.split(",")
ForEach ($node in $nodes) {
    $session = New-PSSession -ComputerName "$node" -Authentication Credssp -Credential $credentials
    Invoke-Command -Session $session -scriptblock {
        Function setVars {        
            $Script:logpath = "C:\scripts\logs"
            $Script:tempUpload = "C:\app\TempUpload"
            # DV Custom App for Encrypting files (only on WEB Servers)
            $Script:DVSec = "C:\app\dvsec\dvsec.exe"
            # Network share for Encrypted files
            $Script:UploadFilesEnc = "\\appfs\dv\prod\dv_shared_prod\UploadFilesEnc"
        }
        Function logWrite {
            # Function to write to log file
            Param ([string]$message)
            $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
            $Line = "$Stamp - $message"
            Add-content -path $logfile -value $Line
        }

        Function cleanUp ($Folder, $Days, $Type) {
            if (Test-Path $Folder) {
                # Function to delete files and log each delete
                foreach ($File in Get-ChildItem $Folder -Recurse -include $Type) {
                    if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false) {
                        try {
                            Remove-Item $File.FullName -Force -ErrorAction Stop | Out-Null
                            LogWrite "Deleted - $($File.FullName)"
                            Write-Host "Deleted - $($File.FullName)"
                        }
                        catch {
                            LogWrite "Failed to delete - $($File.FullName)"
                            Write-Host "Failed to delete - $($File.FullName)"
                        }
                    }
                }
            }
            else {
                LogWrite "$($Folder) does not exist, continuing."
                Write-Host "$($Folder) does not exist, continuing."
            }
        }
        Function setupLogging {
            # Set up Log file with date
            if (!(Test-Path $Script:logpath)) {
                try {
                    New-Item $Script:logpath -ItemType Directory -ErrorAction Stop | Out-Null
                }
                catch {
                    LogWrite "Failed to create $($Script:logpath)"
                    Write-Host "Failed to create $($Script:logpath)"
                }
            }
            $Script:date = get-date -format MMddyy
            $Script:logfile = "$Script:logpath\DV-FileUploadEncryptMove-LOG-$Script:date.txt"

            try {
                New-Item $Script:logfile -ItemType File -Force -ErrorAction Stop | Out-Null
            }
            catch {
                LogWrite "Failed to create $($Script:logfile)"
                Write-Host "Failed to create $($Script:logfile)"
            }
        }
    
        Function encrypt {
            # Encrypt each file in C:\app\TempUpload
            if (Test-Path $Script:tempUpload) {
                foreach ($File in Get-ChildItem "$Script:tempUpload" -Recurse) {
                    & $Script:DVSec -e $File.FullName
                    if ($?) {            
                        LogWrite "Encrypted - $($File.FullName)."   
                        Write-Host "Encrypted - $($File.FullName)."         
                    }
                    else {            
                        LogWrite "Failed to encrypt - $($File.FullName)."  
                        Write-Host "Failed to encrypt - $($File.FullName)."          
                    }   
                }
            }
            else {
                LogWrite "$($Script:tempUpload) does not exist."
                Write-Host "$($Script:tempUpload) does not exist."
            }
        }

        Function moveFiles {
            if (Test-Path $Script:tempUpload) {
                # Move encrypted files to \\appfs\dv\prod\dv_shared_prod\UploadFilesEnc
                foreach ($File in Get-ChildItem "$Script:tempUpload" -Recurse -Include *.enc) {
                    try {
                        Move-Item -Path $File -Destination $Script:UploadFilesEnc -Force -ErrorAction Stop | Out-Null
                        LogWrite "Moved - $($File.FullName)."
                        Write-Host "Moved - $($File.FullName)."
                    }
                    catch {
                        LogWrite "Failed to move - $($File.FullName)." 
                        Write-Host "Failed to move - $($File.FullName)."
                    }
                }
            }
            else {
                LogWrite "$($Script:tempUpload) does not exist."
                Write-Host "$($Script:tempUpload) does not exist."
            }
        }

        setVars
        setupLogging
        encrypt
        moveFiles
        # Clean up the C:\app\TempUpload folder
        cleanup "$Script:tempUpload" 0 '*.*'
        logWrite "CleanUp Complete - $($Script:tempUpload)" 
        Write-Host "CleanUp Complete - $($Script:tempUpload)"
        
    }
    Remove-PSSession $session
}