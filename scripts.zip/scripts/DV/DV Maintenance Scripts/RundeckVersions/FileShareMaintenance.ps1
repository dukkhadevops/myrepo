# File Share Maintenance – Runs at 5am everyday
# Cleans up specific folders on the DV_FS and DV_Shared File Shares 

# Rundeck server variable, if needed when running locally
#$server = "@node.hostname@"

# Create session for Rundeck to use Maintenance Account for script to run locally (target node = rundeck01uwap)
$credusername = "world\svc_dvrundeckmaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername, $credpasswordss)
$session = New-PSSession -ComputerName "rundeck01uwap" -Authentication Credssp -Credential $credentials
Invoke-Command -Session $session -scriptblock {

    Function setVars {
        # Root folders for File Shares
        ## DVShared
        $Script:P1 = "\\appfs\dv\prod\dv_shared_prod\Logs\TaskLogs"
        $Script:P2 = "\\appfs\dv\prod\dv_shared_prod\Logs\MaintenanceLogs"
        $Script:P3 = "\\appfs\dv\prod\dv_shared_prod\Tasks\IRSRobot3_KenViviano\html\trans\backup"
        $Script:P4 = "\\appfs\dv\prod\dv_shared_prod\TaskLoads\UVLBulkMatch\Backup"
        $Script:P5 = "\\appfs\dv\prod\dv_shared_prod\TaskLoads\NMLS"
        $Script:P6 = "\\appfs\dv\prod\dv_shared_prod\UploadFilesEnc"
        $Script:P7 = "\\appfs\dv\prod\dv_shared_prod\xmlreqs"

        ## DVFSWebClusterFiles
        $Script:P8 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\4506SSA\Batchque"
        $Script:P9 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\4506SSA\DeleteFax"
        $Script:P10 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\creports"
        $Script:P11 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\drivepdf"
        $Script:P12 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\fax\inbound\SSA\IncomingFax"
        $Script:P13 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\Fax\outbound\backup"
        $Script:P14 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\temp"
        $Script:P15 = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles\watchlistauthrequests"

        # Set up Log file with date
        $Script:logPath = "\\appfs\dv\prod\dv_shared_prod\Logs\MaintenanceLogs"
        <# No need to create since it exists on the share
    if (!(Test-Path $logpath)) {
        New-Item $logpath -ItemType Directory
    }#>
        $Script:date = get-date -format MMddyy
        $Script:logFile = "$Script:logPath\DV-FileShareMaintenance-LOG-$Script:date.txt"
        New-Item $Script:logFile -Type "file" -Force
    }

    Function logWrite {
        # Function to write to log file
        Param ([string]$message)
        $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
        $Line = "$Stamp - $message"
        Add-content -path $Script:logFile -value $Line
    }

    Function cleanUp ($Folder, $Days, $Type) {
        # Function to delete files based on number of days and log each delete
        if (Test-Path $Folder) {
            logWrite "Running cleanup in $($Folder)."
            Write-Host "Running cleanup in $($Folder)."
            foreach ($File in Get-ChildItem $Folder -Recurse -include $Type) {
                if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false) {
                    try {
                        Remove-Item $File.FullName -Force
                        logWrite "Deleted - $($File.FullName)"
                        #Write-Host "Deleted - $($File.FullName)"
                    }
                    catch {
                        logWrite "Failed to Delete - $($File.FullName)"
                        Write-Host "Failed to Delete - $($File.FullName)"
                    }
                }
            }
        }
        else {
            logWrite "Cannot find $($Folder), moving on."
            Write-Host "Cannot find $($Folder), moving on."
        }
        logWrite "Cleanup in $($Folder) complete."
        Write-Host "Cleanup in $($Folder) complete."
    }

    Function DeleteEmptyFolders ($Path) {
        # Function for deleting empty folders
        LogWrite "Deleting empty directories found in $($Path)."
        Write-Host "Deleting empty directories found in $($Path)."
        $EmptyFolders = Get-ChildItem -Path $Path -Recurse -Force | 
        Where-Object { $_.PSIsContainer -and $null -eq ( Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer } ) }
        if ($null -ne $EmptyFolders) {
            $EmptyFolders | Foreach-Object {
                try {
                    Remove-Item $($_.FullName) -Force
                    LogWrite "Deleted Empty Folder - $($_.FullName)"
                    #Write-Host "Deleted Empty Folder - $($_.FullName)"
                }
                catch {
                    LogWrite "Failed to Delete Empty Folder - $($_.FullName)"
                    #Write-Host "Failed to Delete Empty Folder - $($_.FullName)"
                }
            }
        }
        else {
            LogWrite "No empty folders found in $($Path)"
            Write-Host "No empty folders found in $($Path)"
        }
    }

    setVars

    logWrite "Starting Cleanup Of DV_Shared Paths."
    Write-Host "Starting Cleanup Of DV_Shared Paths."

    # DV_Shared Paths
    cleanUp "$Script:P1" 30 '*'
    cleanUp "$Script:P2" 30 '*'
    cleanUp "$Script:P3" 10 '*.enc'
    cleanUp "$Script:P4" 60 '*.enc'
    cleanUp "$Script:P5" 30 '*'
    cleanUp "$Script:P6" 365 '*.enc'
    cleanUp "$Script:P7" 30 '*'
    DeleteEmptyFolders "$Script:P7"

    logWrite "Starting Cleanup Of DV_FS Paths."
    Write-Host "Starting Cleanup Of DV_FS Paths."

    # DV_FS Paths
    cleanUp "$Script:P8" 90 '*'
    cleanUp "$Script:P9" 90 '*'
    cleanUp "$Script:P10" 30 '*.oxo'
    cleanUp "$Script:P11" 30 '*.enc'
    cleanUp "$Script:P12" 14 '*.pdf'
    cleanUp "$Script:P13" 14 '*'
    cleanUp "$Script:P14" 7 '*'
    cleanUp "$Script:P15" 7 '*'

    logWrite "Cleanup Complete."
    Write-Host "Cleanup Complete."
}
Remove-PSSession $session

<# New command line for deleting empty folders with logging (if used, $path should be updated)
LogWrite "Deleting any empty directories left behind after deleting the old files."
$EmptyFolders = Get-ChildItem -Path $path -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null }
if ($EmptyFolders -ne $null) {
    $EmptyFolders | Foreach {
        LogWrite "Deleting Empty Folder - $($_.FullName)"
        try {
            Remove-Item $($_.FullName) -Force
        }
        catch {
            LogWrite "Failed to Delete Empty Folder - $($_.FullName)"
        }
    }
}
else {
    LogWrite "No empty folders found"
}
#>

# Old script command line for deleting empty folders (no logging)
# Get-ChildItem -Path $path -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null } | Remove-Item -Force -Recurse 