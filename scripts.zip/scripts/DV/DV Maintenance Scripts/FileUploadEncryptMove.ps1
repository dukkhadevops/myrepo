﻿# FileUploadEncryptMove - Runs at 3am everyday
# Encrypt and Move user uploaded files from C:\app\TempUpload to network share (only on WEB Servers)
# Script must log into each WEB server and run locally

# Set up Log file with date
$logpath = "C:\scripts\logs"
if (!(Test-Path $logpath)) {
    New-Item $logpath -ItemType Directory
}
$date = get-date -format MMddyy
$logfile = "$logpath\DV-FileUploadEncryptMove-LOG-$date.txt"
New-Item $logfile -Type "file" -Force

# DV Custom App for Encrypting files (only on WEB Servers)
$DVSec = "C:\app\dvsec\dvsec.exe"

# Network share for Encrypted files
$UploadFilesEnc = "\\appfs\dv\prod\dv_shared_prod\UploadFilesEnc"

# Function to write to log file
Function LogWrite
{
   Param ([string]$message)

   $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
   $Line = "$Stamp - $message"
   Add-content -path $logfile -value $Line
}

# Function to delete files based on number of days and log each delete
Function CleanUp ($Folder, $Days, $Type)
{
    foreach ($File in Get-ChildItem $Folder -Recurse -include $Type)
    {
        if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false)
        {
            Remove-Item $File.FullName -Force
            LogWrite "Deleted - $($File.FullName)"
        }
    }
}

# Encrypt each file in C:\app\TempUpload
if (Test-Path "C:\app\TempUpload") {
    foreach ($File in Get-ChildItem "C:\app\TempUpload" -Recurse)
    {
        try {
            & $DVSec -e $File.FullName
            LogWrite "Encrypted - $($File.FullName)"
        }
        catch {
            LogWrite "Failed to Encrypt - $($File.FullName)"
        }
    }

    # Move encrypted files to \\appfs\dv\prod\dv_shared_prod\UploadFilesEnc
    foreach ($File in Get-ChildItem "C:\app\TempUpload" -Recurse -Include *.enc)
    {
        try {
            Move-Item $File $UploadFilesEnc -Force
            LogWrite "Moved - $($File.FullName)"
        }
        catch {
            LogWrite "Failed to Move - $($File.FullName)"
        }
        
    }

    # Clean up the C:\app\TempUpload folder
    Cleanup 'C:\app\TempUpload' 0 '*.*'
    LogWrite "CleanUp Complete - C:\app\TempUpload"
}
else {
    LogWrite "C:\app\TempUpload does not exist"
}