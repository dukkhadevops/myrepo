# Archive File Share Maintenance � Runs at 5am everyday
# Cleans up specific folders on the Archive File Share

# Rundeck server variable, if needed when running locally
#$server = "@node.hostname@"

# Create session for Rundeck to use Maintenance Account for script to run locally (target node = rundeck01uwap)
$credusername = "world\svcdvRundeckMaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername,$credpasswordss)
$session = New-PSSession -ComputerName "rundeck01uwap" -Authentication Credssp -Credential $credential
Invoke-Command -Session $session -scriptblock {

    # Root File Share
    $DVDFSArchiveWebClusterFiles = "\\appfs\dv\backup\dv_dfsarchive_prod\DFS\WebClusterFiles"

    # Set up Log file with date
    $logpath = "\\appfs\dv\prod\dv_shared_prod\Logs\MaintenanceLogs"
    <# No need to create since it exists on the share
    if (!(Test-Path $logpath)) {
        New-Item $logpath -ItemType Directory
    }#>
    $date = get-date -format MMddyy
    $logfile = "$logpath\DV-ArchiveMaintenance-LOG-$date.txt"
    New-Item $logfile -Type "file" -Force

    # Function to write to log file
    Function LogWrite
    {
       Param ([string]$message)

       $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
       $Line = "$Stamp - $message"
       Add-content -path $logfile -value $Line
    }

    # Function to delete files based on number of days and log each delete
    Function CleanUp ($Folder, $Days, $Type)
    {
        foreach ($File in Get-ChildItem $Folder -Recurse -include $Type)
        {
            if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false)
            {
                try {
                    Remove-Item $File.FullName -Force
                    LogWrite "Deleted - $($File.FullName)"
                }
                catch {
                    LogWrite "Failed to Delete - $($File.FullName)"
                }
            }
        }
    }

    # Function for deleting empty folders
    Function DeleteEmptyFolders ($Path)
    {
        LogWrite "Deleting empty directories found in $Path."
        $EmptyFolders = Get-ChildItem -Path $Path -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null }
        if ($EmptyFolders -ne $null) {
            $EmptyFolders | Foreach {
                LogWrite "Deleted Empty Folder - $($_.FullName)"
                try {
                    Remove-Item $($_.FullName) -Force
                }
                catch {
                    LogWrite "Failed to Delete Empty Folder - $($_.FullName)"
                }
            }
        }
        else {
            LogWrite "No empty folders found in $Path"
        }
        # Old script command line for deleting empty folders (no logging)
        # Get-ChildItem -Path $path -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null } | Remove-Item -Force -Recurse
    }

    LogWrite "Starting CleanUp"

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles\4506SSA\BatchQue"
    Cleanup "$DVDFSArchiveWebClusterFiles\4506SSA\BatchQue" 1 '*.*'

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles\4506SSA\DeleteFax"
    Cleanup "$DVDFSArchiveWebClusterFiles\4506SSA\DeleteFax" 1 '*.*'

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles\drivepdf"
    Cleanup "$DVDFSArchiveWebClusterFiles\drivepdf" 30 '*.enc'

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles\fax\inbound\SSA\INCOMINGFAX"
    Cleanup "$DVDFSArchiveWebClusterFiles\fax\inbound\SSA\INCOMINGFAX" 1 '*.pdf'

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles\temp"
    Cleanup "$DVDFSArchiveWebClusterFiles\temp" 1 '*.*'

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles\watchlistauthrequests"
    Cleanup "$DVDFSArchiveWebClusterFiles\watchlistauthrequests" 1 '*.*'

    LogWrite "Running cleanup in $DVDFSArchiveWebClusterFiles"
    Cleanup $DVDFSArchiveWebClusterFiles 1825 '*.*'

    LogWrite "CleanUp Complete"
}
Remove-PSSession $session
