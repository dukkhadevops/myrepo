﻿# Local File Maintenance – Runs weekly, every Sunday, 5am for ODD servers, 5:30am for EVEN servers
# Cleans up specific folders on the local server
# Script must log into each server and run locally
# Applies to ALL DataVerify servers

$IISStop = "iisreset /stop"
$IISStart = "iisreset /start"
$Restart = "shutdown -r -f -t 5"

# Set up Log file with date
$logpath = "C:\scripts\logs"
if (!(Test-Path $logpath)) {
    New-Item $logpath -ItemType Directory
}
$date = get-date -format MMddyy
$logfile = "$logpath\DV-LocalFileMaintenance-LOG-$date.txt"
New-Item $logfile -Type "file" -Force

# Function to write to log file
Function LogWrite
{
    Param ([string]$message)

    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp - $message"
    Add-content -path $logfile -value $Line
}

# Function to delete files based on number of days and log each delete
Function CleanUp ($Folder, $Days, $Type)
{
    foreach ($File in Get-ChildItem $Folder -Recurse -include $Type)
    {
        if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false)
        {
            try {
                Remove-Item $File.FullName -Force
                LogWrite "Deleted - $($File.FullName)"
            }
            catch {
                LogWrite "Failed to Delete - $($File.FullName)"
            }
        }
    }
}

# Stop IIS
Invoke-Expression -Command $IISStop
Start-Sleep -Seconds 5

# Start the cleanup job write a log after each cleanup with a timestamp
LogWrite "Starting CleanUp" 

# Application Logs (Changed from 5 to 7)
if (Test-Path "C:\app\log") {
    LogWrite "Running cleanup in C:\app\log"
    CleanUp "C:\app\log" 7 '*.*'
}

# XML Requests
if (Test-Path "C:\app\XmlReq") {
    LogWrite "Running cleanup in C:\app\xmlreq"
    CleanUp "C:\app\xmlreq" 7 '*'
}

# Request Logs (Changed from 5 to 7)
if (Test-Path "C:\app\requestlogs") {
    LogWrite "Running cleanup in C:\app\requestlogs"
    CleanUp "C:\app\requestlogs" 7 '*.*'
}

# Maintenance Logs
if (Test-Path "C:\scripts\logs") {
    LogWrite "Running cleanup in C:\scripts\logs"
    CleanUp "C:\scripts\logs" 7 '*.*'
}

# Dynatrace Logs (Changed from 5 to 7)
if (Test-Path "C:\Program Files (x86)\dynaTrace") {
    LogWrite "Running cleanup in C:\Program Files (x86)\dynaTrace"
    CleanUp "C:\Program Files (x86)\dynaTrace" 7 '*.log*'
}

# ASP.NET Temporary Files
if (Test-Path "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files") {
    LogWrite "Running cleanup in C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files"
    CleanUp "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files" 0 '*.*'   
}

# Windows Error Reporting Logs
if (Test-Path "C:\ProgramData\Microsoft\Windows\WER") {
    LogWrite "Running cleanup in C:\ProgramData\Microsoft\Windows\WER"
    CleanUp "C:\ProgramData\Microsoft\Windows\WER" 3 '*.*'
}

# IIS Logs (Changed from 5 to 7)
if (Test-Path "C:\inetpub\logs") {
    LogWrite "Running cleanup in C:\inetpub\logs"
    CleanUp "C:\inetpub\logs" 7 '*.*'
}

LogWrite "CleanUp Complete"

#restart the machine
Invoke-Expression -Command $Restart
