# File Share Maintenance � Runs at 5am everyday
# Cleans up specific folders on the DV_FS and DV_Shared File Shares 

# Rundeck server variable, if needed when running locally
#$server = "@node.hostname@"

# Create session for Rundeck to use Maintenance Account for script to run locally (target node = rundeck01uwap)
$credusername = "world\svc_dvRundeckMaint_p"
$credpassword = "@option.Password@"
$credpasswordss = $credpassword | ConvertTo-SecureString -asPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($credusername,$credpasswordss)
$session = New-PSSession -ComputerName "rundeck01uwap" -Authentication Credssp -Credential $credential
Invoke-Command -Session $session -scriptblock {

    # Root folders for File Shares
    $DVShared = "\\appfs\dv\prod\dv_shared_prod"
    $DVFSWebClusterFiles = "\\appfs\dv\prod\dv_fs_prod\WebClusterFiles"

    # Set up Log file with date
    $logpath = "\\appfs\dv\prod\dv_shared_prod\Logs\MaintenanceLogs"
    <# No need to create since it exists on the share
    if (!(Test-Path $logpath)) {
        New-Item $logpath -ItemType Directory
    }#>
    $date = get-date -format MMddyy
    $logfile = "$logpath\DV-FileShareMaintenance-LOG-$date.txt"
    New-Item $logfile -Type "file" -Force

    # Function to write to log file
    Function LogWrite
    {
       Param ([string]$message)

       $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
       $Line = "$Stamp - $message"
       Add-content -path $logfile -value $Line
    }

    # Function to delete files based on number of days and log each delete
    Function CleanUp ($Folder, $Days, $Type)
    {
        foreach ($File in Get-ChildItem $Folder -Recurse -include $Type)
        {
            if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false)
            {
                try {
                    Remove-Item $File.FullName -Force
                    LogWrite "Deleted - $($File.FullName)"
                }
                catch {
                    LogWrite "Failed to Delete - $($File.FullName)"
                }
            }
        }
    }

    # Function for deleting empty folders
    Function DeleteEmptyFolders ($Path)
    {
        LogWrite "Deleting empty directories found in $Path."
        $EmptyFolders = Get-ChildItem -Path $Path -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null }
        if ($EmptyFolders -ne $null) {
            $EmptyFolders | Foreach {
                LogWrite "Deleted Empty Folder - $($_.FullName)"
                try {
                    Remove-Item $($_.FullName) -Force
                }
                catch {
                    LogWrite "Failed to Delete Empty Folder - $($_.FullName)"
                }
            }
        }
        else {
            LogWrite "No empty folders found in $Path"
        }
        # Old script command line for deleting empty folders (no logging)
        # Get-ChildItem -Path $path -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null } | Remove-Item -Force -Recurse
    }
    
    LogWrite "Starting CleanUp"

    # DV_Shared Paths
    LogWrite "Running cleanup in $DVShared\Logs\TaskLogs"
    CleanUp "$DVShared\Logs\TaskLogs" 30 '*.*'

    LogWrite "Running cleanup in $DVShared\Logs\MaintenanceLogs"
    CleanUp "$DVShared\Logs\MaintenanceLogs" 30 '*.*'

    LogWrite "Running cleanup in $DVShared\Tasks\IRSRobot3_KenViviano\html\trans\backup"
    CleanUp "$DVShared\Tasks\IRSRobot3_KenViviano\html\trans\backup" 10 '*.enc'

    LogWrite "Running cleanup in $DVShared\TaskLoads\UVLBulkMatch\Backup"
    CleanUp "$DVShared\TaskLoads\UVLBulkMatch\Backup" 60 '*.enc'

    LogWrite "Running cleanup in $DVShared\TaskLoads\NMLS"
    CleanUp "$DVShared\TaskLoads\NMLS" 30 '*.*'

    LogWrite "Running cleanup in $DVShared\UploadFilesEnc"
    CleanUp "$DVShared\UploadFilesEnc" 365 '*.enc'

    LogWrite "Running cleanup in $DVShared\xmlreqs"
    CleanUp "$DVShared\xmlreqs" 30 '*'
    DeleteEmptyFolders "$DVShared\xmlreqs"

    # DV_FS Paths
    LogWrite "Running cleanup in $DVFSWebClusterFiles\4506SSA\Batchque"
    CleanUp "$DVFSWebClusterFiles\4506SSA\Batchque" 90 '*.*'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\4506SSA\DeleteFax"
    CleanUp "$DVFSWebClusterFiles\4506SSA\DeleteFax" 90 '*.*'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\creports"
    CleanUp "$DVFSWebClusterFiles\creports" 30 '*.oxo'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\drivepdf"
    CleanUp "$DVFSWebClusterFiles\drivepdf" 30 '*.enc'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\fax\inbound\SSA\IncomingFax"
    CleanUp "$DVFSWebClusterFiles\fax\inbound\SSA\IncomingFax" 14 '*.pdf'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\Fax\outbound\backup"
    CleanUp "$DVFSWebClusterFiles\Fax\outbound\backup" 14 '*.*'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\temp"
    CleanUp "$DVFSWebClusterFiles\temp" 7 '*.*'

    LogWrite "Running cleanup in $DVFSWebClusterFiles\watchlistauthrequests"
    CleanUp "$DVFSWebClusterFiles\watchlistauthrequests" 7 '*.*'

    LogWrite "CleanUp Complete"
}
Remove-PSSession $session
