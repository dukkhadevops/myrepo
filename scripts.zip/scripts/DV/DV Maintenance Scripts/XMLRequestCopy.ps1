﻿# XMLRequestCopy – Runs at 4am everyday
# Copies XML Requests from C:\app\requestlogs and C:\app\XmlReq to a network share (APP/GW/WEB Servers)
# The network share is organized with folders by server names and dates
# Script must log into each APP/GW/WEB server and run locally

# Set up Log file with date
$logpath = "C:\scripts\logs"
if (!(Test-Path $logpath)) {
    New-Item $logpath -ItemType Directory
}
$date = get-date -format MMddyy
$logfile = "$logpath\DV-XMLRequestCopy-LOG-$date.txt"
New-Item $logfile -Type "file" -Force

# Network share for XML Requests
$xmlReqShare = "\\appfs\dv\prod\dv_shared_prod\xmlreqs"

# Local server running the script (Used to define the folder on the share, noting where the files are moved from)
$server = $env:COMPUTERNAME

# Function to write to log file
Function LogWrite
{
   Param ([string]$message)

   $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
   $Line = "$Stamp - $message"
   Add-content -path $logfile -value $Line
}

# Copy each file from C:\app\XmlReq to network share using server name and date
if (Test-Path "C:\app\XmlReq") {
    LogWrite "Starting Copy for C:\app\XmlReq"
    Foreach ($File in Get-ChildItem "C:\app\XmlReq")
    {
	    If ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
	    {
		    $filedate = $File.lastwritetime.tostring("MM-dd-yyyy")
            If ((Test-Path "$xmlReqShare\$Server\xmlreq\$filedate") -eq $False)
		    {
                try {
			        New-Item -ItemType Directory "$xmlReqShare\$Server\xmlreq\$filedate"
                    LogWrite "Created Folder - $xmlReqShare\$Server\xmlreq\$filedate"
                }
                catch {
                    LogWrite "Failed to Create Folder - $xmlReqShare\$Server\xmlreq\$filedate"
                }
		    }
            try {
                if (!(Test-Path "$xmlReqShare\$Server\xmlreq\$filedate\$($File.Name)")) {
		            Copy-Item $File.FullName "$xmlReqShare\$Server\xmlreq\$filedate" -Force
                    LogWrite "Copied - $File - TO - $xmlReqShare\$Server\xmlreq\$filedate"
                }
            }
            catch {
                LogWrite "Failed to Copy - $File - TO - $xmlReqShare\$Server\xmlreq\$filedate"
            }
	    }
    }
    LogWrite "Completed Copy for C:\app\XmlReq"
}
else {
    LogWrite "C:\app\XmlReq does not exist"
}

# Copy each file from C:\app\requestlogs to network share using server name and date
if (Test-Path "C:\app\requestlogs") {
    LogWrite "Starting Copy for C:\app\requestlogs"
    Foreach ($File in Get-ChildItem "C:\app\requestlogs")
    {   
	    If ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
	    {
		    $filedate = $File.lastwritetime.tostring("MM-dd-yyyy")
            If ((Test-Path "$xmlReqShare\$Server\requestlogs\$filedate") -eq $False)
		    {
                try{                
			        New-Item -ItemType Directory "$xmlReqShare\$Server\requestlogs\$filedate"
                    LogWrite "Created Folder - $xmlReqShare\$Server\requestlogs\$filedate"
                }
                catch {
                    LogWrite "Failed to Create Folder - $xmlReqShare\$Server\requestlogs\$filedate"
                }
		    }
            try {
                if (!(Test-Path "$xmlReqShare\$Server\requestlogs\$filedate\$($File.Name)")) {
		            Copy-Item $File.FullName "$xmlReqShare\$Server\requestlogs\$filedate" -Force
                    LogWrite "Copied - $File - TO - $xmlReqShare\$Server\requestlogs\$filedate"
                }
            }
            catch {
                LogWrite "Failed to Copy - $File - TO - $xmlReqShare\$Server\requestlogs\$filedate"
            }
	    }
    }
    LogWrite "Completed Copy for C:\app\requestlogs"
}
else {
    LogWrite "C:\app\requestlogs does not exist"
}