﻿########
# Author:               Matt Keller
# Description:          Module to install Dynatrace .Net Agent on Dataverify servers
#                       10/19/2018    script created and turned into module based on older Dynatrace installer scripts
#                       10/22/2018    add handling for if Dynatrace already exists, dont install etc
#                       07/23/2019    Updated Path to Dynatrace INI
#                       08/16/2019    Set default value for file share location
#                       08/16/2019    Added switch to enable Dynatrace IIS modules
#
########

#some assumptions for this module/function, since it is originally designed for DV environment and in conjunction with DV Powershell DSC configuration/builds of server.
#1)we'll be running the installer from c:\scripts on the target server so this script will create it and use it if it doesn't exist already
#2)the account you're running this under has access to the machine and permissions to install applications
#3)the $dynatraceinstallparams should be inspected and compared with Dynatrace install documentation to insure you're installing the agents you want.
## in this case these are .NET and IIS agents
#4)there is an accompanying .ini file that $dynatraceinifile can use. it should be named like other files in this directory and formatted similarly

#idea - OPTIONAL PARAMS make the function take in a NAME & SERVER:PORT so you can dynamically create the ini files on the fly if you want otherwise look at the destination in source control
#
# Add switch to choose to add IIS Module (If you enable all modules matching Dynatrace*, older versions will be enabled if they exist.)
# Get-WebGlobalModule | Where {$_.name -like "Dynatrace*"} | Enable-WebGlobalModule
# Enable-WebGlobalModule -Name "Dynatrace IIS Webserver Agent 7.0"
# Enable-WebGlobalModule -Name "Dynatrace IIS Webserver Agent 7.0 (x64)"
# You can also enable the module for a specific site:
# Enable-WebGlobalModule -Name "Dynatrace IIS Webserver Agent 7.0" -PSPath "IIS:\sites\Default Web Site"
#
#
# If Dynatrace 6.3 is installed and needs to be removed:
# Check for path "\\$computername\C$\Program Files (x86)\Dynatrace\Dynatrace Agent 6.3\"
# Or check for program Get-WmiObject -Class Win32_Product -ComputerName $computername -Filter "Name = 'Dynatrace Agent 6.3'"
# Use WMI within Invoke-Command:
# $DT63app=Get-WmiObject -Class Win32_Product -Filter "Name = 'Dynatrace Agent 6.3'"
# $DT63app.Uninstall()

########
#example usage of the function
########
#Newer version: "\\fs\pub\collab\dynatrace\AppMon 7.2\windows\dynatrace-agent-7.2.0.1697-x86.msi"
#$dyna = "\\fs\pub\collab\dynatrace\Dynatrace 7\Windows\Agent\dynatrace-agent-7.0.0.2469-x86.msi"
#$dynatraceIISmodule = $false
#$target = "dvweb01uwwl"
#
#$InstallDynatrace_modulepath = "C:\GIT\Scripts\DV\InstallDynatrace\InstallDynatrace.psm1"
#Import-Module -Name $InstallDynatrace_modulepath -Verbose
#InstallDynatrace $target $dynatraceIISmodule $dyna
########

function InstallDynatrace{ 
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$false,Position=2)]
            $dynatraceIISmodule = $false,

        [Parameter(Mandatory=$false,Position=3)]
            [string]$dynatracefileshare = "\\fs\pub\collab\dynatrace\Dynatrace 7\Windows\Agent\dynatrace-agent-7.0.0.2469-x86.msi"
        )

    #region Parse Server Name into variables
    # Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
    $targetarray = $computername -Split '(\d\d)'
    # Read the first string, which is the Root Name for the server
    $RootName = $targetarray[0]
    # Read the second string, which is the double digit number in the server name
    $Number = $targetarray[1]
    # Read the third string, which includes Location/Support Team/Type/Environment
    $Details = $targetarray[2]
    $ServerLocation = $($Details[0])
    # Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
    $Prefix = $RootName[0,1] -join ''
    $Prefix = $($Prefix.ToLower())
    # Read the Root Name, starting after the second character (web from dvweb)
    $ServerType = $RootName.Substring(2)
    $ServerType = $($ServerType.ToLower())
    # Read last character for Environment
    $Environment = $Details.Substring($Details.Length-1)
    # Update Environment variable
    switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
    #endregion

    #test if can connect to machine
    If (Test-WSMan -ComputerName $computername -Verbose)
    {
        $destpath = "\\" + $computername + "\C$\scripts"
        $localpath = "C:\scripts"
        $dynatracefile = Split-Path $dynatracefileshare -Leaf
        $dynatracedest = $localpath + "\" + $dynatracefile
        $dynatraceinstallparams = "/i $dynatracedest ADDLOCAL=DiagnosticsAgent,IIS7Agent,IISAgents,DotNetAgent,WebServerAgent,DotNetAgent20x64,IIS7Agentx64 /qn"
        #dynatrace ini install
        #$dynatraceinifile = "C:\Git\Scripts\DV\InstallDynatrace\inifiles\$computername"
        $dynatraceinidest = "\\" + $computername + "\C$\Program Files (x86)\Dynatrace\Dynatrace Agent 7.0\agent\conf"
        #dynatrace install dir
        $dynatraceremotepath = "\\" + $computername + "\C$\Program Files (x86)\Dynatrace\Dynatrace Agent 7.0\dtagentconf.exe"
        #dynatrace service name (in case it changes in the future)
        $servicename = "Dynatrace Web Server Agent 7.0"
        #$blah = (Get-Service -ComputerName $computername -Name $serviceName)
        #$blah.Status

        #region check if c:\scripts exists on host, if not, create it.
        #invoke command on $computername passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        If(!(test-path $destpath)) {
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
        }             
        #endregion

        #region dynatrace install. Copy files, check and see if $dynatraceremotepath exists already. if it doesn't, run installer with params we want
        #copy file from $dynatracefileshare to destpath we know exists
        Copy-Item -Path $dynatracefileshare -Destination $destpath -ErrorAction Stop
        
        #if path exists, skip install
        If (Test-Path -Path $dynatraceremotepath) {
            return "$dynatraceremotepath exists already. Make sure Dynatrace isn't installed already"
        }

        #else the path doesn't exist, so install Dynatrace.
        Else {
            echo "$dynatraceremotepath not found. Installing Dynatrace on $computername"
            #invoke command start-process msiexec with our $dynatraceinstallparams
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) Start-Process -Filepath msiexec $p1 -Wait } -ArgumentList "$dynatraceinstallparams" -ErrorAction Stop
            #option to enable Dyntrace IIS modules
            If ($dynatraceIISmodule -eq $true){
                echo "Adding Dyntrace IIS Modules"
                Invoke-Command -Computername $computername -ScriptBlock {
                    Enable-WebGlobalModule -Name "Dynatrace IIS Webserver Agent 7.0"
                    Enable-WebGlobalModule -Name "Dynatrace IIS Webserver Agent 7.0 (x64)"
                } -ErrorAction Stop
            }
        }
        #endregion

        #region .ini copy, rename and restart service
        # Check for Dynatrace IIS module install flag
        # If the Server Type is not WEB, this section will fail
        If ($dynatraceIISmodule -eq $true){
            # ODD Servers
            if($Number % 2 -eq 1) {
                if ($ServerType -eq "web") {
                    $dynatracelocalinifile = $ServerType + "_" + $ServerLocation + "_" + $Environment + "_odd_dtwsagent.ini"
                }
            }
            # EVEN Servers
            if($Number % 2 -eq 0) {
                if ($ServerType -eq "web") {
                    $dynatracelocalinifile = $ServerType + "_" + $ServerLocation + "_" + $Environment + "_even_dtwsagent.ini"
                }
            }
            $dynatraceinifile = "C:\Git\Scripts\DV\InstallDynatrace\inifiles\$dynatracelocalinifile"
            # copy staged ini file
            Copy-Item -Path $dynatraceinifile -Destination $dynatraceinidest -ErrorAction Stop
            # set condition variables for ini files
            $check1 = "$dynatraceinidest" + "\dtwsagent.ini"
            $check2 = "$dynatraceinidest" + "\dtwsagent.ini.default"
            $check3 = "$dynatraceinidest" + "\$dynatracelocalinifile"
            # Check if the default ini file exists before proceeding
            If (Test-Path $check1) {
                # Check if the ini.default copy exists, delete it if it exists
                If (Test-Path $check2) {
                    Remove-Item $check2
                }
                # Rename the default ini file to dtwsagent.ini.default
                Rename-Item -path $check1 -NewName "dtwsagent.ini.default" -Force
                # Rename the pre-configured ini file to dtwsagent.ini
                Rename-Item -path $check3 -NewName "dtwsagent.ini" -Force
            }
            # If ini file doesnt exist, check installer
            Else {
                echo "$check1 doesnt exist. Either it wasn't created prior to install or this script can't access the path $dynatraceinidest."
            }
            # now that the new .ini is in place, restart dynatrace service
            echo "trying to restart Dynatrace service on $computername"
            #if the service exists
            If(Get-Service -ComputerName $computername -Name $servicename -ErrorAction SilentlyContinue) {
                echo "service name found"
                #if the service is already running
                If ((Get-Service -ComputerName $computername -Name $serviceName).Status -eq 'Running') {
                    #stop the service
                    echo "Service already running. Stopping service..."
                    (Get-Service -ComputerName $computername -Name $servicename).Stop()
                    #sleep so we can restart it
                    Start-Sleep -s 10
                    #start it
                    echo "starting service"
                    (Get-Service -ComputerName $computername -Name $servicename).Start()
                }
                Else {
                    echo "service isn't running so no need to recycle. Starting Dynatrace"
                    (Get-Service -ComputerName $computername -Name $servicename).Start()
                }

            }
            #else the service must not exist
            Else {
                echo "$servicename not found. Check $computername and make sure install suceeded"
            }
        }
        #endregion
    }
    Else{
        echo "cannot connect to $computername"
    }
    echo "exiting Dynatrace install"
}