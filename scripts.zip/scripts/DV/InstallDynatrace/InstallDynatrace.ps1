﻿########
# Author:               Matt Keller
# Description:          Module to install Dynatrace .Net Agent on Dataverify servers
#                       10/19/2018    script created and turned into module based on older Dynatrace installer scripts
#                       10/22/2018    add handling for if the service already exists, dont install etc
#
########

#some assumptions for this module/function, since it is originally designed for DV environment and in conjunction with DV Powershell DSC configuration/builds of server.
#1)we'll be running the installer from c:\scripts on the target server so this script will create it and use it if it doesn't exist already
#2)the account you're running this under has access to the machine and permissions to install applications
#3)the $dynatraceinstallparams should be inspected and compared with Dynatrace install documentation to insure you're installing the agents you want.
## in this case these are .NET and IIS agents
#4)there is an accompanying .ini file that $dynatraceinifile can use. it should be named like other files in this directory and formatted similarly

#idea - OPTIONAL PARAMS make the function take in a NAME & SERVER:PORT so you can dynamically create the ini files on the fly if you want otherwise look at the destination in source control

########
#example usage of the function
########
$dyna = "\\fs\pub\collab\dynatrace\Dynatrace 7\WIndows\Agent\dynatrace-agent-7.0.0.2469-x86.msi"
$target = "dvweb01uwwl"
#
InstallDynatrace $target $dyna
########

function InstallDynatrace{ 
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$True,Position=2)]
            [string]$dynatracefileshare
        )

    #test if can connect to machine
    If (Test-WSMan -ComputerName $computername -Verbose)
    {
        $destpath = "\\" + $computername + "\C$\scripts"
        $localpath = "C:\scripts"
        $dynatracefile = Split-Path $dynatracefileshare -Leaf
        $dynatracedest = $localpath + "\" + $dynatracefile
        $dynatraceinstallparams = "/i $dynatracedest ADDLOCAL=DiagnosticsAgent,IIS7Agent,IISAgents,DotNetAgent,WebServerAgent,DotNetAgent20x64,IIS7Agentx64 /qn"
        #dynatrace ini install
        $dynatraceinifile = "C:\SVN\WindowsAdmins\Scripts\DV\InstallDynatrace\inifiles\$computername"
        $dynatraceinidest = "\\" + $computername + "\C$\Program Files (x86)\Dynatrace\Dynatrace Agent 7.0\agent\conf"
        #dynatrace install dir
        $dynatraceremotepath = "\\" + $computername + "\C$\Program Files (x86)\Dynatrace\Dynatrace Agent 7.0"
        #dynatrace service name (in case it changes in the future)
        $servicename = "Dynatrace Web Server Agent 7.0"
        #$blah = (Get-Service -ComputerName $target -Name $serviceName)
        #$blah.Status



        #region check if c:\scripts exists on host, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath

        If(!(test-path $destpath))
        {
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
        }
             
        #endregion

        #region dynatrace install. Copy files, check and see if $dynatraceremotepath exists already. if it doesn't, run installer with params we want
        #copy file from $dynatracefileshare to destpath we know exists
        Copy-Item -Path $dynatracefileshare -Destination $destpath -ErrorAction Stop

        #if path exists, skip install
        If (Test-Path -Path $dynatraceremotepath) {
            return "$dynatraceremotepath exists already. Make sure Dynatrace isn't installed already"
        }

        #else the path doesn't exist, so install Dynatrace.
        Else {
            echo "$dynatraceremotepath not found. Installing Dynatrace on $target"
            #invoke command start-process msiexec with our $dynatraceinstallparams
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) Start-Process -Filepath msiexec $p1 -Wait } -ArgumentList "$dynatraceinstallparams" -ErrorAction Stop
        }

        #endregion

        #region .ini copy and rename tasks
        Copy-Item -Path $dynatraceinifile -Destination $dynatraceinidest -ErrorAction Stop

        $check1 = "$dynatraceinidest" + "\dtwsagent.ini"
        $check2 = "$dynatraceinidest" + "\dtwsagent.ini.default"
        $check3 = "$dynatraceinidest" + "\$computername"

        #if ini file exists...
        If (Test-Path $check1) {
                
            #if ini.default exists, delete it
            If (Test-Path $check2) {
                Remove-Item $check2
            }

            #if ini file exists, rename to .ini.default
            Rename-Item -path $check1 -NewName "dtwsagent.ini.default" -Force
            #rename .ini.matt to .ini
            Rename-Item -path $check3 -NewName "dtwsagent.ini" -Force
        }
        
        #else if ini file doesnt exist, check installer
        Else {
            echo "$check1 doesnt exist. Either it wasn't created prior to install or this script can't access the path $dynatraceinidest."
        }

        #endregion

        #region now that the new .ini is in place, restart dynatrace service
        echo "trying to restart Dynatrace service on $target"

        #if the service exists
        If(Get-Service -ComputerName $target -Name $servicename -ErrorAction SilentlyContinue) {
            echo "service name found"
            #if the service is already running
            If ((Get-Service -ComputerName $target -Name $serviceName).Status -eq 'Running') {
                    #stop the service
                    echo "Service already running. Stopping service..."
                    (Get-Service -ComputerName $target -Name $servicename).Stop()
                    #sleep so we can restart it
                    Start-Sleep -s 10
                    #start it
                    echo "starting service"
                    (Get-Service -ComputerName $target -Name $servicename).Start()
            }
            Else {
                echo "service isn't running so no need to recycle. Starting Dynatrace"
                (Get-Service -ComputerName $target -Name $servicename).Start()
            }

        }
        #else the service must not exist
        Else {
        echo "$servicename not found. Check $target and make sure install suceeded"
        }

        #endregion

        #region configure native modules

        #endregion
    }
    Else{echo "cannot connect to $computername"}
echo "exiting Dynatrace install"
}