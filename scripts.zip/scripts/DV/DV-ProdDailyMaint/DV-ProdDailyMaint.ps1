﻿$IISStop = 'iisreset /stop'
$IISStart = 'iisreset /start'
$Restart = 'shutdown -r -f -t 0'
$logpath = 'c:\scripts'
$logfile = 'c:\scripts\DV-ProdDailyMaint-LOG.txt'

#see if the old log file is there, if it is, remove it
if (Test-Path $logfile){
    Remove-Item $logfile
} Else {

    New-Item -path $logpath -name DV-ProdDailyMaint-LOG.txt -type "file"
}


Function CleanUp ($Folder, $Days, $Type)
{
	foreach ($File in Get-ChildItem $Folder -Recurse -include $Type)
	{
	    if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false)
	    {
	        Remove-Item $File.FullName -force
	    }
	}
}

Function LogWrite
{
   Param ([string]$message)

   $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
   $Line = "$Stamp $message"
   Add-content -path $logfile -value $Line
}

#stop IIS
Invoke-Expression -Command $IISStop

#run the cleanup job as normal then write a log after each cleanup with a timestamp
LogWrite 'Log Begin' 
CleanUp 'C:\app\log' 5
LogWrite 'C:\app\log cleanup DONE'

CleanUp 'C:\Program Files (x86)\dynaTrace' 5 '*.log*'
LogWrite 'C:\Program Files (x86)\dynaTrace cleanup DONE'

CleanUp 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files' 0 '*.*'
LogWrite 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files cleanup DONE'

CleanUp 'C:\ProgramData\Microsoft\Windows\WER' 3 '*.*'
LogWrite 'C:\ProgramData\Microsoft\Windows\WER cleanup DONE'

CleanUp 'C:\app\requestlogs' 5 '*.*'
LogWrite 'C:\app\requestlogs cleanup DONE'

CleanUp 'C:\app\xmlreq' 7
LogWrite 'C:\app\xmlreq cleanup DONE'

CleanUp 'C:\inetpub\logs\LogFiles' 5 '*.*'
LogWrite 'C:\inetpub\logs\LogFiles cleanup DONE'

CleanUp 'C:\Users\dvservice\AppData\Local\Microsoft\Windows\Temporary Internet Files\Content.IE5' 0 '*.*'
LogWrite 'C:\Users\dvservice\AppData\Local\Microsoft\Windows\Temporary Internet Files\Content.IE5 cleanup DONE'

#restart the machine
Invoke-Expression -Command $Restart