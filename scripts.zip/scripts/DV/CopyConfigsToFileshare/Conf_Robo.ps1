#AppServers
robocopy "\\cbcdv-app01p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-app01p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-app02p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-app02p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-app03p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-app03p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-app04p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-app04p\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-app01\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-app01\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-app02\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-app02\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-app03\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-app03\conf" /e /sec /R:2 /W:2

#GWServers
robocopy "\\cbcdv-GW01p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-GW01p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-GW02p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-GW02p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-GW03p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-GW03p\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-GW01\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-GW01\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-GW02\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-GW02\conf" /e /sec /R:2 /W:2

#InetServers
robocopy "\\cbcdv-inet01p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-inet01p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-inet02p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-inet02p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-inet03p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-inet03p\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-inet01\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-inet01\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-inet02\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-inet02\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-inet03\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-inet03\conf" /e /sec /R:2 /W:2

#PDFServers
robocopy "\\cbcdv-pdfgen01p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-pdfgen01p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-pdfgen02p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-pdfgen02p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-pdfgen03p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-pdfgen03p\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-pdfgen01\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-pdfgen01\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-pdfgen02\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-pdfgen02\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-pdfgen03\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-pdfgen03\conf" /e /sec /R:2 /W:2

#WebServers
robocopy "\\cbcdv-web01p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web01p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web02p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web02p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web03p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web03p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web04p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web04p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web05p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web05p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web06p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web06p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web07p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web07p\conf" /e /sec /R:2 /W:2
robocopy "\\cbcdv-web08p\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\cbcdv-web08p\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web01\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web01\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web02\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web02\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web03\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web03\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web04\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web04\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web05\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web05\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web06\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web06\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web07\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web07\conf" /e /sec /R:2 /W:2
robocopy "\\dvdr-web08\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvdr-web08\conf" /e /sec /R:2 /W:2

#API
robocopy "\\dvinapi01uwap\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi01uwap\conf" /e /sec /R:2 /W:2
robocopy "\\dvinapi02uwap\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi02uwap\conf" /e /sec /R:2 /W:2
robocopy "\\dvinapi03uwap\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi03uwap\conf" /e /sec /R:2 /W:2
robocopy "\\dvinapi01mwap\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi01mwap\conf" /e /sec /R:2 /W:2
robocopy "\\dvinapi02mwap\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi02mwap\conf" /e /sec /R:2 /W:2
robocopy "\\dvinapi03mwap\c$\app\conf" "\\dfs\nas\DV_Shared\AppConfig\Servers\dvinapi03mwap\conf" /e /sec /R:2 /W:2

