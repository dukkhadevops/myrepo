﻿# NetGender Silent/Remote Install

$target = "dvweb02uwwl"

$NetGenderInstallPath = "\\dfs\NAS\DV_Shared\WebApp Deploy\NetGender\Netgender35\NetGender35.msi"

$LocalPath = "\\dvweb02uwwl\C$\scripts"

Copy-Item -Path $NetGenderInstallPath -Destination $LocalPath -ErrorAction Stop

Invoke-Command -ComputerName $target -ScriptBlock {Start-Process -Filepath msiexec "/i C:\scripts\NetGender35.msi /qn" -Wait} -ErrorAction Stop
