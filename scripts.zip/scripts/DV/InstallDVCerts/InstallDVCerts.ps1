﻿########
# Author:       John Basso
# Description:  Script to install certificates on Dataverify servers
# Changes:      11/18/2019      Initial creation
#
########

# Read list of computers for deployment
$computers = Get-Content -Path "C:\Git\Scripts\DV\InstallDVCerts\computers.txt"

#Certificate Install Modules
$DataverifyCOMCertInstall_modulepath = "C:\GIT\Scripts\DV\DataverifyCOMCertInstall\DataverifyCOMCertInstall.psm1"
$TALXCertInstall_modulepath = "C:\GIT\Scripts\DV\TALXCertInstall\TALXCertInstall.psm1"
$TUNACertInstall_modulepath = "C:\GIT\Scripts\DV\TUNACertInstall\TUNACertInstall.psm1"
$ThawteCertInstall_modulepath = "C:\GIT\Scripts\DV\ThawteCertInstall\ThawteCertInstall.psm1"

$overwrite = $false # Overwrite is false by default for TALX and TUNA

Foreach ($target in $computers) {
    
    #region Parse Server Name into variables
    # Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
    $targetarray = $target -Split '(\d\d)'
    # Read the first string, which is the Root Name for the server
    $RootName = $targetarray[0]
    # Read the second string, which is the double digit number in the server name
    $Number = $targetarray[1]
    # Read the third string, which includes Location/Support Team/Type/Environment
    $Details = $targetarray[2]
    $ServerLocation = $($Details[0])
    # Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
    $Prefix = $RootName[0,1] -join ''
    $Prefix = $($Prefix.ToLower())
    # Read the Root Name, starting after the second character (web from dvweb)
    $ServerType = $RootName.Substring(2)
    $ServerType = $($ServerType.ToLower())
    # Read last character for Environment
    $Environment = $Details.Substring($Details.Length-1)
    # Update Environment variable
    switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
    #endregion

    $SVCaccount = "svc_" + $Prefix + $ServerType + "_" + $($Environment[0])

    #region Set up Server Type Flags
    switch ($ServerType){
        "app"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "bp"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }
        "batch"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }
        "fnma"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }
        "gw"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "inapi"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $true
            $FlagCertTUNA = $false
            $FlagCertThawte = $true
        }
        "inet"{
            $FlagCertDataverifyCOM = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "intgw"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }        
        <#"mrtk"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }#>
        "pdf"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "score"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }
        "svc"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $false
        }
        "task"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $false
            $FlagCertTUNA = $true
        }
        "taskapi"{
            $FlagCertDataverifyCOM = $true
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
        "web"{
            $FlagCertDataverifyCOM = $false
            $FlagCertTALX = $true
            $FlagCertTUNA = $true
        }
    }
    #endregion

    #region install certificates
    if ($FlagCertDataverifyCOM -eq $true) {
        Import-Module -Name $DataverifyCOMCertInstall_modulepath -Verbose
        DataverifyCOMCertInstall $target $SVCaccount
    }
    if ($FlagCertTALX -eq $true) {
        if ($Environment -eq "prod") {
            $TALX_Env = "prod"
        }
        Else {
            $TALX_Env = "test"
        }
        Import-Module -Name $TALXCertInstall_modulepath -Verbose
        TALXCertInstall $target $SVCaccount $TALX_Env $overwrite
    }
    if ($FlagCertTUNA -eq $true) {
        Import-Module -Name $TUNACertInstall_modulepath -Verbose
        TUNACertInstall $target $SVCaccount $overwrite
    }
    if ($FlagCertThawte -eq $true) {
        Import-Module -Name $ThawteCertInstall_modulepath -Verbose
        ThawteCertInstall $target
    }
    #endregion
}