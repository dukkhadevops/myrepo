###########################################################
#         Date: 12/09/14                                  #
#      Helpbox: 187453                                    #
# Steps Needed: Copy files							      #
#      Purpose: Move Files                                #
###########################################################

########################################################### 
#   Needed: Change $Files for files needing moved         #
#	Needed:	Change path to copy to						  #
###########################################################

$Files = Get-Content C:\Scripts\LIVE\DataVerify\PROD\Marchesig2015.txt
 
Foreach ($File in $Files)
{
     Copy-Item $File \\dataverify-01fp\dfs\sharedfiles\4506files\Marchesig2015 -Force
     #Write-Host $File
}
