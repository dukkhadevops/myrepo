﻿##################################################################################################################################
#
#     Name: MoveFiles.ps1
#   Author: Trevor Brown
#     Date: 04 December 2014
#  Helpbox: 187252
#  Purpose: Move Files from one location to another
#
##################################################################################################################################

Param (
[string]$strPathSource = "C:\Users\trevor.brown\Documents\Scripts\Move Files\",
[string]$strPathDestBegin = "\\dataverify-01fp\dfs\sharedfiles\4506files\20141203\",
[string]$strFileSource = $strPathSource + "HB187252fileLocations.txt",
[string]$strLogFile = $strPathSource + "MoveResults.Log"
)

if (Test-Path $strLogFile)
   {
   Remove-Item $strLogFile -Force -Confirm:$false
   }

foreach ($File in Get-Content $strFileSource)
   {
   if (Test-Path $File)
      {
	  $strFileDest = $strPathDestBegin + $File.substring(43)
	  $strPathDest = Split-Path $strFileDest -Parent
	  if (!(Test-Path $strPathDest))
	     {
		 New-Item -ItemType Directory -Path $strPathDest
		 }
      Move-Item $File $strFileDest -Force -Confirm:$false
	  "Moved: " + $File | Out-File $strLogFile -Append
      }
   else
      {
	  "" | Out-File $strLogFile -Append
	  "##############################" | Out-File $strLogFile -Append
	  "# Below File does not exist: #" | Out-File $strLogFile -Append
	  "##############################" | Out-File $strLogFile -Append
	  $File | Out-File $strLogFile -Append
	  "" | Out-File $strLogFile -Append
	  }
   }