﻿#Daily Maintenance Job for CBCDV-FS01P, The File Server for DataVerify in the Columbus DataCenter

function Write-Log([string]$info){$info >> $logfile}
function CleanUp ($Folder, $Days, $Log, $Type)
{
	<#---------Logfile Info----------#>            
	$script:logfile = "$BaseLog\$Log$(get-date -format MMddyy).log"                
	
	foreach ($File in Get-ChildItem $Folder -Recurse -include $Type)
	{
	    if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-$Days)) -and $File.PSIsContainer -eq $false)
	    {
	        Remove-Item $File.FullName -force
			Write-Log "Deleted: $File"
	    }
	}
}

#<------------------------------------Start Script----------------------------------->

$WebServers = Get-Content 'C:\scripts\webservers.txt'
$AppServers = Get-Content 'C:\scripts\appservers.txt'
$xmlReqServers = Get-Content 'C:\scripts\xmlreqservers.txt'
$PDFServers = Get-Content 'C:\scripts\pdfgenservers.txt'
$BaseLog = 'C:\scripts\logs'
$7Zip = "C:\Program Files\7-Zip\7z.exe"
$DVSec = "C:\dvsec\dvsec.exe"
$Robo = "C:\Windows\System32\Robocopy.exe"

#***********************************************
#   Moving user uploaded files to DV-FS01      *
#***********************************************
Write-Host 'Moving user uploaded files'
$UploadFilesEnc = '\\dvfs-prod\UploadFilesEnc'

Foreach ($Server in $WebServers)
{
	foreach ($File in Get-ChildItem "\\$Server\TempUpload" -Recurse)
	{
		#& $DVSec -e $File.FullName
	}
	foreach ($File in Get-ChildItem "\\$Server\TempUpload" -Recurse -Include *.enc)
	{
		#Move-Item $File $UploadFilesEnc -Force
	}
	#Cleanup "\\$Server\TempUpload" 0 "$Server-Uploads" "*.*"
}


#************************
#     Moving WebLogs    *
#************************
Write-Host 'Moving Weblogs'
$WebLogShare = '\\dfs\nas\DV_Shared\Logs\WebLogs'

Foreach ($Server in $WebServers) #For the Web Servers
{
	Foreach ($File in Get-ChildItem "\\$Server\WebLogs")
	{
		if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
		{
			& $7Zip a -tzip "$WebLogShare\$Server\$File.zip" $File.FullName -mx7
		}
	}
	Cleanup "\\$Server\Weblogs" 5 "$Server-Weblog" "*.*"
}

Foreach ($Server in $AppServers) #For the App Servers
{
	Foreach ($File in Get-ChildItem "\\$Server\WebLogs")
	{
		if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
		{
			& $7Zip a -tzip "$WebLogShare\$Server\$File.zip" $File.FullName -mx7
		}
	}
	Cleanup "\\$Server\Weblogs" 5 "$Server-Weblog" "*.*"
}

#************************
#     Moving AppLogs    *
#************************
Write-Host 'Moving Applogs'
$ApplogsShare = '\\dfs\nas\DV_Shared\Logs\AppLogs'

Foreach ($Server in $WebServers) #For the Web Servers
{
	Foreach ($File in Get-ChildItem "\\$Server\AppLogs")
	{
		if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
		{
			& $7Zip a -tzip "$ApplogsShare\$Server\$File.zip" $File.FullName -mx7
		}
	}
	Cleanup "\\$Server\Applogs" 5 "$Server-Applog" "*.*"
}

Foreach ($Server in $AppServers) #For the App Servers
{
	Foreach ($File in Get-ChildItem "\\$Server\AppLogs")
	{
		if ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
		{
			& $7Zip a -tzip "$ApplogsShare\$Server\$File.zip"  $File.FullName -mx7
		}
	}
	Cleanup "\\$Server\Applogs" 5 "$Server-Applog" "*.*"
}


#******************************************************
#     Offloading Xml Requests from the App Servers    *
#******************************************************
Write-Host 'Moving xmlreq'
$xmlReqShare = '\\dfs\nas\DV_Shared\xmlreqs'

Foreach ($Server in $xmlReqServers)
{
	Foreach ($File in Get-ChildItem "\\$Server\XmlReq")
	{
		If ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
		{
			$filedate = $File.lastwritetime.tostring("M-d-yyyy")
            If ((Test-Path "$xmlReqShare\$Server\xmlreq\$Filedate") -eq $False)
			{
				New-Item -ItemType Directory "$xmlReqShare\$Server\xmlreq\$filedate"
			}
			Copy-Item $File.FullName "$xmlReqShare\$Server\xmlreq\$filedate" -Force
		}
	}
    Foreach ($File in Get-ChildItem "\\$Server\requestlogs")
	{
		If ($File.LastWriteTime -lt ($(Get-Date).AddDays(-1)))
		{
			$filedate = $File.lastwritetime.tostring("M-d-yyyy")
            If ((Test-Path "$xmlReqShare\$Server\requestlogs\$Filedate") -eq $False)
			{
				New-Item -ItemType Directory "$xmlReqShare\$Server\requestlogs\$filedate"
			}
			Copy-Item $File.FullName "$xmlReqShare\$Server\requestlogs\$filedate" -Force
		}
	}
}

#****************************************************************
#     Backup the App Config Values on App Servers with tasks    *
#****************************************************************
Write-Host 'Backup App Config'
$AppConfigBackup = '\\dvfs-prod\WebApp Deploy\LocalTaskConfig'

& $Robo "\\cbcdv-app01p\c$\app\conf" "$AppConfigBackup\cbcdv-app01p" /mir /e /nfl /ndl
& $Robo "\\cbcdv-app02bp\c$\app\conf" "$AppConfigBackup\cbcdv-app02bp" /mir /e /nfl /ndl
& $Robo "\\cbcdv-app01bp\c$\app\conf" "$AppConfigBackup\cbcdv-app01bp" /mir /e /nfl /ndl
& $Robo "\\DVDR-Task01\c$\app\conf" "$AppConfigBackup\DVDR-Task01" /mir /e /nfl /ndl

Write-Host 'Send Copies to DR'
$AppConfigBackup = '\\dvdr-fs01\WebApp Deploy\LocalTaskConfig'

& $Robo "\\cbcdv-app01p\c$\app\conf" "$AppConfigBackup\cbcdv-app01p" /mir /e /nfl /ndl
& $Robo "\\cbcdv-app02bp\c$\app\conf" "$AppConfigBackup\cbcdv-app02bp" /mir /e /nfl /ndl
& $Robo "\\cbcdv-app01bp\c$\app\conf" "$AppConfigBackup\cbcdv-app01bp" /mir /e /nfl /ndl
& $Robo "\\DVDR-Task01\c$\app\conf" "$AppConfigBackup\DVDR-Task01" /mir /e /nfl /ndl

#*********************************************************
#     Backup the Automated task files for each server    *
#*********************************************************
#Write-Host 'Backup Automated tasks'
#$AutoTasksBackup = '\\dvfs-prod\WebApp Deploy\TaskBackups'

#& $Robo "\\cbcnas04\DV_PROD_Tasks" "$AutoTasksBackup\cbcnas04" /mir /e /nfl /ndl
#& $Robo "\\cbcdv-app01bp\C$\apps" "$AutoTasksBackup\cbcdv-app01bp" /mir /e /nfl /ndl
#& $Robo "\\cbcdv-app02bp\C$\apps" "$AutoTasksBackup\cbcdv-app02bp" /mir /e /nfl /ndl
#& $Robo "\\cbcdv-app02bp\C$\apps" "$AutoTasksBackup\cbcdv-app02bp" /mir /e /nfl /ndl

#Write-Host 'Send Copies to DR'
#$AutoTasksBackup = '\\dvdr-fs01\WebApp Deploy\TaskBackups'

#& $Robo "\\cbcnas04\DV_PROD_Tasks" "$AutoTasksBackup\cbcnas04" /mir /e /nfl /ndl
#& $Robo "\\cbcdv-app01bp\C$\apps" "$AutoTasksBackup\cbcdv-app01bp" /mir /e /nfl /ndl
#& $Robo "\\cbcdv-app02bp\C$\apps" "$AutoTasksBackup\cbcdv-app02bp" /mir /e /nfl /ndl
#& $Robo "\\cbcdv-app02bp\C$\apps" "$AutoTasksBackup\cbcdv-app02bp" /mir /e /nfl /ndl

#*********************************************
#     Cleanup of folders on the fileshare    *
#*********************************************
Write-Host 'Clean scripts'
Cleanup $BaseLog 5 'Logs' '*.log'
Cleanup '\\dfs\nas\DV_Shared\Logs\AppLogs' 30 'AppLogs-Cleanup' '*.zip'
Cleanup '\\dfs\nas\DV_Shared\Logs\WebLogs' 90 'WebLogs-Cleanup' '*.zip'
Cleanup '\\dfs\nas\DV_Shared\Logs\TaskLogs' 30 'TaskLogs-Cleanup' '*.*'
Cleanup '\\dfs\nas\DV_Shared\UploadFilesEnc' 365 'UploadFilesEnc-Cleanup' '*.enc'
Cleanup '\\dfs\nas\DV_FS\WebClusterFiles\4506SSA\DeleteFax' 90 '4506SSA-DeleteFax' '*.*'
Cleanup '\\dfs\nas\DV_FS\WebClusterFiles\Fax\outbound\backup' 14 'Fax-out-bkup' '*.*'
Cleanup '\\cbcnas05\dv_prod_tasks\IRSRobot3_KenViviano\html\trans\backup' 10 'Vivano-fax' '*.enc'
Cleanup '\\dfs\nas\DV_FS\WebClusterFiles\temp' 7 'WCF-temp' '*.*'
Cleanup '\\dfs\nas\DV_FS\WebClusterFiles\watchlistauthrequests' 7 'WCF-wlauthreq' '*.*'
Cleanup '\\dfs\nas\DV_Shared\xmlreqs' 120 'xmlreqs' '*.*'
Cleanup '\\dfs\nas\DV_Shared\TaskLoads\UVLBulkMatch\Backup' 60 'UVLBulkMatch' '*.enc'
Cleanup '\\dfs\nas\DV_Shared\TaskLoads\NMLS\backup' 60 'NMLS' '*.csv'


Cleanup '\\cbcefs-fileserv\DFS_Test\WebClusterFiles\temp' 7 'WCF-temp' '*.*'
Cleanup '\\cbcefs-fileserv\DFS_Test\WebClusterFiles\watchlistauthrequests' 7 'WCF-wlauthreq' '*.*'
Cleanup '\\cbcefs-fileserv\DFS_Test\WebClusterFiles\4506SSA\DeleteFax' 30 '4506SSA-DeleteFax' '*.*'
Cleanup '\\cbcefs-fileserv\DFS_Test\WebClusterFiles\Fax\outbound\backup' 14 'Fax-out-bkup' '*.*'


Cleanup '\\cbcefs-fileserv\DFS_UAT\WebClusterFiles\temp' 7 'WCF-temp' '*.*'
Cleanup '\\cbcefs-fileserv\DFS_UAT\WebClusterFiles\watchlistauthrequests' 7 'WCF-wlauthreq' '*.*'
Cleanup '\\cbcefs-fileserv\DFS_UAT\WebClusterFiles\4506SSA\DeleteFax' 30 '4506SSA-DeleteFax' '*.*'
Cleanup '\\cbcefs-fileserv\DFS_UAT\WebClusterFiles\Fax\outbound\backup' 14 'Fax-out-bkup' '*.*'















