﻿###########################################################
#         Date: 4/22/2014                                 #
#      Helpbox: N/A                                       #
# Steps Needed: Change Path of files needing encrypted    #
#      Purpose: Encrypt Files and delete files            #
###########################################################

########################################################### 
#   Needed: Change $Files for files needing encryption    #
###########################################################

$Files = Get-ChildItem -Recurse \\cbcnas\tmptest\sysadmin.enc
$DVSec = "C:\dvsec\dvsec.exe"

Foreach ($File in $Files)
{
		if ($File.PSIsContainer -eq $false)
	    {
		& $DVSec -e $File.FullName
		Remove-Item $File.FullName -Exclude *.enc
		}
}

####################################################################
#   Needed: Change $Files2 for files needing deleted -Disabled     #
####################################################################

#$Files2 = Get-ChildItem -Recurse -Exclude *.enc C:\Users\bryan.kloss\Desktop\Test

#Foreach ($File in $Files2)
{
	#if ($File.PSIsContainer -eq $false){Remove-Item $File -Force}
}

		