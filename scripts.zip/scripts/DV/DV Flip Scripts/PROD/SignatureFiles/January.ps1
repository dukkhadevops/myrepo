﻿##################################################################################################################################
#
#     Name: CopyFiles.ps1
#   Author: Trevor Brown
#     Date: 07 January 2015
#  Helpbox: 187252
#  Purpose: Copy Files from one location to another
#
##################################################################################################################################

Param (
[string]$strPathSource = "C:\Scripts\Scripts\LIVE\DataVerify\PROD\SignatureFiles\",
[string]$strPathDestBegin = "\\dataverify-01fp\dfs\sharedfiles\4506files\January_2016",
[string]$strFileSource = $strPathSource + "January_Esig_2016.txt",
[string]$strLogFile = $strPathSource + "CopyResultsJanuary.Log"
)

if (Test-Path $strLogFile)
   {
   Remove-Item $strLogFile -Force -Confirm:$false
   }

foreach ($File in Get-Content $strFileSource)
   {
   if (Test-Path $File)
      {
	  $strFileDest = $strPathDestBegin + $File.substring(43)
	  $strPathDest = Split-Path $strFileDest -Parent
	  if (!(Test-Path $strPathDest))
	     {
		 New-Item -ItemType Directory -Path $strPathDest
		 }
      Copy-Item $File $strFileDest
	  "Copied: " + $File | Out-File $strLogFile -Append
      }
   else
      {
	  "" | Out-File $strLogFile -Append
	  "##############################" | Out-File $strLogFile -Append
	  "# Below File does not exist: #" | Out-File $strLogFile -Append
	  "##############################" | Out-File $strLogFile -Append
	  $File | Out-File $strLogFile -Append
	  "" | Out-File $strLogFile -Append
	  }
   }