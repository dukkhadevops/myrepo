#Specify servers in an array variable
[array]$servers = "dvdr-web01","dvdr-web02","dvdr-web03","dvdr-web04","dvdr-gw01","dvdr-gw02","dvdr-inet01","dvdr-inet02","dvdr-app01","dvdr-app02","dvdr-pdfgen01","dvdr-pdfgen02"
#Step through each server in the array and perform an IISRESET
#Also show IIS service status after the reset has completed
foreach ($server in $servers)
{
    Write-Host "Restarting IIS on server $server..."
    IISRESET $server /noforce
    Write-Host "IIS status for server $server"
    IISRESET $server /status
}
Write-Host IIS has been restarted on all servers
