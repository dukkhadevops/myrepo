################################################################## 
#         Date: 09/05/2014                                       #
#      Helpbox: N/A                                              #
# Steps Needed: Change Server to remove file in path             #
#      Purpose: remove .txt file to add server from pool on F5   #
##################################################################


remove-item \\cbcdv-app03p\c$\app\shutdown.txt
remove-item \\cbcdv-gw01p\c$\app\shutdown.txt
remove-item \\cbcdv-gw03p\c$\app\shutdown.txt
remove-item \\cbcdv-web01p\c$\app\shutdown.txt
remove-item \\cbcdv-web03p\c$\app\shutdown.txt
remove-item \\cbcdv-web05p\c$\app\shutdown.txt
