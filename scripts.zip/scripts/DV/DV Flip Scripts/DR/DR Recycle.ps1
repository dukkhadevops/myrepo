﻿# Will reset IIS on all the servers for DataVerify DR

$iisreset = 'iisreset'
$psexec = 'C:\Windows\System32\PsExec.exe'

$IISReset = "$psexec \\dvdr-web01 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-web02 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-web03 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-web04 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-gw01 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-gw02 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-inet01 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-inet02 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-app01 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-app02 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-pdfgen01 $iisreset"
Invoke-Expression -Command $IISReset
$IISReset = "$psexec \\dvdr-pdfgen02 $iisreset"
Invoke-Expression -Command $IISReset