########################################################### 
#         Date: 09/05/2014                                #
#      Helpbox: N/A                                       #
# Steps Needed: Change Server to update file in path      #
#      Purpose: Add .txt file to remove from pool on F5   #
###########################################################


new-item \\cbcdv-app03p\c$\app\shutdown.txt -type file
new-item \\cbcdv-gw01p\c$\app\shutdown.txt -type file
new-item \\cbcdv-gw03p\c$\app\shutdown.txt -type file
new-item \\cbcdv-web01p\c$\app\shutdown.txt -type file
new-item \\cbcdv-web03p\c$\app\shutdown.txt -type file
new-item \\cbcdv-web05p\c$\app\shutdown.txt -type file

