﻿$computers = Get-Content -Path "C:\scripts\computers.txt"

$lbmonitorsourcepath = "\\dfs\nas\DV_Shared\WebApp Deploy\lbmonitor"
$lbmonitordestpath = "C:\www\dataverify"

#copy from share path to local site dir. keep in mind we want to keep permissions in tact and not overwrite permissions.
#may have to copy file by file


Foreach ($target in $computers) {

    $lbmonitordestpath = "\\$target\c$\www\dataverify"
    Copy-Item -Path $lbmonitorsourcepath -Recurse -Force -Destination $lbmonitordestpath -ErrorAction Stop
    }
		
	

