﻿# Secret Server Search And Return Password

$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users

$secretId = 12609
$proxy = New-WebServiceProxy -uri $url -UseDefaultCredential

# get a token for further use by authenticating using username/password
$result1 = $proxy.Authenticate($username, $password, '', $domain)
if ($result1.Errors.length -gt 0){
    $result1.Errors[0]
    exit
} 
else 
{
    $token = $result1.Token
}

$result2 = $proxy.GetSecret($token, $secretId, $false, $null)
if ($result2.Errors.length -gt 0){
    $result2.Errors[0]
}
else
{
    $result2.Secret
    $result2.Secret.Items[2].FieldName
    $result2.Secret.Items[2].Value

# If you want the data as XML
# $xml = convertto-xml $result.Secret -As string -Depth 20
# $xml

# if you want to update the password field
    <#
    $newpassword = 'foobee123456'
    $result2.Secret.Items[2].Value = $newpassword
    $result3 = $proxy.UpdateSecret($token, $result2.Secret)
    if ($result3.Errors.length -gt 0){
        $result1.Errors[0]
        exit
    } 
    #>
}