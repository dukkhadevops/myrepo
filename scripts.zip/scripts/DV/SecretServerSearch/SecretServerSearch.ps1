﻿# Secret Server Search

$url = "https://ss01uwap/webservices/sswebservice.asmx"
$username = "svcsccmosdzti"
$password = "pDBJCTU6evVDMwUjRwZy"
$domain = 'world'   # leave blank for local users

$searchterm = 'svc_dvintgw_d'
$proxy = New-WebServiceProxy -uri $url -UseDefaultCredential

# get a token for further use by authenticating using username/password
$result1 = $proxy.Authenticate($username, $password, '', $domain)
if ($result1.Errors.length -gt 0){
    $result1.Errors[0]
    exit
} 
else 
{
    $token = $result1.Token
}

# search secrets with our searchterm (authenticate by passing in our token)
Write-Host 'Searching for: ' $searchterm
$result2 = $proxy.SearchSecrets($token, $searchterm,$null,$null)
if ($result2.Errors.length -gt 0){
    $result2.Errors[0]
}
else
{
    Write-Host 'Got search results: ' $result2.SecretSummaries.length

    # If you want the data as XML
    # $xml = convertto-xml $result2.SecretSummaries -As string -Depth 20
    # $xml

    $result2.SecretSummaries | 
    ForEach-Object {
        If ($_.SecretName -eq $searchterm){
            Write-Host 'Exact Match - SecretId:' $_.SecretId '  Name:' $_.SecretName  ' FolderId:' $_.FolderId
        }
        else{
            Write-Host 'Close Match - SecretId:' $_.SecretId '  Name:' $_.SecretName  ' FolderId:' $_.FolderId
        }
    }

    # To view all details for all results
    #if ($result2.SecretSummaries.length -gt 0) {
    #    $result2.SecretSummaries
    #}
}