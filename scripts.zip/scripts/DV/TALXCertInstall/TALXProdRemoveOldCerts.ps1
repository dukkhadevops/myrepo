#assign variable where our computer list comes from
$computers = Get-Content -Path "C:\SVN\WindowsAdmins\Scripts\TALXCertInstall\Midland.txt"

Foreach ($target in $computers) {

    #region remove cert from cert snap in LocalMachine\My

    #if the connection to the target works, proceed
    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose){
        echo "test connection to $target SUCCESS"

        
        #invoke-command with the scriptblock to find the TALX cert and remove it
        Invoke-Command -Computername $target -ScriptBlock { 
            #Create object array of the correct certificate store
            $obj = New-Object System.Security.Cryptography.x509Certificates.x509Store("My","LocalMachine")
            #find the correct cert we want based on the thumbprint or name
            #$TALX = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { ($_.FriendlyName -like "*TALX*" -or $_.Subject -like "*TALX*") }
            $TALX = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { ($_.Thumbprint -like "e9d7f61f084349c49126deb51b8680460b16c6a6") }

            #open the certificate store array for read/write. Remove our Cert object. Close the cert store.
            $obj.Open("ReadWrite")
            $obj.Remove($TALX)
            $obj.Close() 
        }
        echo "Remove cert command ran on target $target."

    #endif
    }
    Else { echo "test connection to $target failed" }
    #endregion

    #region remove cert from local c:\app\certs

        #check if cert is there
        If (Test-Path -Path "\\$target\c`$\app\certs\talxprodcert.cer"){

            #rename old cert
            Rename-Item -Path "\\$target\c`$\app\certs\talxprodcert.cer" -NewName "talxprodcert.old"
        }
    #endregion
    
#endforeach
}