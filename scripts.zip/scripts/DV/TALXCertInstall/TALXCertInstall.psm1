﻿########
# Author:               Matt Keller
# Description:          Module to install Dataverify TALX Certificate
#########
# Example module import/use:
# $TALXCertInstall_modulepath = "C:\GIT\Scripts\DV\TALXCertInstall\TALXCertInstall.psm1"
# Import-Module -Name $TALXCertInstall_modulepath -Verbose
#
# TALXCertInstall $target $SVCaccount $environment $overwrite(optional)
# TALXCertInstall dvweb01uwwl svc_dvweb_l "test" $true
# TALXCertInstall dvweb01uwwl svc_dvweb_l "prod" $false
#########

#region cert variables
#assign variables for each cert
$certPath = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\"
# Prod Cert
$prodPlainTextPass = "iy7UoEehF3orCg2ZCQyp"
$PFXprodcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\talxprodcert.pfx"
$prodthumbvar = "‎40d8345312536c416e1ce39a1622b5f27660ab39"
$CERprodcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\talxprodcert.cer"
$IntCAprodcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\DigiCert SHA2 Assured ID CA.cer"
$IntCAprodcertthumb = "E12D2E8D47B64F469F518802DFBD99C0D86D3C6A"
$Rootprodcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\DigiCert Assured ID Root CA.cer"
$Rootprodcertthumb = "0563B8630D62D75ABBC8AB1E4BDFB5A899B24D43"
# Test Cert
$testPlainTextPass = "vsVJruXrZNPy76VCQv5d"
$PFXtestcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\talxtestcert.pfx"
$testthumbvar = "‎64d2e505a3384382aa41b185607f3e50886712e5"
$CERtestcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\talxtestcert.cer"
$IntCAtestcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\Test DigiCert SHA2 Assured ID CA.cer"
$IntCAtestcertthumb = "E12D2E8D47B64F469F518802DFBD99C0D86D3C6A"
$Roottestcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Equifax\2018\Contents\Test DigiCert Assured ID Root CA.cer"
$Roottestcertthumb = "0563B8630D62D75ABBC8AB1E4BDFB5A899B24D43"

#this returns the rightmost element from the path above (the cert name essentially)
$PFXprodcertname = Split-Path -Path $PFXprodcert -Leaf
$CERprodcertname = Split-Path -Path $CERprodcert -Leaf
$IntCAprodcertname = Split-Path -Path $IntCAprodcert -Leaf
$Rootprodcertname = Split-Path -Path $Rootprodcert -Leaf
$PFXtestcertname = Split-Path -Path $PFXtestcert -Leaf
$CERtestcertname = Split-Path -Path $CERtestcert -Leaf
$IntCAtestcertname = Split-Path -Path $IntCAtestcert -Leaf
$Roottestcertname = Split-Path -Path $Roottestcert -Leaf
#endregion

#region LogWrite function
$logfile = "C:\GIT\Scripts\DV\TALXCertInstall\TALXCertInstalllog.txt"
Function LogWrite{
    Param ([string]$logstring)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp -- $target -- $logstring"
    Add-Content $logfile -Value $Line
}
#endregion

#region import-pfxcertificate function
#Invoke-Command -ComputerName $target -ScriptBlock ${Function:Import-PfxCertificate1} -ArgumentList ("c:\temp\certs\DATAVER5.pfx","LocalMachine","My", "Summer09", $pfxThumb)
Function Import-PfxCertificate1 {
    param(
        [String]$certPath,
        [String]$certRootStore,
        [String]$certStore,
        [String]$pfxPass,
        [String]$certthumbvar
    )
    # Confirm certificate does not exist before installing
    $CheckForCert = Get-ChildItem -Path cert:\$certRootStore\$certStore | Where { $_.ThumbPrint -eq $certthumbvar }
    if ($CheckForCert -eq $null) {
        # Setup certificate
        $PrivateKeyPassword = $pfxPass | ConvertTo-SecureString -AsPlainText -Force
        $Flags = "MachineKeySet,PersistKeySet,Exportable"
        $Certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $Certificate.Import($certPath, $PrivateKeyPassword, $Flags)

        # Install certificate into machine store
        $Store = New-Object System.Security.Cryptography.X509Certificates.X509Store($certStore,$certRootStore)
        $Store.Open("MaxAllowed")
        $Store.Add($Certificate)
        $Store.Close()
    }
    Else {
        echo "`n*** PFX Certificate is already installed ***"
    }
}
#endregion

#region function to set certificate permissions
Function Set-CertificatePermission {
    param(
        [Parameter(Position=1, Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$pfxThumbPrint,

        [Parameter(Position=2, Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$serviceAccount
    )

    $cert = Get-ChildItem -Path cert:\LocalMachine\My | Where-Object -FilterScript { $PSItem.ThumbPrint -eq $pfxThumbPrint }

    # Specify the user, the permissions and the permission type
    $permission = "$($serviceAccount)","Read,FullControl","Allow"
    $accessRule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $permission

    # Location of the machine related keys
    $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\"
    $keyName = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
    $keyFullPath = $keyPath + $keyName

    try {
        # Get the current acl of the private key
        $acl = (Get-Item $keyFullPath).GetAccessControl('Access')

        # Add the new ace to the acl of the private key
        $acl.AddAccessRule($accessRule)

        # Write back the new acl
        Set-Acl -Path $keyFullPath -AclObject $acl
    }
    catch {
        throw $_
    }
}
#endregion

#region function to install the certificates
function TALXCertInstall { 
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true,Position=1)]
            [string]$target,

        [Parameter(Mandatory=$true,Position=2)]
            [string]$SVCaccount,

        [Parameter(Mandatory=$true,Position=3)]
            [ValidateSet('Test','Prod')]
            [string]$environment,

        [Parameter(Mandatory=$false,Position=4)]
            $overwrite = $false
    )

    # variables
    $destpath = "\\" + $target + "\c$\temp\certs\"
    $localpath = "c:\temp\certs\"
    $appcertsdestpath = "\\" + $target + "\c$\app\certs\"
    $appcertslocalpath = "c:\app\certs\"
    $environment = $($environment.ToLower())

    #test connection. if connection works, then proceed, erroraction = stop
    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose) {
        echo "test connection to $target SUCCESS"
        echo " "
        LogWrite "Test connection to $target SUCCESS"

        #region setup each targets local c:\temp\certs and copy certs
        #Do until tries = 3, try the copies and if success then success=true. catch and write to log and also sleep for 5s before continue
        #catch with erroraction = silentylycontinue so the retry loop continues
        $tries = 0
        $success = $null
        Do {
            Try {
                If (!(test-path $destpath)) {
                    #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
                    Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "$localpath exists or was created on $target"
                LogWrite "$localpath exists or was created on $target"

                # Quick pause for C:\temp\certs folder creation
                Start-Sleep -Seconds 5

                # copy certs
                Copy-Item -Path $PFXprodcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $CERprodcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $IntCAprodcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $Rootprodcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $PFXtestcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $CERtestcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $IntCAtestcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $Roottestcert -Destination $destpath -Force -ErrorAction Stop
                $success = $true
                echo " "
                echo "cert copies okay on $target"
                LogWrite "cert copies okay on $target"
            }
            Catch {
                echo "failed creating $localpath or copying certs on $target"
                LogWrite "failed creating $localpath or copying certs on $target. trycounter = $tries"
                Start-Sleep -Seconds 5
                $erroractionpreference="SilentlyContinue"
            }
            #increment tries
            $tries++
        #end do
        } Until ($tries -eq 3 -or $success)
        if (-not($success)) {exit}
        #endregion

        #region check if c:\app\certs exists on host, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
            If (!(test-path $appcertsdestpath)) {
                Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $appcertslocalpath -ErrorAction Stop
                # Quick pause for C:\app\certs folder creation
                Start-Sleep -Seconds 5
            }
            echo " "
            echo "$appcertslocalpath exists or was created on $target"
            LogWrite "$appcertslocalpath exists or was created on $target"
        }
        Catch {
            echo "failed creating $appcertslocalpath on $target"
            LogWrite "failed creating $appcertslocalpath on $target"
            break
        }
        #endregion

        #region put cert in c:\app\certs & rename old to .old
        $appcertdest = $appcertsdestpath + "talx" + $environment + "cert.cer"
        $appcertdestold = $appcertsdestpath + "talx" + $environment + "cert.cer.old"
        $appcertname = Split-Path -Path $appcertdest -Leaf
        $copythiscert = $certPath + "talx" + $environment + "cert.cer"

        #check if cert exists
            #if overwrite=true then overwrite
            #else output we are not overwriting
        #else the cert doesnt exist
            #cert doesn't exist so copy

        #if c:\app\certs\talx[$env]cert.cer exists...
        If (Test-Path $appcertdest) {
            echo "$appcertdest exists"
            LogWrite "$appcertdest exists"

            #if overwrite=true then proceed with overwrite
            If ($overwrite -eq $true) {
                #if talx[$env]cert.cer.old exists, delete it
                If (Test-Path $appcertdestold) {
                    echo "$appcertdestold exists too so we need to remove it"
                    LogWrite "$appcertdestold exists too so we need to remove it"
                    Remove-Item $appcertdestold -Force
                    echo "removed $appcertdestold"
                    LogWrite "removed $appcertdestold"
                }

                #rename talx[$env]cert.cer to talx[$env]cert.cer.old
                Rename-Item -path $appcertdest -NewName "$appcertname.old" -Force
                echo "$appcertdest renamed to .old"
                LogWrite "$appcertdest renamed to .old"

                #copy non-private-key cert to c:\app\certs
                Copy-Item -path $copythiscert -Destination $appcertsdestpath -Force -ErrorAction Stop
                echo "copied $copythiscert to $appcertsdestpath"
                LogWrite "copied $copythiscert to $appcertsdestpath"
            }
            #else overwrite=false so output that
            Else {
                echo "overwrite = $overwrite so no overwrite"
                LogWrite "overwrite = $overwrite so no overwrite"
            }
        #endif
        }
        #else if talxtestcert.cer doesnt exist, just copy it
        Else {
            Copy-Item -path $copythiscert -Destination $appcertsdestpath -Force -ErrorAction Stop
            echo "copied $copythiscert to $appcertsdestpath"
            LogWrite "copied $copythiscert to $appcertsdestpath"
        }
        #endregion

        #region for importing certs - invoke cert import command with password

        If ($environment -eq "Prod"){
            $certthumbvar = $prodthumbvar #Prod Cert Thumbprint
            $PlainTextPass = $prodPlainTextPass
            $PFXlocalcert = $localpath + $PFXprodcertname #Prod Cert
            $IntCAlocalcert = $localpath + $IntCAprodcertname #IntCA
            $IntCAcertthumb = $IntCAprodcertthumb
            $Rootlocalcert = $localpath + $Rootprodcertname #Root
            $Rootcertthumb = $Rootprodcertthumb
        }
        Else {
            $certthumbvar = $testthumbvar #Test Cert Thumbprint
            $PlainTextPass = $testPlainTextPass
            $PFXlocalcert = $localpath + $PFXtestcertname #Test Cert
            $IntCAlocalcert = $localpath + $IntCAtestcertname #IntCA
            $IntCAcertthumb = $IntCAtestcertthumb
            $Rootlocalcert = $localpath + $Roottestcertname #Root
            $Rootcertthumb = $Roottestcertthumb
        }
        Try {
            Invoke-Command -ComputerName $target -ScriptBlock ${Function:Import-PfxCertificate1} -ArgumentList ($PFXlocalcert, "LocalMachine", "My", $PlainTextPass, $certthumbvar)
            echo " "
            echo "############################################################################################################################################"
            echo "local cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "local cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($IntCAlocalcert,$IntCAcertthumb)
                # Confirm certificate does not exist before installing
                $CheckForCert = Get-ChildItem -Path cert:\LocalMachine\CA | Where { $_.ThumbPrint -eq $IntCAcertthumb }
                if ($CheckForCert -eq $null) {
                    Import-Certificate -FilePath $IntCAlocalcert -CertStoreLocation Cert:\LocalMachine\CA
                }
                else {
                    echo "*** Intermediate Certificate is already installed ***"
                }
            } -ArgumentList ($IntCAlocalcert,$IntCAcertthumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "INTERMEDIATE cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "INTERMEDIATE cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($Rootlocalcert,$Rootcertthumb)
                # Confirm certificate does not exist before installing
                $CheckForCert = Get-ChildItem -Path cert:\LocalMachine\Root | Where { $_.ThumbPrint -eq $Rootcertthumb }
                if ($CheckForCert -eq $null) {
                    Import-Certificate -FilePath $Rootlocalcert -CertStoreLocation Cert:\LocalMachine\Root
                }
                else {
                    echo "*** Root Certificate is already installed ***"
                }
            } -ArgumentList ($Rootlocalcert,$Rootcertthumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "ROOT cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "ROOT cert import okay"
        }
        Catch {
            echo "failed cert imports on $target"
            LogWrite "failed cert imports"
            break
        }
        #endregion

        #region for setting private key permissions on TALX cert
        Try {
            #Set-CertificatePermission $certthumbvar $SVCaccount
            Invoke-Command -ComputerName $target -ScriptBlock ${Function:Set-CertificatePermission} -ArgumentList ($certthumbvar, $SVCaccount)
            echo " "
            echo "############################################################################################################################################"
            echo "Certificate Private Key Permissions for $SVCaccount set on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "Certificate Private Key Permissions for $SVCaccount set on $target"
        }
        Catch {
            echo "failed to set Certificate Private Key Permissions for $SVCaccount on $target"
            LogWrite "setting Certificate Private Key Permissions for $SVCaccount failed on $target"
            break
        }
        #endregion

        #region cleanup c:\temp\certs
        Try {
            Invoke-Command -Computername $target -ScriptBlock { param($p1) remove-item -Path $p1 -recurse -Force } -ArgumentList $localpath -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "$localpath deleted on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "c:\temp\certs cleanup success"
        }
        Catch {
            echo "failed to delete $localpath on $target"
            LogWrite "failed to delete $localpath on $target"
            break
        }
        #endregion

        # Quick pause for C:\temp\certs folder cleanup
        Start-Sleep -Seconds 5

        #iisreset if you want it
        #invoke-command -computername $target {cd C:\Windows\System32\; ./cmd.exe /c "iisreset" }

        #end if for test connection
    }
    Else { 
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
        LogWrite "connection to $target failed. Try running winrm /quickconfig on the destination host and try again" 
    }
#end function
}
#endregion