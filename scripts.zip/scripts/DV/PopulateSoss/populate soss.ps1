$computers = Get-Content -Path "C:\Git\Scripts\DV\PopulateSoss\computers.txt"

#soss.exe
$sossexelocalpath = "C:\Program Files\Scaleout_Software\StateServer\soss.exe"
$sossexeargs = "populate"
# In case you need to remove an old gateway before populating a new one
#$sossexeargs1 = "remove 723,10.240.90.245,724"

Foreach ($target in $computers) {

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #run soss.exe populate
        echo "starting soss.exe populate on $target"
        Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs -ErrorAction Stop
        echo "soss.exe populate successful on $target"

    #endif
    }
#endforeach
}