#region cert variables
#assign variables for each cert
$cert1 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\www.dataverify.com\2019\dataverify.com.pfx"
$cert2 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\www.dataverify.com\2019\process\intermediate.cer"
$cert3 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\www.dataverify.com\2019\process\root.cer"

#this returns the rightmost element from the path above (the cert name essentially)
$cert1name = Split-Path -Path $cert1 -Leaf
$cert2name = Split-Path -Path $cert2 -Leaf
$cert3name = Split-Path -Path $cert3 -Leaf
#endregion

#assign variable where our computer list comes from
$computers = Get-Content -Path "C:\GIT\Scripts\DV\DataverifyCOMCertInstall\temp.txt"

#For the region where we set the Permissions on the private key - you need to update these variables
#This is the thumbprint for the cert we're looking for and the service account we need to set permissions on
#these will change based on the environment(service account) and whether it uses the test cert or prod cert
$testthumbvar = ""
$testaccountvar1 = "svcdvservicewebq"
$testaccountvar2 = "svcdvservicewebt"
$testaccountvar3 = "svc_dvinwebapi_q"
$testaccountvar4 = "svc_dvinwebapi_u"
$prodthumbvar = "c388755c3cba09384953597eb2699be88799f879"
$prodaccountvar1 = "dvservice"

#region funtion to set certificate permissions
Function Set-CertificatePermission
{
 param
 (
    [Parameter(Position=1, Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$pfxThumbPrint,

    [Parameter(Position=2, Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$serviceAccount
 )

 $cert = Get-ChildItem -Path cert:\LocalMachine\My | Where-Object -FilterScript { $PSItem.ThumbPrint -eq $pfxThumbPrint; };

 # Specify the user, the permissions and the permission type
 $permission = "$($serviceAccount)","Read,FullControl","Allow"
 $accessRule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $permission;

 # Location of the machine related keys
 $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\";
 $keyName = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName;
 $keyFullPath = $keyPath + $keyName;

 try
 {
    # Get the current acl of the private key
    $acl = (Get-Item $keyFullPath).GetAccessControl('Access')

    # Add the new ace to the acl of the private key
    $acl.AddAccessRule($accessRule);

    # Write back the new acl
    Set-Acl -Path $keyFullPath -AclObject $acl;
 }
 catch
 {
    throw $_;
 }
}
#endregion

Foreach ($target in $computers) {
        #more variables
        $destpath = "\\" + $target + "\c$\temp\certs\"
        $localpath = "c:\temp\certs\"

        #region LogWrite function
        $logfile = "C:\GIT\Scripts\DV\DataverifyCOMCertInstall\log.txt"
        Function LogWrite{
            Param ([string]$logstring)
            $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
            $Line = "$Stamp -- $target -- $logstring"
            Add-Content $logfile -Value $Line
        }
        #endregion

        #test connection. if connection works, then proceed, erroraction = stop
        If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose){
        echo "test connection to $target SUCCESS"
        echo " "
        LogWrite "Test connection to $target SUCCESS"

        #region setup each targets local c:\temp\certs
        Try {
                If(!(test-path $destpath))
                {
                    #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
                    Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "$destpath exists or was created on $target"
            }

        Catch {
                echo "failed creating $destpath on $target"
                break
              }
        #endregion

        #region copy each cert to c:\temp\certs

        #Do until tries = 3, try the copies and if success then success=true. catch and write to log and also sleep for 5s before continue
        #catch with erroraction = silentylycontinue so the retry loop continues
        $tries = 0
        $success = $null
        Do {
            Try {
                    #copy everything to c:\temp\certs
                    Copy-Item -Path $cert1 -Destination $destpath  -Force -ErrorAction Stop
                    Copy-Item -Path $cert2 -Destination $destpath  -Force -ErrorAction Stop
                    Copy-Item -Path $cert3 -Destination $destpath  -Force -ErrorAction Stop

                    #success
                    $success = $true

                    echo " "
                    echo "cert copies okay on $target"
                    LogWrite "cert copies okay"
                 }

            Catch {
                    echo "failed copying certs on $target"
                    LogWrite "cert copies failed. trycounter = $tries" 
                    Start-Sleep -s 5
                    $erroractionpreference="SilentlyContinue"

                    #break
                   }

            #increment tries
            $tries++

        #end do
        }

        Until ($tries -eq 3 -or $success)
        if (-not($success)){exit}
        
        #endregion

        #region for solo cert with password - invoke cert import command with password
    
        $PlainTextPass = "PleaseImportMe"
        $cred = $PlainTextPass | ConvertTo-SecureString -AsPlainText -Force
        $localcert1 = $localpath + $cert1name
        $localcert2 = $localpath + $cert2name
        $localcert3 = $localpath + $cert3name

        Try {
                #invoke command on $target passing a scriptblock to execute import-pfxcertificate with $p1 & $p2 params. -Argumentlist specifies the ordered params so $p1 becomes $localscert1 & $p2 becomes $cred
                Invoke-Command -Computername $target -ScriptBlock { param($p1,$p2) Import-PfxCertificate -FilePath $p1 -CertStoreLocation Cert:\LocalMachine\My -Password $p2 } -ArgumentList ($localcert1,$cred) -ErrorAction Stop
           
                echo " "
                echo "############################################################################################################################################"
                echo "local cert import okay on $target"
                echo "############################################################################################################################################"
                LogWrite "local cert import okay"

                Invoke-Command -Computername $target -ScriptBlock { param($p1) Import-Certificate -FilePath $p1 -CertStoreLocation Cert:\LocalMachine\CA } -ArgumentList ($localcert2) -ErrorAction Stop
                echo " "
                echo "############################################################################################################################################"
                echo "INTERMEDIATE cert import okay on $target"
                echo "############################################################################################################################################"
                echo " "
                LogWrite "INTERMEDIATE cert import okay"

                Invoke-Command -Computername $target -ScriptBlock { param($p1) Import-Certificate -FilePath $p1 -CertStoreLocation Cert:\LocalMachine\Root } -ArgumentList ($localcert3) -ErrorAction Stop
                echo " "
                echo "############################################################################################################################################"
                echo "ROOT cert import okay on $target"
                echo "############################################################################################################################################"
                echo " "
                LogWrite "ROOT cert import okay"
             }

        Catch {
                echo "failed cert imports on $target"
                LogWrite "failed cert imports"
                break
               }
        #endregion 

        #region for setting private key permissions on TALX cert
        Try {
                #Set-CertificatePermission $prodthumbvar $prodaccountvar1, 2, & 3
                Invoke-Command -ComputerName $target -ScriptBlock ${Function:Set-CertificatePermission} -ArgumentList ($prodthumbvar, $prodaccountvar1)
                echo " "
                echo "############################################################################################################################################"
                echo "Certificate Private Key Permissions set on $target"
                echo "############################################################################################################################################"
                echo " "
                LogWrite "Certificate Private Key Permissions set on $target"
            }

        Catch {
                echo "failed to set Certificate Private Key Permissions on $target"
                LogWrite "setting Certificate Private Key Permissions failed"
                break
                }
        #endregion

        #region cleanup c:\temp\certs
        Try {
            
                Invoke-Command -Computername $target -ScriptBlock { param($p1) remove-item -Path $p1 -recurse -Force } -ArgumentList $localpath -ErrorAction Stop
                echo " "
                echo "############################################################################################################################################"
                echo "$localpath deleted on $target"
                echo "############################################################################################################################################"
                echo " "
                LogWrite "c:\temp\certs cleanup success"
            }

        Catch {
                echo "failed to delete $localpath on $target"
                LogWrite "failed to delete c:\temp\certs"
                break
                }
        #endregion

        #sleep for 15 seconds before starting on the next target
        Start-Sleep -s 15

        #iisreset if you want it
        #invoke-command -computername $target {cd C:\Windows\System32\; ./cmd.exe /c "iisreset" }

        #end if for test connection
        }

        Else { 
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
        LogWrite "connection to $target failed. Try running winrm /quickconfig on the destination host and try again" 
        }
        

#end for each target in computers
}