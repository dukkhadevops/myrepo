########
# Author:               Matt Keller / John Basso
# Description:          Module to install Dataverify.com Certificate
#########
# Example module import/use:
# $DataverifyCOMCertInstall_modulepath = "C:\GIT\Scripts\DV\DataverifyCOMCertInstall\DataverifyCOMCertInstall.psm1"
# Import-Module -Name $DataverifyCOMCertInstall_modulepath -Verbose
#
# DataverifyCOMCertInstall $target $SVCaccount
# DataverifyCOMCertInstall dvweb02uwwl svc_dvweb_l
#########

#region cert variables
#assign variables for each cert
$PlainTextPass = "PleaseImportMe"
$PFXcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\www.dataverify.com\2019\dataverify.com.pfx"
$certthumbvar = "c388755c3cba09384953597eb2699be88799f879"
$IntCAcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\www.dataverify.com\2019\process\intermediate.cer"
$IntCAcertthumb = "27AC9369FAF25207BB2627CEFACCBE4EF9C319B8"
$Rootcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\www.dataverify.com\2019\process\root.cer"
$Rootcertthumb = "47BEABC922EAE80E78783462A79F45C254FDE68B"

#this returns the rightmost element from the path above (the cert name essentially)
$PFXcertname = Split-Path -Path $PFXcert -Leaf
$IntCAcertname = Split-Path -Path $IntCAcert -Leaf
$Rootcertname = Split-Path -Path $Rootcert -Leaf
#endregion

#region LogWrite function
$logfile = "C:\GIT\Scripts\DV\DataverifyCOMCertInstall\log.txt"
Function LogWrite{
    Param ([string]$logstring)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp -- $target -- $logstring"
    Add-Content $logfile -Value $Line
}
#endregion

#region import-pfxcertificate function
#Invoke-Command -ComputerName $target -ScriptBlock ${Function:Import-PfxCertificate1} -ArgumentList ("c:\temp\certs\DATAVER5.pfx","LocalMachine","My", "Summer09", $pfxThumb)
Function Import-PfxCertificate1 {
    param(
        [String]$certPath,
        [String]$certRootStore,
        [String]$certStore,
        [String]$pfxPass,
        [String]$certthumbvar
    )
    # Confirm certificate does not exist before installing
    $CheckForCert = Get-ChildItem -Path cert:\$certRootStore\$certStore | Where { $_.ThumbPrint -eq $certthumbvar }
    if ($CheckForCert -eq $null) {
        # Setup certificate
        $PrivateKeyPassword = $pfxPass | ConvertTo-SecureString -AsPlainText -Force
        $Flags = "MachineKeySet,PersistKeySet,Exportable"
        $Certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $Certificate.Import($certPath, $PrivateKeyPassword, $Flags)

        # Install certificate into machine store
        $Store = New-Object System.Security.Cryptography.X509Certificates.X509Store($certStore,$certRootStore)
        $Store.Open("MaxAllowed")
        $Store.Add($Certificate)
        $Store.Close()
    }
    Else {
        echo "`n*** PFX Certificate is already installed ***"
    }
}
#endregion

#region function to set certificate permissions
Function Set-CertificatePermission {
    param(
        [Parameter(Position=1, Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$pfxThumbPrint,

        [Parameter(Position=2, Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$serviceAccount
    )

    $cert = Get-ChildItem -Path cert:\LocalMachine\My | Where-Object -FilterScript { $PSItem.ThumbPrint -eq $pfxThumbPrint }

    # Specify the user, the permissions and the permission type
    $permission = "$($serviceAccount)","Read,FullControl","Allow"
    $accessRule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $permission

    # Location of the machine related keys
    $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\"
    $keyName = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
    $keyFullPath = $keyPath + $keyName

    try {
        # Get the current acl of the private key
        $acl = (Get-Item $keyFullPath).GetAccessControl('Access')

        # Add the new ace to the acl of the private key
        $acl.AddAccessRule($accessRule)

        # Write back the new acl
        Set-Acl -Path $keyFullPath -AclObject $acl
    }
    catch {
        throw $_
    }
}
#endregion

#region DataVerify.com Cert Install
Function DataverifyCOMCertInstall {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true,Position=1)]
            [string]$target,

        [Parameter(Mandatory=$true,Position=2)]
            [string]$SVCaccount
    )

    # variables
    $destpath = "\\" + $target + "\c$\temp\certs\"
    $localpath = "c:\temp\certs\"

    #test connection. if connection works, then proceed, erroraction = stop
    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose) {
        echo "test connection to $target SUCCESS"
        echo " "
        LogWrite "Test connection to $target SUCCESS"

        #region setup each targets local c:\temp\certs and copy certs
        #Do until tries = 3, try the copies and if success then success=true. catch and write to log and also sleep for 5s before continue
        #catch with erroraction = silentylycontinue so the retry loop continues
        $tries = 0
        $success = $null
        Do {
            Try {
                If (!(test-path $destpath)) {
                    #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
                    Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "$localpath exists or was created on $target"
                LogWrite "$localpath exists or was created on $target"

                # Quick pause for C:\temp\certs folder creation
                Start-Sleep -Seconds 5

                # copy certs
                Copy-Item -Path $PFXcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $IntCAcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $Rootcert -Destination $destpath -Force -ErrorAction Stop
                $success = $true
                echo " "
                echo "cert copies okay on $target"
                LogWrite "cert copies okay on $target"
            }
            Catch {
                echo "failed creating $localpath or copying certs on $target"
                LogWrite "failed creating $localpath or copying certs on $target. trycounter = $tries"
                Start-Sleep -Seconds 5
                $erroractionpreference="SilentlyContinue"
            }
            #increment tries
            $tries++
        #end do
        } Until ($tries -eq 3 -or $success)
        if (-not($success)) {exit}
        #endregion

        #region for importing certs - invoke cert import command with password

        $PFXlocalcert = $localpath + $PFXcertname #Prod Cert
        $IntCAlocalcert = $localpath + $IntCAcertname #IntCA
        $Rootlocalcert = $localpath + $Rootcertname #Root

        Try {
            #invoke command on $target passing a scriptblock to execute import-pfxcertificate with $p1 & $p2 params. -Argumentlist specifies the ordered params so $p1 becomes $localscert1 & $p2 becomes $cred
            #Invoke-Command -Computername $target -ScriptBlock { param($p1,$p2) Import-PfxCertificate -FilePath $p1 -CertStoreLocation Cert:\LocalMachine\My -Password $p2 } -ArgumentList ($localcert1,$cred) -ErrorAction Stop
            Invoke-Command -ComputerName $target -ScriptBlock ${Function:Import-PfxCertificate1} -ArgumentList ($PFXlocalcert, "LocalMachine", "My", $PlainTextPass, $certthumbvar)           
            echo " "
            echo "############################################################################################################################################"
            echo "local cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "local cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($IntCAlocalcert,$IntCAcertthumb)
                # Confirm certificate does not exist before installing
                $CheckForCert = Get-ChildItem -Path cert:\LocalMachine\CA | Where { $_.ThumbPrint -eq $IntCAcertthumb }
                if ($CheckForCert -eq $null) {
                    Import-Certificate -FilePath $IntCAlocalcert -CertStoreLocation Cert:\LocalMachine\CA
                }
                else {
                    echo "*** Intermediate Certificate is already installed ***"
                }
            } -ArgumentList ($IntCAlocalcert,$IntCAcertthumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "INTERMEDIATE cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "INTERMEDIATE cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($Rootlocalcert,$Rootcertthumb)
                # Confirm certificate does not exist before installing
                $CheckForCert = Get-ChildItem -Path cert:\LocalMachine\Root | Where { $_.ThumbPrint -eq $Rootcertthumb }
                if ($CheckForCert -eq $null) {
                    Import-Certificate -FilePath $Rootlocalcert -CertStoreLocation Cert:\LocalMachine\Root
                }
                else {
                    echo "*** Root Certificate is already installed ***"
                }
            } -ArgumentList ($Rootlocalcert,$Rootcertthumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "ROOT cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "ROOT cert import okay"
        }
        Catch {
            echo "failed cert imports on $target"
            LogWrite "failed cert imports"
            break
        }
        #endregion

        #region for setting private key permissions on cert
        Try {
            #Set-CertificatePermission $certthumbvar $SVCaccount
            Invoke-Command -ComputerName $target -ScriptBlock ${Function:Set-CertificatePermission} -ArgumentList ($certthumbvar, $SVCaccount)
            echo " "
            echo "############################################################################################################################################"
            echo "Certificate Private Key Permissions for $SVCaccount set on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "Certificate Private Key Permissions for $SVCaccount set on $target"
        }
        Catch {
            echo "failed to set Certificate Private Key Permissions for $SVCaccount on $target"
            LogWrite "setting Certificate Private Key Permissions for $SVCaccount failed on $target"
            break
        }
        #endregion

        #region cleanup c:\temp\certs
        Try {
            Invoke-Command -Computername $target -ScriptBlock { param($p1) remove-item -Path $p1 -recurse -Force } -ArgumentList $localpath -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "$localpath deleted on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "c:\temp\certs cleanup success"
        }
        Catch {
            echo "failed to delete $localpath on $target"
            LogWrite "failed to delete $localpath on $target"
            break
        }
        #endregion

        # Quick pause for C:\temp\certs folder cleanup
        Start-Sleep -Seconds 5

        #iisreset if you want it
        #invoke-command -computername $target {cd C:\Windows\System32\; ./cmd.exe /c "iisreset" }

        #end if for test connection
    }
    Else { 
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
        LogWrite "connection to $target failed. Try running winrm /quickconfig on the destination host and try again" 
    }
#end function
}
#endregion