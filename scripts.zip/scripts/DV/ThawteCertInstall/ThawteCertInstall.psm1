﻿########
# Author:               Matt Keller / John Basso
# Description:          Module to install Thawte Intermediate and Root Certificates
#########
# Example module import/use:
# $ThawteCertInstall_modulepath = "C:\GIT\Scripts\DV\ThawteCertInstall\ThawteCertInstall.psm1"
# Import-Module -Name $ThawteCertInstall_modulepath -Verbose
#
# ThawteCertInstall $target
# ThawteCertInstall dvweb02uwwl
#########

#region cert variables
#assign variables for each cert
$IntCAcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Thawte\thawte EV SSL CA - G3.cer"
$IntCAcertthumb = "68060ca074ff36c7e81b0b338d7e8376790ed020"
$Rootcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\Thawte\thawte_primary_root_CA.cer"
$Rootcertthumb = "91c6d6ee3e8ac86384e548c299295c756c817b81"

#this returns the rightmost element from the path above (the cert name essentially)
$IntCAcertname = Split-Path -Path $IntCAcert -Leaf
$Rootcertname = Split-Path -Path $Rootcert -Leaf
#endregion

#region LogWrite function
$logfile = "C:\GIT\Scripts\DV\ThawteCertInstall\log.txt"
Function LogWrite{
    Param ([string]$logstring)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp -- $target -- $logstring"
    Add-Content $logfile -Value $Line
}
#endregion

#region Thawte Cert Install
Function ThawteCertInstall {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true,Position=1)]
            [string]$target
    )

    # variables
    $destpath = "\\" + $target + "\c$\temp\certs\"
    $localpath = "c:\temp\certs\"

    #test connection. if connection works, then proceed, erroraction = stop
    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose) {
        echo "test connection to $target SUCCESS"
        echo " "
        LogWrite "Test connection to $target SUCCESS"

        #region setup each targets local c:\temp\certs and copy certs
        #Do until tries = 3, try the copies and if success then success=true. catch and write to log and also sleep for 5s before continue
        #catch with erroraction = silentylycontinue so the retry loop continues
        $tries = 0
        $success = $null
        Do {
            Try {
                If (!(test-path $destpath)) {
                    #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
                    Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "$localpath exists or was created on $target"
                LogWrite "$localpath exists or was created on $target"

                # Quick pause for C:\temp\certs folder creation
                Start-Sleep -Seconds 5

                # copy certs
                Copy-Item -Path $IntCAcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $Rootcert -Destination $destpath -Force -ErrorAction Stop
                $success = $true
                echo " "
                echo "cert copies okay on $target"
                LogWrite "cert copies okay on $target"
            }
            Catch {
                echo "failed creating $localpath or copying certs on $target"
                LogWrite "failed creating $localpath or copying certs on $target. trycounter = $tries"
                Start-Sleep -Seconds 5
                $erroractionpreference="SilentlyContinue"
            }
            #increment tries
            $tries++
        #end do
        } Until ($tries -eq 3 -or $success)
        if (-not($success)) {exit}
        #endregion

        #region for importing certs - invoke cert import command

        $IntCAlocalcert = $localpath + $IntCAcertname #IntCA
        $Rootlocalcert = $localpath + $Rootcertname #Root

        Try {
            Invoke-Command -Computername $target -ScriptBlock {
                param($IntCAlocalcert,$IntCAcertthumb)
                # Confirm certificate does not exist before installing
                $CheckForCert = Get-ChildItem -Path cert:\LocalMachine\CA | Where { $_.ThumbPrint -eq $IntCAcertthumb }
                if ($CheckForCert -eq $null) {
                    Import-Certificate -FilePath $IntCAlocalcert -CertStoreLocation Cert:\LocalMachine\CA
                }
                else {
                    echo "*** Intermediate Certificate is already installed ***"
                }
            } -ArgumentList ($IntCAlocalcert,$IntCAcertthumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "INTERMEDIATE cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "INTERMEDIATE cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($Rootlocalcert,$Rootcertthumb)
                # Confirm certificate does not exist before installing
                $CheckForCert = Get-ChildItem -Path cert:\LocalMachine\Root | Where { $_.ThumbPrint -eq $Rootcertthumb }
                if ($CheckForCert -eq $null) {
                    Import-Certificate -FilePath $Rootlocalcert -CertStoreLocation Cert:\LocalMachine\Root
                }
                else {
                    echo "*** Root Certificate is already installed ***"
                }
            } -ArgumentList ($Rootlocalcert,$Rootcertthumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "ROOT cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "ROOT cert import okay"
        }
        Catch {
            echo "failed cert imports on $target"
            LogWrite "failed cert imports"
            break
        }
        #endregion

        #region cleanup c:\temp\certs
        Try {
            Invoke-Command -Computername $target -ScriptBlock { param($p1) remove-item -Path $p1 -recurse -Force } -ArgumentList $localpath -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "$localpath deleted on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "c:\temp\certs cleanup success"
        }
        Catch {
            echo "failed to delete $localpath on $target"
            LogWrite "failed to delete $localpath on $target"
            break
        }
        #endregion

        # Quick pause for C:\temp\certs folder cleanup
        Start-Sleep -Seconds 5

        #iisreset if you want it
        #invoke-command -computername $target {cd C:\Windows\System32\; ./cmd.exe /c "iisreset" }

        #end if for test connection
    }
    Else { 
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
        LogWrite "connection to $target failed. Try running winrm /quickconfig on the destination host and try again" 
    }
#end function
}
#endregion