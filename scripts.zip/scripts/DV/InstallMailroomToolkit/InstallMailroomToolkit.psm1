﻿########
# Author:               John Basso
# Description:          Module to install Mailroom Toolkit on Dataverify servers
#                       07/18/2019    script created and turned into module
#                       08/07/2019    Reconfigured to run installer from network path
#                       08/16/2019    Set default values for folder and license
#                       09/06/2019    Added parameter for COM Classes installation
#                       09/17/2019    Added parameter for updating existing installation
#                       11/19/2019    Changed parameter to auto-detect update based on folder name
#
#########
# Example module import/use:
# $InstallMailroomToolkit_modulepath = "C:\GIT\Scripts\DV\InstallMailroomToolkit\InstallMailroomToolkit.psm1"
# $target = "dvweb02uwwl"
# $type = "Full" # Can use "COM" to install COM Classes without BCC Architect or "Full" to include BCC Architect
# $foldername and $license are only needed if you want to override the default value (ie. if someone didn't update the module)
# $foldername = "MRTK-11-2019"
# $license = "1B6HEL3-AS1BF8-IMFGU"
# Import-Module -Name $InstallMailroomToolkit_modulepath -Verbose
# InstallMailroomToolkit $target $type $reboot $foldername $license
#########

#Optionally take in where you want to install, the type of install, where the latest installer is, and a license key, then install MRTK

function InstallMailroomToolkit{ 
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$false,Position=2)]
        [ValidateSet("Full", "COM")]
            [string]$type = "Full",

        [Parameter(Mandatory=$false,Position=3)]
            $reboot = $false,

        [Parameter(Mandatory=$false,Position=4)]
            [string]$foldername = "MRTK-01-2020",

        [Parameter(Mandatory=$false,Position=5)]
            [string]$license = "1B6HEL3-AS1BF8-IMFGU"
        )

    #test if can connect to machine
    If (Test-WSMan -ComputerName $computername -Verbose)
    {
        $destpath = "\\" + $computername + "\C$\scripts"
        $localpath = "C:\scripts"
        $destinstallpath = "\\" + $computername + "\C$\Program Files (x86)\Satori Software"
        $fileshareinstaller = "`"\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\$foldername\setup.exe`""
        $installparams = " -s -k`"$license`" -xT -oT -pT -fT -hT -vT /f2`"C:\scripts\"+$foldername+"_setup.log`""
        $COMinstallparams = " -s -k`"$license`" -xT -oT -pT -fT -hT /f2`"C:\scripts\"+$foldername+"_setup.log`""

        #Check Install Type
        If ($type -eq "Full"){
            $mrtkfullinstall = $fileshareinstaller+$installparams
        }else{
            $mrtkfullinstall = $fileshareinstaller+$COMinstallparams
        }

        #region check if c:\scripts exists on host, if not, create it.
        #invoke command on $computername passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath

        If(!(test-path $destpath))
        {
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
        }
        Else
        {
            echo " "
            echo "$localpath already exists"
        }
             
        #endregion
        
        #region mailroom install. Check if path exists and is up to date. Run installer with configured params.

        # if the path exists, check for latest update
        If ((Test-Path -Path $destinstallpath)) {
            echo "$destinstallpath already exists. Checking if Mailroom is up to date..."
            # Find existing Mailroom data and compare it to installation folder date
            # Program Folder name might be "BCC Architect" or "Satori Architect" so we need to pull it from the server
            $MRTKProgramFolder = Get-ChildItem $destinstallpath | Select Name
            # Set up path to address file
            if (($MRTKFolder.Name).Count -gt 1) {
                $MRTKProgramFolderName = $MRTKProgramFolder.Name[0]
            }
            else {
                $MRTKProgramFolderName = $MRTKProgramFolder.Name
            }
            $ExistingFilePath = $destinstallpath + "\" + $MRTKProgramFolderName + "\Data Files\Update.ini"
            # Get the date timestamp from the address file
            $ExistingFileCheck = Get-Item $ExistingFilePath | Select LastWriteTime
            # Get the existing file timestamp
            $ExistingFileDate = $ExistingFileCheck.LastWriteTime
            # Clear the quotes from the installer path
            $MRTKInstallerPath = $fileshareinstaller.Replace("""","")
            # Get the date timestamp from the installer
            $MRTKInstallerFileCheck = Get-Item $MRTKInstallerPath | Select LastWriteTime
            # Get the the Installer timestamp
            $MRTKInstallerFileDate = $MRTKInstallerFileCheck.LastWriteTime
            # Compare the Month/Year from the address file with the current MRTK install folder
            if ($ExistingFileDate -lt $MRTKInstallerFileDate) {
                echo "Mailroom is not up to date. Updating existing Mailroom install on $computername"
                $FlagMRTKinstall = $true
            }
            else {
                return "Mailroom is already installed and up to date."
            }
        }
        # else the path doesn't exist, so install
        Else {
            echo "$destinstallpath not found. Installing Mailroom on $computername"
            $FlagMRTKinstall = $true
        }
        # invoke installation
        if ($FlagMRTKinstall -eq $true) {
            # check for existing session
            if (Get-PSSession -ComputerName $computername){                
                Invoke-Command -Session $session -ScriptBlock {param($mrtkfullinstall) cmd /c $mrtkfullinstall} -ArgumentList $mrtkfullinstall -Verbose                
            }
            else{
                $credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"
                $session = New-PSSession -ComputerName $computername -Authentication Credssp -Credential $credential
                Invoke-Command -Session $session -ScriptBlock {param($mrtkfullinstall) cmd /c $mrtkfullinstall} -ArgumentList $mrtkfullinstall -Verbose
                Remove-PSSession $session
            }
            # reboot option
            echo "Mailroom installed on $computername"
            if ($reboot -eq $true) {
                echo "Sending Reboot command to $computername"
                shutdown -r -f -m \\$computername -t 01
            }
        }
        #endregion
    #endif
    }
    echo "exiting MailroomToolkit install"
#endfunction
}