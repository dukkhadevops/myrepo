﻿$filesharefolder = "\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\MRTK-05-2019"
$fileshareinstaller = "\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\MRTK-05-2019\setup.exe"
$license = "1B6HEL3-AS1BF8-IMFGU"
$computers = Get-Content -Path "C:\SVN\WindowsAdmins\DSC\DV\Lab\dvweb01uwwl\computers.txt"

#take in where you want to install, where the latest installer is, and a license key then install MRTK

function InstallMailroomToolkit{ 
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$True,Position=2)]
            [string]$filesharefolder,

        [Parameter(Mandatory=$True,Position=3)]
            [string]$license
        )

    #test if can connect to machine
    If (Test-WSMan -ComputerName $computername -Verbose)
    {
        $destscriptspath = "\\" + $computername + "\C$\scripts"
        $localscriptspath = "C:\scripts"
        $foldername = Split-Path $filesharefolder -Leaf
        $destfolderpath = $destscriptspath + "\" + $foldername
        $localfolderpath = $localscriptspath + "\" + $foldername
        $destinstallpath = "\\" + $computername + "\C$\Program Files (x86)\Satori Software"
        ######
        ###we're using {0} with the -f switch so we can construct these strings and variable replacements and pass them correctly to powershell
        ###basically, all the " and ' get confusing so this simplifies it some
        ######
        $setupexe = '{0}\setup.exe' -f $localfolderpath
        $installparams = ' -s -k{0} -xT -oT -pT -fT -hT -vT /f2"C:\scripts\{1}\setup.log"' -f $license, $foldername
        #$setupexe = $localfolderpath + "\" + "setup.exe"
        #$installparams = " -s -k`"$license`" -xT -oT -pT -fT -hT -vT /f2`"C:\scripts\$foldername\setup.log`""
        
        $arg1 = "-s"
        $arg2 = "-k`"$license`""
        $arg3 = "-xT"
        $arg4 = "-oT"
        $arg5 = "-pT"
        $arg6 = "-fT"
        $arg7 = "-hT"
        $arg8 = "-vT"
        $arg9 = "/f2`"C:\scripts\$foldername\setup.log`""
        $arrayparams = @("-s","-k`"$license`"","-xT","-oT","-pT","-fT","-hT","-vT","/f2`"C:\scripts\$foldername\setup.log`"")

        #region check if c:\scripts exists on host, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath

        If(!(test-path $destscriptspath))
        {
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) md $p1 } -ArgumentList $localscriptspath -ErrorAction Stop
        }
        Else
        {
            echo " "
            echo "$localscriptspath already exists"
        }
             
        #endregion

        #region check if C:\scripts\$destfolderpath exists, if not create and copy installer to c:\scripts
        If(!(test-path $destfolderpath))
        {
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) md $p1 } -ArgumentList $localfolderpath -ErrorAction Stop
            #copy file from $dynatracefileshare to destpath we know exists
            Copy-Item -Path $filesharefolder -Destination $destscriptspath -Recurse -ErrorAction Stop
            echo "copied $filesharefolder to $destscriptspath"
        }
        Else
        {
            echo "$destfolderpath already exists"
        }

        #endregion

        #region mailroom install. Check and see if path exists already. if it doesn't, run installer with params we want

        #if path exists, skip install
        If (Test-Path -Path $destinstallpath) {
            return "$destinstallpath exists already. Make sure Mailroom isn't installed already"
        }

        #else the path doesn't exist, so install
        Else {
            echo "$destinstallpath not found. Installing Mailroom on $computername"
            #invoke command start-process setup.exe with our $installparams
            #Invoke-Command -Computername $computername -ScriptBlock { param($p1,$p2) & "$p1" $p2 -Wait } -ArgumentList $setupexe, $installparams  -ErrorAction Stop

            $session = New-PSSession -ComputerName $ComputerName
            $fullinstallparams = $setupexe + $installparams
            Invoke-Command -Session $session -Verbose -ScriptBlock { 
                 & $using:setupexe $using:installparams 
            }
            
            
            #Invoke-Command -Session $session -Verbose -ScriptBlock { 
            #     $using:fullinstallparams 
            #}
            #Invoke-Command -Session $session -ScriptBlock { param($p1) C:\scripts\MRTK-05-2019\setup.exe $p1 } -ArgumentList $installparams -Verbose
            #Invoke-Command -Session $session -ScriptBlock { param($p1,$p2) & $p1 $p2 } -ArgumentList $setupexe, $arrayparams -Verbose 
            #Invoke-Command -Session $session -ScriptBlock { param($p0,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9) & $p0 $p1 $p2 $p3 $p4 $p5 $p6 $p7 $p8 $p9 } -ArgumentList $setupexe,$arg1,$arg2,$arg3,$arg4,$arg5,$arg6,$arg7,$arg8,$arg9 -Verbose
            #Invoke-Command -Session $session -ScriptBlock { $using:fullinstallparams }
            #Invoke-Command -Session $session -ScriptBlock { param($p1) $p1 } -ArgumentList $fullinstallparams -Verbose
            #Invoke-Command -Session $session -ScriptBlock { param($p1,$p2) $p1 $p2 } -ArgumentList $setupexe, $installparams -Verbose 
            
            ###this works
            #Invoke-Command -Session $session -ScriptBlock { C:\scripts\MRTK-05-2019\setup.exe -s -k"1B6HEL3-AS1BF8-IMFGU" -xT -oT -pT -fT -hT -vT /f2"C:\scripts\setup.log" }
            ###this works

            echo "Mailroom installed on $computername"
        }

        #endregion

    #endif
    }

#endfunction
}

InstallMailroomToolkit dvweb01uwwl "\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\MRTK-05-2019" "1B6HEL3-AS1BF8-IMFGU"


####################
###these didnt work
#Invoke-Command -ComputerName dvweb01uwwl -ScriptBlock {  Start-Process -filepath C:\scripts\MRTK-05-2019\setup.exe -wait -ArgumentList "-s", "-k'1B6HEL3-AS1BF8-IMFGU'", "-xT", "-oT", "-pT", "-fT", "-hT", "-vT", "/f2'C:\scripts\setup.log'" }
#Invoke-Command -ComputerName dvweb01uwwl -ScriptBlock {  
#        cd c:\scripts\MRTK-05-2019
#
#        .\setup.exe -s -k"1B6HEL3-AS1BF8-IMFGU" -xT -oT -pT -fT -hT -vT /f2"C:\scripts\setup.log"  
#         }