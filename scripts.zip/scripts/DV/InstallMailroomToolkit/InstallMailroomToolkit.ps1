﻿#########
# $fileshareroot = "\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\"
# $foldername = "MRTK-07-2019"
# $fileshareinstaller = "\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\MRTK-07-2019\setup.exe"
# $license = "1B6HEL3-AS1BF8-IMFGU"
# $computers = Get-Content -Path "C:\Git\DSC\DV\Lab\dvweb02uwwl\computers.txt"
#
# InstallMailroomToolkit dvweb02uwwl $foldername $license
# InstallMailroomToolkit dvweb02uwwl "MRTK-07-2019" "1B6HEL3-AS1BF8-IMFGU"
#########

#take in where you want to install, where the latest installer is, and a license key, then install MRTK

function InstallMailroomToolkit{ 
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$True,Position=2)]
            [string]$foldername,

        [Parameter(Mandatory=$True,Position=3)]
            [string]$license
        )

    #test if can connect to machine
    If (Test-WSMan -ComputerName $computername -Verbose)
    {
        $destscriptspath = "\\" + $computername + "\C$\scripts"
        $localscriptspath = "C:\scripts"
        $destinstallpath = "\\" + $computername + "\C$\Program Files (x86)\Satori Software"
        $fileshareinstaller = "`"\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\$foldername\setup.exe`""
        $installparams = " -s -k`"$license`" -xT -oT -pT -fT -hT -vT /f2`"C:\scripts\"+$foldername+"_setup.log`""
        $mrtkfullinstall = $fileshareinstaller+$installparams

        #region check if c:\scripts exists on host, if not, create it.
        #invoke command on $computername passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath

        If(!(test-path $destscriptspath))
        {
            Invoke-Command -Computername $computername -ScriptBlock { param($p1) md $p1 } -ArgumentList $localscriptspath -ErrorAction Stop
        }
        Else
        {
            echo " "
            echo "$localscriptspath already exists"
        }
             
        #endregion
        
        #region mailroom install. Check and see if path exists already. if it doesn't, run installer with params we want

        #if path exists, skip install
        If (Test-Path -Path $destinstallpath) {
            return "$destinstallpath exists already. Make sure Mailroom isn't installed already"
        }

        #else the path doesn't exist, so install
        Else {
            echo "$destinstallpath not found. Installing Mailroom on $computername"
            $credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"
            $session = New-PSSession -ComputerName $computername -Authentication Credssp -Credential $credential 
            Invoke-Command -Session $session -ScriptBlock {param($mrtkfullinstall) cmd /c $mrtkfullinstall} -ArgumentList $mrtkfullinstall -Verbose
            Remove-PSSession $session
            echo "Mailroom installed on $computername"
        }

        #endregion

    #endif
    }
    echo "exiting MailroomToolkit install"
#endfunction
}