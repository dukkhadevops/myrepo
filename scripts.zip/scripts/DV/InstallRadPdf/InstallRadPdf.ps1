﻿# RAD PDF Silent/Remote Install

$target = "dvweb02uwwl"

$RadPdfInstallPath = "\\dfs\NAS\DV_Shared\WebApp Deploy\RadPdf\RadPdfInstaller2.19.exe"

$LocalPath = "\\dvweb02uwwl\C$\scripts"

Copy-Item -Path $RadPdfInstallPath -Destination $LocalPath -ErrorAction Stop

Invoke-Command -ComputerName $target -ScriptBlock {cmd /c "C:\scripts\RadPdfInstaller2.19.exe /quiet"} -ErrorAction Stop
