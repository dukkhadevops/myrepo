﻿# Computers to update
$computers = Get-Content -Path "C:\Git\Scripts\DV\UpdateMailroomToolkit\computers.txt"
######################################
#UPDATE THESE VALUES BELOW WHEN NEEDED
######################################
$foldername = "MRTK-01-2020"
$license = "1B6HEL3-AS1BF8-IMFGU"
######################################

#credentials for connecting to each machine
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

#######################
#reboot true or false??
#######################
$reboot = $true


Foreach ($target in $computers) {
    If (Test-WSMan -ComputerName $target -Verbose)
    {
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        $fileshareinstaller = "`"\\dfs\nas\DV_Shared\WebApp Deploy\MRTK\$foldername\setup.exe`""
        $installparams = " -s -k`"$license`" -xT -oT -pT -fT -hT -vT /f2`"C:\scripts\"+$foldername+"_setup.log`""
        $mrtkfullinstall = $fileshareinstaller+$installparams

        echo "starting mailroom install on $target"
        Invoke-Command -Session $session -ScriptBlock {param($mrtkfullinstall) cmd /c $mrtkfullinstall} -ArgumentList $mrtkfullinstall -Verbose
        echo "Mailroom installed on $target"

        #remove session
        Remove-PSSession $session

        # reboot option
        if ($reboot -eq $true) {
            echo "Sending Reboot command to $target"
            echo " "
            echo " "
            shutdown -r -f -m \\$target -t 01
        }

    #endif
    }

#endforeach
}