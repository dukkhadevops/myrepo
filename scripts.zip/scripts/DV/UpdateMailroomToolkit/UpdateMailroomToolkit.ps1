﻿########
# Author:               John Basso
# Description:          Script to install/update Mailroom Toolkit on Dataverify servers
#                       09/18/2019    script created
#
#########

### THIS SCRIPT WILL TRIGGER A REBOOT AFTER THE UPDATE ###
### CHANGE THE REBOOT OPTION AS NEEDED ###

$reboot = $true # Reboot option

# Computers to update
$computers = Get-Content -Path "C:\Git\Scripts\DV\UpdateMailroomToolkit\computers.txt"

# Mailroom Toolkit Module
$InstallMailroomToolkit_modulepath = "C:\GIT\Scripts\DV\InstallMailroomToolkit\InstallMailroomToolkit.psm1"
Import-Module -Name $InstallMailroomToolkit_modulepath -Verbose

# Get admin credentials once, to be used for all computers listed
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"

Foreach ($target in $computers) {
    
    #region Parse Server Name into variables
    # Split string into 3 pieces using regex for two digits - "dvweb" "02" "uwwl"
    $targetarray = $target -Split '(\d\d)'
    # Read the first string, which is the Root Name for the server
    $RootName = $targetarray[0]
    # Read the second string, which is the double digit number in the server name
    $Number = $targetarray[1]
    # Read the third string, which includes Location/Support Team/Type/Environment
    $Details = $targetarray[2]
    $ServerLocation = $($Details[0])
    # Read the first two characters of the Root Name, then join them as a string (dv from dvweb)
    $Prefix = $RootName[0,1] -join ''
    $Prefix = $($Prefix.ToLower())
    # Read the Root Name, starting after the second character (web from dvweb)
    $ServerType = $RootName.Substring(2)
    $ServerType = $($ServerType.ToLower())
    # Read last character for Environment
    $Environment = $Details.Substring($Details.Length-1)
    # Update Environment variable
    switch ($Environment){
        "l"{$Environment = "lab"}
        "d"{$Environment = "dev"}
        "q"{$Environment = "qa"}
        "u"{$Environment = "uat"}
        "p"{$Environment = "prod"}
    }
    #endregion

    #region Set up Server Type Flags
    switch ($ServerType){
        "app"{
            $FlagMRTKfull = $true
            $FlagMRTKcom = $false
        }
        "bp"{
            $FlagMRTKfull = $true
            $FlagMRTKcom = $false
        }
        "batch"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "fnma"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "gw"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $true
        }
        "inapi"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "inet"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "intgw"{
            $FlagMRTKfull = $true
            $FlagMRTKcom = $false
        }
        <#"mrtk"{
            $FlagMRTKfull = $true
            $FlagMRTKcom = $false
        }#>
        "pdf"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "score"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $true
        }
        "svc"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "task"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $false
        }
        "taskapi"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $true
        }
        "web"{
            $FlagMRTKfull = $false
            $FlagMRTKcom = $true
        }
    }
    #endregion

    #region install MailroomToolkit using InstallMailroomToolkit.psm1
    # $MRTK_installtype is ignored when performing an update (installer switches are only used during the initial install)
    if ($FlagMRTKfull -eq $true) {
        $MRTK_installtype = "Full"
    }
    if ($FlagMRTKcom -eq $true) {
        $MRTK_installtype = "COM"
    }
    if (($FlagMRTKfull -eq $true) -or ($FlagMRTKcom -eq $true)) {
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        InstallMailroomToolkit $target $MRTK_installtype $reboot
        Remove-PSSession $session
    }
    #endregion
}

<# Simple bulk install/update
$reboot = $true # Reboot option
# Computers to update
$computers = Get-Content -Path "C:\Git\Scripts\DV\UpdateMailroomToolkit\computers.txt"
# Mailroom Toolkit Module
$InstallMailroomToolkit_modulepath = "C:\GIT\Scripts\DV\InstallMailroomToolkit\InstallMailroomToolkit.psm1"
Import-Module -Name $InstallMailroomToolkit_modulepath -Verbose
# Get admin credentials once, to be used for all computers listed
$credential = Get-Credential -Message "USE YOUR .1/ADMIN CREDENTIAL HERE"
$MRTK_installtype = "COM" # Use "COM" or "Full" for install type (This is ignored when updating an existing install)
Foreach ($target in $computers) {
        $session = New-PSSession -ComputerName $target -Authentication Credssp -Credential $credential
        InstallMailroomToolkit $target $MRTK_installtype $reboot 
        Remove-PSSession $session
}
#>