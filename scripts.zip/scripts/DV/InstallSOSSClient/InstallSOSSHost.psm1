########
# Author:               Matt Keller
# Description:          Module to install SOSS Client intended for use on DV Web, Gateway and Intranet servers
#                       10/4/2018      Copy everything from DV-SOSS-Dev installer and begin building script
#                       10/5/2018      turn working sossclientinstall script into a function and then into a module we can import for use later
#                       12/11/2018     swap to SOSSHost instead of client (change InstallLevel value from 500 to 1000)
#                       12/2/2019      Changed input parameter to Environment to automatically select the correct ports and license
#
########

#some assumptions for this module/function, since it is originally designed for DV environment and in conjunction with DV Powershell DSC configuration/builds of server.
#1)we'll be running the installer from c:\scripts on the target server so this script will create it and use it if it doesn't exist already
#2)the account you're running this under has access to the machine and permissions to install applications

#here is the command we tested successfully when ran locally on the server
#soss set 10.1.5.225 net_interface=10.1.5.0 subnet_mask=255.255.255.0 mgt_port=730 svr_port=731 int_port 732 license_key=JBMy3Nyz4uE-AtNfbn44li6 auto_join=1 accept_secure=1 secure_mgt_port=733 secure_svr_port=734 

#example call of new soss host install function with all parameters
#Import-Module C:\Git\Scripts\DV\InstallSOSSClient\InstallSOSSHost.psm1
#InstallSOSSHost dvsoss01uwad DEV
#InstallSOSSHost $target $Environment
# Environment Variable options - DEV QA UAT PRODUA PRODML

function InstallSOSSHost{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$True,Position=2)]
        [ValidateSet("DEV", "QA", "UAT", "PRODUA", "PRODML")]
            [string]$Environment
    )

    # Assign variables based on Environment
    switch ($Environment) {
        "DEV"{$mgt_port="730";$svr_port="731";$int_port="732";$secure_mgt_port="733";$secure_svr_port="734";$licensekey="MozvzHFJOQ-8a9Y2nwWNdk"}
        "QA"{$mgt_port="740";$svr_port="741";$int_port="742";$secure_mgt_port="743";$secure_svr_port="744";$licensekey="JpTii9g3xO-8a9Y2nwWNdk"}
        "UAT"{$mgt_port="720";$svr_port="721";$int_port="722";$secure_mgt_port="723";$secure_svr_port="724";$licensekey="1OZcm3xb5C2-6U6TPgAKGXY"}
        "PRODUA"{$mgt_port="720";$svr_port="721";$int_port="722";$secure_mgt_port="723";$secure_svr_port="724";$licensekey="JJfoRGd7u0u-8zGculDT1Iz"}
        "PRODML"{$mgt_port="720";$svr_port="721";$int_port="722";$secure_mgt_port="723";$secure_svr_port="724";$licensekey="7MSSIGOAsEb-8zGculDT1Iz"}
    }

    #do an nslookup to get $ComputerName IPAddress and save it in a variable
    $temp1 = Test-Connection $ComputerName -count 1 | select Ipv4Address
    #$temp2 = Test-Connection pfoxsoss01uwal -count 1 | select Ipv4Address
    $ipaddress = $temp1.IPV4Address.ToString()
    #$ipaddress2 = $temp2.IPV4Address.ToString()
    $ipbyte = $ipaddress.Split(".")
    $net_interface = ($ipbyte[0]+"."+$ipbyte[1]+"."+$ipbyte[2]+".0")

    #setup some base variables for us to work with
    $target = $ComputerName
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #SOSS
    $sossfileshare = "\\dfs\nas\dv_shared\webapp deploy\soss\soss_setup64.msi"
    $sossfilename = Split-Path $sossfileshare -Leaf
    $sosstargetdest = $localpath + "\" + $sossfilename
    #installlevel=1000 for host =500 for client
    $sossargs = "/i $sosstargetdest /quiet INSTALLLEVEL=1000"
    $sossexelocalpath = "C:\Program Files\Scaleout_Software\StateServer\soss.exe"
    
    #SOSS Final setup arguments
    #$sossexeargs = "add 730,10.255.15.88,731"
    #$sossexeargs = "add targetipaddress mgt_port,gateway_ip,svr_port"
    #$sossexeargs = "add $mgt_port,$gateway_ip,$svr_port"
    #soss set 10.1.5.225 net_interface=10.1.5.0 subnet_mask=255.255.255.0 mgt_port=730 svr_port=731 int_port=732 license_key=JBMy3Nyz4uE-AtNfbn44li6 auto_join=1 accept_secure=1 secure_mgt_port=733 secure_svr_port=734 
    $sossexeargs = "set $ipaddress net_interface=$net_interface subnet_mask=255.255.255.0 mgt_port=$mgt_port svr_port=$svr_port int_port=$int_port license_key=$licensekey accept_secure=1 secure_mgt_port=$secure_mgt_port secure_svr_port=$secure_svr_port"
    # Note: You must manually set "Join on Start" then reboot for the new host to join the Store
    # To add that to the exeargs, include "set auto_join=1"
    # To immediately add the new host to the Store, run "soss.exe join"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy SOSS install locally & install via silent install using the arguments from above
        Try 
        {
            #copy jobs and echoes first
            echo "copying SOSS installer to $target"
            Copy-Item -Path $sossfileshare -Destination $destpath -ErrorAction Stop
            Start-Sleep 3
            echo "copying okay to $target"

            #trigger install with echoes before and after
            echo "starting SOSS install on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath msiexec $p2 -Wait } -ArgumentList $sossargs -ErrorAction Stop
            echo "SOSS install okay on $target"

            #run soss set command to configure soss host
            echo "starting soss.exe set on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs -ErrorAction Stop
            echo "soss.exe set succeeded on $target"

            #reboot the Server
            #echo "attempting reboot on $target."
            #Restart-Computer -ComputerName $target -Force -ErrorAction SilentlyContinue
            #echo "either the server restarted or it did not restart because someone was still logged in"

        }
        Catch
        {
            echo "one of the SOSS steps failed on $target"
            break
        }

        #endregion
    
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }

#endfunction
}