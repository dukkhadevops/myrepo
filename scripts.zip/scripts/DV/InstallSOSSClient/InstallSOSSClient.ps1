########
# Author:               Matt Keller
# Description:          Script to install SOSS Client intended for use on DV Web, Gateway and Intranet servers
#                       10/4/2018      Copy everything from DV-SOSS-Dev installer and begin building script
#                       03/20/2019     try to get installs to work without re-running the script everytime. try to get add gateway and populate commands to work first time through as well.
#
########
# make sure you are running this under your .cbc account

$computers = Get-Content -Path "C:\GIT\Scripts\DV\InstallSOSSClient\computers.txt"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #SOSS
    $sossfileshare = "\\dfs\nas\dv_shared\webapp deploy\soss\soss_setup64.msi"
    $sossfilename = Split-Path $sossfileshare -Leaf
    $sosstargetdest = $localpath + "\" + $sossfilename

    #INSTALLLEVEL=1000 for HOST. 500 for CLIENT
    #$sossargs = "/i $sosstargetdest /quiet INSTALLLEVEL=1000"
    $sossargs = "/i $sosstargetdest /quiet INSTALLLEVEL=500"

    #soss_params.txt
    $sossparamstxt = "\\dfs\nas\dv_shared\WebApp Deploy\soss\DEV-soss_params.txt"
    $sossparamstxtdestpath = "\\" + $target + "\C$\Program Files\ScaleOut_Software\StateServer\soss_params.txt"

    #soss.exe
    $sossexelocalpath = "C:\Program Files\Scaleout_Software\StateServer\soss.exe"
    $sossexedestpath = "\\" + $target + "\c$\Program Files\Scaleout_Software\StateServer\soss.exe"
    #$sossexeargs1 = "join"
    $sossexeargs2 = "populate"

    #format for how to add gateways after soss client install
    #soss.exe add <mgt_port>,<gateway_IP>,<gateway_port>
    #EXAMPLE soss add 730,10.255.15.88,731
    $sossexeargs3 = "add 720,10.240.90.236,721"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy SOSS install locally & install via silent install using the path you specified above, then reboot
        Try
        {
            
            #copy jobs and echoes first
            echo "starting SOSS installer copy to $target"
            Copy-Item -Path $sossfileshare -Destination $destpath -ErrorAction Stop
            echo "SOSS installer copy okay on $target"

            #trigger install with echoes before and after
            echo "checking SOSS install on $target"
            #while path doesn't exist, do the loop
            While ((Test-Path $sossexedestpath -PathType leaf) -eq $false)
            {
                echo "no install detected, going through install on $target"
                Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath msiexec $p2 -Wait } -ArgumentList $sossargs -ErrorAction Stop
                Start-sleep -s 10

                #reboot the Server
                echo "since we did an install, triggering reboot on $target."
                Restart-Computer -ComputerName $target -Force -ErrorAction SilentlyContinue
                echo "since we did a reboot, start wait for 120s"
                Start-Sleep -s 120
            }
            echo "$sossexelocalpath exists on $target"
            
            
            ######SKIP FOR NOW. ONLY NEEDED FOR HOSTS NOT CLIENTS#####
            <#
            #overwrite soss_params.txt in local install directory
            echo "starting soss_params.txt overwrite on $target"
            Copy-Item -Path $sossparamstxt -Destination $sossparamstxtdestpath -Force -ErrorAction Stop
            echo "soss_params.txt overwrite successful on $target"
            
            #start sleep for a period of time to see if we can get the join to work on the first try
            echo "start sleep for 15s on $target"
            Start-Sleep -s 15
            echo "end sleep on $target"

            #run soss.exe populate
            echo "starting soss.exe populate on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs2 -ErrorAction Stop
            echo "soss.exe populate successful on $target"

            #run soss.exe join
            echo "starting soss.exe join on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs1 -ErrorAction Stop
            echo "soss.exe join successful on $target"
            
            #>
        }
            
        Catch
        {
            echo "Either the copy job, silent install or reboot failed $target"
            break
        }
        #endregion

        #region after install and reboot, do soss.exe add gateway and populate  
        Try
        {        
            While ((Test-WSMan -ComputerName $target) -eq $false) 
            {
                echo "checking if we can connect to $target yet"
                echo "starting sleep for 30"
                Start-Sleep -s 30
            }
            echo "now we should be able to connect to $target"

            #run soss add Gateway
            Start-Sleep -s 30
            echo "starting soss.exe add Gateway on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs3 -ErrorAction Stop
            echo "soss.exe add Gateway on $target succeeded"

            #run soss.exe populate
            Start-Sleep -s 10
            echo "starting soss.exe populate on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs2 -ErrorAction Stop
            echo "soss.exe populate successful on $target"
        }
        Catch
        {
            echo "either we cant reconnect after reboot, add gateway or populate commands failed on $target"
            break
        }

        #endregion 

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
}
