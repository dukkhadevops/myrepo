########
# Author:               Matt Keller
# Description:          Script to install SOSS Client intended for use on DV Web, Gateway and Intranet servers
#                       10/4/2018      Copy everything from DV-SOSS-Dev installer and begin building script
#                       03/20/2019     changed over to UNINSTALL version of script.
#                                      MAKE SURE YOU USE THE CORRECT VERSION FOR SOSS .MSI OTHERWISE THE UNINSTALL WILL NOT WORK. Uninstall MSI must match what is on the server you are trying to uninstall from.
#
########
# make sure you are running this under your .cbc account

$computers = Get-Content -Path "C:\GIT\Scripts\DV\InstallSOSSClient\computers.txt"

#for each computer target in our computers.txt file
Foreach ($target in $computers) {
    
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #SOSS
    #MAKE SURE YOU USE THE CORRECT VERSION FOR SOSS .MSI OTHERWISE THE UNINSTALL WILL NOT WORK
    $sossfileshare = "\\dfs\nas\DV_Shared\WebApp Deploy\SOSS\soss_setup64_5_7_1.msi"
    $sossfilename = Split-Path $sossfileshare -Leaf
    $sosstargetdest = $localpath + "\" + $sossfilename

    #IF YOU NEED LOGGING TO TROUBLESHOOT, USE THIS
    #$sossargs = "/x $sosstargetdest /quiet /L*V! C:\scripts\sossuninstall.log"
    #OTHERWISE USE THIS
    $sossargs = "/x $sosstargetdest /quiet"

    #soss.exe
    $sossexelocalpath = "C:\Program Files\Scaleout_Software\StateServer\soss.exe"
    #$sossexeargs1 = "join"
    #$sossexeargs2 = "populate"

    #format for how to add gateways after soss client install
    #soss.exe add <mgt_port>,<gateway_IP>,<gateway_port>
    #EXAMPLE soss add 730,10.255.15.88,731
    $sossexeargs3 = "add 720,10.240.90.236,721"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)){
             Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "c:\scripts exists or was created on $target"
             }

        Catch {
                echo "failed creating c:\scripts on $target"
                break
              }
        #endregion

        #region copy SOSS install locally & install via silent install using the path you specified above
        Try 
        {
            #copy jobs and echoes first
            echo "starting SOSS installer copy to $target"
            Copy-Item -Path $sossfileshare -Destination $destpath -ErrorAction Stop
            echo "SOSS installer copy okay on $target"

            #trigger install with echoes before and after
            echo "starting SOSS UNinstall on $target"
            Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath msiexec $p2 -Wait } -ArgumentList $sossargs -ErrorAction Stop
            echo "SOSS UNinstall okay on $target"

            #reboot the Server
            echo "attempting reboot on $target."
            Restart-Computer -ComputerName $target -Force -ErrorAction SilentlyContinue
            echo "either the server restarted or it did not restart because someone was still logged in"

        }
        Catch
        {
            echo "one of the SOSS steps failed on $target"
            break
        }

        #endregion

        #bunch of echoes to break things up
        echo " "
        echo "##### Done with $target #####"
        echo " "
        
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }
}
