########
# Author:               Matt Keller
# Description:          Module to install SOSS Client intended for use on DV Web, Gateway and Intranet servers
#                       10/4/2018      Copy everything from DV-SOSS-Dev installer and begin building script
#                       10/5/2018      turn working sossclientinstall script into a function and then into a module we can import for use later
#                       10/14/2019     Added parameter for Environment to automatically select the correct ports/IP address
#                       10/14/2019     Added parameters to use secure connection and populate other hosts into configuration
########

#some assumptions for this module/function, since it is originally designed for DV environment and in conjunction with DV Powershell DSC configuration/builds of server.
#1)we'll be running the installer from c:\scripts on the target server so this script will create it and use it if it doesn't exist already
#2)the account you're running this under has access to the machine and permissions to install applications

#soss.exe add <mgt_port>,<gateway_IP>,<gateway_port>
#soss.exe set_cli use_secure_conn=1
#wait 30 seconds
#soss.exe populate

#InstallSOSSClient ComputerName mgt_port gateway_ip gateway port
#$sossexeargs = "add 730,10.255.15.88,731"
#$sossexeargs2 = "set_cli use_secure_conn=1"
#$sossexeargs3 = "populate"

#example call of function
#Import-Module C:\Git\Scripts\DV\InstallSOSSClient\InstallSOSSClient.psm1
#InstallSOSSClient dvweb01uwwl DEV
#InstallSOSSClient $target $Environment
# Environment Variable options - DEV QA UAT PRODUA PRODML

function InstallSOSSClient{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,Position=1)]
            [string]$ComputerName,

        [Parameter(Mandatory=$True,Position=2)]
        [ValidateSet("DEV", "QA", "UAT", "PRODUA", "PRODML")]
            [string]$Environment
    )

    # Assign variables for ports and IP addresses based on Environment
    # DEV
    # 733,10.255.15.88,734
    # 733,10.255.15.90,734
    # QA
    # 743,10.255.15.89,744
    # 743,10.255.15.91,744
    # UAT
    # 723,10.255.15.92,724
    # 723,10.255.15.93,724
    # PROD UA
    # 723,172.16.192.129,724
    # 723,172.16.192.130,724
    # 723,172.16.192.131,724
    # PROD ML
    # 723,10.240.91.201,724
    # 723,10.240.91.202,724
    # 723,10.240.91.203,724
    switch ($Environment) {
        "DEV"{$mgt_port="733";$gateway_ip="10.255.15.88";$gateway_port="734"}
        "QA"{$mgt_port="743";$gateway_ip="10.255.15.89";$gateway_port="744"}
        "UAT"{$mgt_port="723";$gateway_ip="10.255.15.92";$gateway_port="724"}
        "PRODUA"{$mgt_port="723";$gateway_ip="172.16.192.129";$gateway_port="724"}
        "PRODML"{$mgt_port="723";$gateway_ip="10.240.91.201";$gateway_port="724"}
    }

    #do an nslookup to get $ComputerName IPAddress and save it in a variable
    $temp1 = Test-Connection $ComputerName -count 1 | select Ipv4Address
    $ipaddress = $temp1.IPV4Address.ToString()

    #setup some base variables for us to work with
    $target = $ComputerName
    $destpath = "\\" + $target + "\c$\scripts"
    $localpath = "C:\scripts"

    #SOSS
    $sossfileshare = "\\dfs\nas\dv_shared\webapp deploy\soss\soss_setup64.msi"
    $sossfilename = Split-Path $sossfileshare -Leaf
    $sosstargetdest = $localpath + "\" + $sossfilename
    #installlevel=1000 for host =500 for client
    $sossargs = "/i $sosstargetdest /quiet INSTALLLEVEL=500"
    $sossexelocalpath = "C:\Program Files\Scaleout_Software\StateServer\soss.exe"
    $sossexedestpath = "\\" + $target + "\c$\Program Files\Scaleout_Software\StateServer\soss.exe"

    #SOSS Final setup arguments
    #$sossexeargs = "add 730,10.255.15.88,731"
    #$sossexeargs = "add targetipaddress mgt_port,gateway_ip,gateway_port"
    $sossexeargs = "add $mgt_port,$gateway_ip,$gateway_port"
    $sossexeargs2 = "set_cli use_secure_conn=1"
    $sossexeargs3 = "populate"

    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose)
    {
        #region check if c:\scripts exists on hosts, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
             If(!(test-path $destpath)) {
                Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
            }
            echo " "
            echo "c:\scripts exists or was created on $target"
        }

        Catch {
            echo "failed creating c:\scripts on $target"
            break
        }
        #endregion

        #check if SOSS is already installed
        If(!(Test-Path $sossexedestpath)) {
            #region copy SOSS install locally & install via silent install using the arguments from above
            Try {
                #copy jobs and echoes first
                echo "copying SOSS installer to $target"
                Copy-Item -Path $sossfileshare -Destination $destpath -ErrorAction Stop
                echo "copying okay to $target"

                #trigger install with echoes before and after
                echo "starting SOSS install on $target"
                Invoke-Command -Computername $target -ScriptBlock { param($p2) Start-Process -Filepath msiexec $p2 -Wait } -ArgumentList $sossargs -ErrorAction Stop
                echo "SOSS install okay on $target"

                #run soss add Gateway
                echo "starting soss.exe add Gateway on $target"
                Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs -ErrorAction Stop
                echo "soss.exe add Gateway succeeded on $target"

                #run soss set_cli use_secure_conn=1
                echo "starting soss.exe set_cli use_secure_conn=1 on $target"
                Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs2 -ErrorAction Stop
                echo "soss.exe set_cli use_secure_conn=1 succeeded on $target"

                #run soss populate
                echo "waiting 30 seconds, then starting soss.exe populate on $target"
                Start-Sleep -Seconds 30
                Invoke-Command -Computername $target -ScriptBlock { param($p3,$p4) Start-Process -Filepath $p3 $p4 -Wait } -ArgumentList $sossexelocalpath,$sossexeargs3 -ErrorAction Stop
                echo "soss.exe populate succeeded on $target"

                #reboot the Server
                #echo "attempting reboot on $target."
                #Restart-Computer -ComputerName $target -Force -ErrorAction SilentlyContinue
                #echo "either the server restarted or it did not restart because someone was still logged in"
            }
            Catch {
                echo "one of the SOSS steps failed on $target"
                break
            }
        }
        Else {
            return "SOSS is already installed"
        }

        #endregion
    
    #endif
    }

    Else {
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
    }

#endfunction
}