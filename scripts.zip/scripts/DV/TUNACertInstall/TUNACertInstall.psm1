########
# Author:               Matt Keller / John Basso
# Description:          Module to install TUNA Certificate
#########
# Example module import/use:
# $TUNACertInstall_modulepath = "C:\GIT\Scripts\DV\TUNACertInstall\TUNACertInstall.psm1"
# Import-Module -Name $TUNACertInstall_modulepath -Verbose
#
# TUNACertInstall $target $SVCaccount $overwrite(optional)
# TUNACertInstall dvweb02uwwl svc_dvweb_l $false
#########

#region cert variables
#assign variables for each cert
$PlainTextPass = "Summer09"
$PFXcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\DATAVER5.pfx"
$certthumbvar = "BA1E734A7CF1A1E703A8878B7446A6BC1EE11165"
$CERcert = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\DATAVER5.cer"
$IntCAcert1 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\TUNA Ext Issuing CA1 G2.cer"
$IntCAcert1thumb = "99A51AA60ABF4BECE083ACD157821D758489EF34"
$IntCAcert2 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\TUNA Ext Policy CA1 G2.cer"
$IntCAcert2thumb = "22D749088F6B7E7584A0963E5FFE3A09798B5FC7"
$Rootcert1 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\TUNA Ext Root CA1 G2.cer"
$Rootcert1thumb = "FFC19B4ABCB08DE90933775529ABA881BE89A657"
$IntCAcert3 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\TUNA CA Intermediate Cust1.cer" # Old IntCA Cert
$IntCAcert3thumb = "FFADE580E8626FB8C598AEC79BA8296696966428"
$Rootcert2 = "\\dfs\nas\DV_Shared\WebApp Deploy\ssl_certs\TransUnion\5-23-2018\Contents\TUNA CA Root1.cer" # Old Root Cert
$Rootcert2thumb = "4493FB6839B7B3B68DC1EDBDE25EC8974C64BB7B"

#this returns the rightmost element from the path above (the cert name essentially)
$PFXcertname = Split-Path -Path $PFXcert -Leaf
$CERcertname = Split-Path -Path $CERcert -Leaf
$IntCAcert1name = Split-Path -Path $IntCAcert1 -Leaf
$IntCAcert2name = Split-Path -Path $IntCAcert2 -Leaf
$Rootcert1name = Split-Path -Path $Rootcert1 -Leaf
$IntCAcert3name = Split-Path -Path $IntCAcert3 -Leaf # Old IntCA Cert
$Rootcert2name = Split-Path -Path $Rootcert2 -Leaf # Old Root Cert
#endregion

#region LogWrite function
$logfile = "C:\GIT\Scripts\DV\TUNACertInstall\log.txt"
Function LogWrite{
    Param ([string]$logstring)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp -- $target -- $logstring"
    Add-Content $logfile -Value $Line
}
#endregion

#region import-pfxcertificate function
#Invoke-Command -ComputerName $target -ScriptBlock ${Function:Import-PfxCertificate1} -ArgumentList ("c:\temp\certs\DATAVER5.pfx","LocalMachine","My", "Summer09", $pfxThumb)
Function Import-PfxCertificate1 {
    param(
        [String]$certPath,
        [String]$certRootStore,
        [String]$certStore,
        [String]$pfxPass,
        [String]$certthumbvar
    )
    # Confirm certificate does not exist before installing
    $CheckForCert = Get-ChildItem -Path cert:\$certRootStore\$certStore | Where { $_.ThumbPrint -eq $certthumbvar }
    if ($CheckForCert -eq $null) {
        # Setup certificate
        $PrivateKeyPassword = $pfxPass | ConvertTo-SecureString -AsPlainText -Force
        $Flags = "MachineKeySet,PersistKeySet,Exportable"
        $Certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $Certificate.Import($certPath, $PrivateKeyPassword, $Flags)

        # Install certificate into machine store
        $Store = New-Object System.Security.Cryptography.X509Certificates.X509Store($certStore,$certRootStore)
        $Store.Open("MaxAllowed")
        $Store.Add($Certificate)
        $Store.Close()
    }
    Else {
        echo "`n*** PFX Certificate is already installed ***"
    }
}
#endregion

#region function to set certificate permissions
Function Set-CertificatePermission {
    param(
        [Parameter(Position=1, Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$pfxThumbPrint,

        [Parameter(Position=2, Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$serviceAccount
    )

    $cert = Get-ChildItem -Path cert:\LocalMachine\My | Where-Object -FilterScript { $PSItem.ThumbPrint -eq $pfxThumbPrint }

    # Specify the user, the permissions and the permission type
    $permission = "$($serviceAccount)","Read,FullControl","Allow"
    $accessRule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $permission

    # Location of the machine related keys
    $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\"
    $keyName = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
    $keyFullPath = $keyPath + $keyName

    try {
        # Get the current acl of the private key
        $acl = (Get-Item $keyFullPath).GetAccessControl('Access')

        # Add the new ace to the acl of the private key
        $acl.AddAccessRule($accessRule)

        # Write back the new acl
        Set-Acl -Path $keyFullPath -AclObject $acl
    }
    catch {
        throw $_
    }
}
#endregion

#region TUNA Cert Install
Function TUNACertInstall {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true,Position=1)]
            [string]$target,

        [Parameter(Mandatory=$true,Position=2)]
            [string]$SVCaccount,

        [Parameter(Mandatory=$false,Position=4)]
            $overwrite = $false
    )

    # variables
    $destpath = "\\" + $target + "\c$\temp\certs\"
    $localpath = "c:\temp\certs\"
    $appcertsdestpath = "\\" + $target + "\c$\app\certs\"
    $appcertslocalpath = "c:\app\certs\"

    #test connection. if connection works, then proceed, erroraction = stop
    If (Test-WSMan -ComputerName $target -ErrorAction Stop -Verbose){
        echo "test connection to $target SUCCESS"
        echo " "
        LogWrite "Test connection to $target SUCCESS"

        #region setup each targets local c:\temp\certs and copy certs
        #Do until tries = 3, try the copies and if success then success=true. catch and write to log and also sleep for 5s before continue
        #catch with erroraction = silentylycontinue so the retry loop continues
        $tries = 0
        $success = $null
        Do {
            Try {
                If (!(test-path $destpath)) {
                    #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
                    Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $localpath -ErrorAction Stop
                }
                echo " "
                echo "$localpath exists or was created on $target"
                LogWrite "$localpath exists or was created on $target"

                # Quick pause for C:\temp\certs folder creation
                Start-Sleep -Seconds 5

                # copy certs
                Copy-Item -Path $PFXcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $CERcert -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $IntCAcert1 -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $IntCAcert2 -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $Rootcert1 -Destination $destpath -Force -ErrorAction Stop
                Copy-Item -Path $IntCAcert3 -Destination $destpath -Force -ErrorAction Stop # Old IntCA Cert
                Copy-Item -Path $Rootcert2 -Destination $destpath -Force -ErrorAction Stop # Old Root Cert
                $success = $true
                echo " "
                echo "cert copies okay on $target"
                LogWrite "cert copies okay on $target"
            }
            Catch {
                echo "failed creating $localpath or copying certs on $target"
                LogWrite "failed creating $localpath or copying certs on $target. trycounter = $tries"
                Start-Sleep -Seconds 5
                $erroractionpreference="SilentlyContinue"
            }
            #increment tries
            $tries++
        #end do
        } Until ($tries -eq 3 -or $success)
        if (-not($success)) {exit}
        #endregion

        #region check if c:\app\certs exists on host, if not, create it.
        #invoke command on $target passing a scriptblock to execute makedir(md) with $p1 parameter($p1 is the path argument for md). -Argumentlist specifies $p1 parameter becomes $localpath
        Try {
            If (!(test-path $appcertsdestpath)) {
                Invoke-Command -Computername $target -ScriptBlock { param($p1) md $p1 } -ArgumentList $appcertslocalpath -ErrorAction Stop
                # Quick pause for C:\app\certs folder creation
                Start-Sleep -Seconds 5
            }
            echo " "
            echo "$appcertslocalpath exists or was created on $target"
            LogWrite "$appcertslocalpath exists or was created on $target"
        }
        Catch {
            echo "failed creating $appcertslocalpath on $target"
            LogWrite "failed creating $appcertslocalpath on $target"
            break
        }
        #endregion

        #region put cert in c:\app\certs and rename old to .old

        $appcertdest = $appcertsdestpath + "tuna.cer"
        $appcertdestold = $appcertsdestpath + "tuna.cer.old"
        $appcertname = Split-Path -Path $appcertdest -Leaf
        $copythiscert = $CERcert # dataver5.cer
        $RenameThisCert = $appcertsdestpath + "dataver5.cer"
        
        #if c:\app\certs\tuna.cer exists...
        If (Test-Path $appcertdest) {
            echo "$appcertdest exists"
            LogWrite "$appcertdest exists"

            #if overwrite=true then proceed with overwrite
            If ($overwrite -eq $true) {
                #if tuna.cer.old exists, delete it
                If (Test-Path $appcertdestold) {
                    echo "$appcertdestold exists too so we need to remove it"
                    LogWrite "$appcertdestold exists too so we need to remove it"
                    Remove-Item $appcertdestold -Force
                    echo "removed $appcertdestold"
                    LogWrite "removed $appcertdestold"
                }

                #rename tuna.cer to tuna.cer.old
                Rename-Item -path $appcertdest -NewName "$appcertname.old" -Force
                echo "$appcertdest renamed to .old"
                LogWrite "$appcertdest renamed to .old"

                #copy non-private-key cert to c:\app\certs
                Copy-Item -path $copythiscert -Destination $appcertsdestpath -Force -ErrorAction Stop
                echo "copied $copythiscert to $appcertsdestpath"
                LogWrite "copied $copythiscert to $appcertsdestpath"

                #rename dataver5.cer to tuna.cer
                Rename-Item -path $RenameThisCert -NewName "$appcertname" -Force
                echo "$RenameThisCert renamed to $appcertname"
                LogWrite "$RenameThisCert renamed to $appcertname"
            }
            #else overwrite=false so output that
            Else {
                echo "overwrite = $overwrite so no overwrite"
                LogWrite "overwrite = $overwrite so no overwrite"
            }
        #endif
        }
        #else if tuna.cer doesnt exist, just copy it
        Else {
            #copy non-private-key cert to c:\app\certs
            Copy-Item -path $copythiscert -Destination $appcertsdestpath -Force -ErrorAction Stop
            echo "copied $copythiscert to $appcertsdestpath"
            LogWrite "copied $copythiscert to $appcertsdestpath"

            #rename dataver5.cer to tuna.cer
            Rename-Item -path $RenameThisCert -NewName "$appcertname" -Force
            echo "$RenameThisCert renamed to $appcertname"
            LogWrite "$RenameThisCert renamed to $appcertname"
        }
        #endregion

        #region for importing certs - invoke cert import command with password

        $PFXlocalcert = $localpath + $PFXcertname #Prod Cert
        $IntCAlocalcert1 = $localpath + $IntCAcert1name #IntCA
        $IntCAlocalcert2 = $localpath + $IntCAcert2name #IntCA
        $Rootlocalcert1 = $localpath + $Rootcert1name #Root
        $IntCAlocalcert3 = $localpath + $IntCAcert3name # Old IntCA Cert
        $Rootlocalcert2 = $localpath + $Rootcert2name # Old Root Cert

        Try {
            Invoke-Command -ComputerName $target -ScriptBlock ${Function:Import-PfxCertificate1} -ArgumentList ($PFXlocalcert, "LocalMachine", "My", $PlainTextPass, $certthumbvar)
            echo " "
            echo "############################################################################################################################################"
            echo "local cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "local cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($IntCAlocalcert1,$IntCAlocalcert2,$IntCAlocalcert3,$IntCAcert1thumb,$IntCAcert2thumb,$IntCAcert3thumb)
                # Confirm certificate does not exist before installing
                $CheckForCert1 = Get-ChildItem -Path cert:\LocalMachine\CA | Where { $_.ThumbPrint -eq $IntCAcert1thumb }
                if ($CheckForCert1 -eq $null) {
                    Import-Certificate -FilePath $IntCAlocalcert1 -CertStoreLocation Cert:\LocalMachine\CA
                }
                else {
                    echo "*** Intermediate Certificate1 is already installed ***"
                }
                # Confirm certificate does not exist before installing
                $CheckForCert2 = Get-ChildItem -Path cert:\LocalMachine\CA | Where { $_.ThumbPrint -eq $IntCAcert2thumb }
                if ($CheckForCert2 -eq $null) {
                    Import-Certificate -FilePath $IntCAlocalcert2 -CertStoreLocation Cert:\LocalMachine\CA
                }
                else {
                    echo "*** Intermediate Certificate2 is already installed ***"
                }
                # Confirm certificate does not exist before installing
                $CheckForCert3 = Get-ChildItem -Path cert:\LocalMachine\CA | Where { $_.ThumbPrint -eq $IntCAcert3thumb }
                if ($CheckForCert3 -eq $null) {
                    Import-Certificate -FilePath $IntCAlocalcert3 -CertStoreLocation Cert:\LocalMachine\CA
                }
                else {
                    echo "*** Intermediate Certificate3 is already installed ***"
                }
            } -ArgumentList ($IntCAlocalcert1,$IntCAlocalcert2,$IntCAlocalcert3,$IntCAcert1thumb,$IntCAcert2thumb,$IntCAcert3thumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "INTERMEDIATE cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "INTERMEDIATE cert import okay"

            Invoke-Command -Computername $target -ScriptBlock {
                param($Rootlocalcert1,$Rootlocalcert2,$Rootcert1thumb,$Rootcert2thumb)
                # Confirm certificate does not exist before installing
                $CheckForCert1 = Get-ChildItem -Path cert:\LocalMachine\Root | Where { $_.ThumbPrint -eq $Rootcert1thumb }
                if ($CheckForCert1 -eq $null) {
                    Import-Certificate -FilePath $Rootlocalcert1 -CertStoreLocation Cert:\LocalMachine\Root
                }
                else {
                    echo "*** Root Certificate1 is already installed ***"
                }
                # Confirm certificate does not exist before installing
                $CheckForCert2 = Get-ChildItem -Path cert:\LocalMachine\Root | Where { $_.ThumbPrint -eq $Rootcert2thumb }
                if ($CheckForCert2 -eq $null) {
                    Import-Certificate -FilePath $Rootlocalcert2 -CertStoreLocation Cert:\LocalMachine\Root
                }
                else {
                    echo "*** Root Certificate2 is already installed ***"
                }
            } -ArgumentList ($Rootlocalcert1,$Rootlocalcert2,$Rootcert1thumb,$Rootcert2thumb) -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "ROOT cert import okay on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "ROOT cert import okay"
        }
        Catch {
            echo "failed cert imports on $target"
            LogWrite "failed cert imports"
            break
        }
        #endregion

        #region for setting private key permissions on TALX cert
        Try {
            #Set-CertificatePermission $certthumbvar $SVCaccount
            Invoke-Command -ComputerName $target -ScriptBlock ${Function:Set-CertificatePermission} -ArgumentList ($certthumbvar, $SVCaccount)
            echo " "
            echo "############################################################################################################################################"
            echo "Certificate Private Key Permissions for $SVCaccount set on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "Certificate Private Key Permissions for $SVCaccount set on $target"
        }
        Catch {
            echo "failed to set Certificate Private Key Permissions for $SVCaccount on $target"
            LogWrite "setting Certificate Private Key Permissions for $SVCaccount failed on $target"
            break
        }
        #endregion

        #region cleanup c:\temp\certs
        Try {
            Invoke-Command -Computername $target -ScriptBlock { param($p1) remove-item -Path $p1 -recurse -Force } -ArgumentList $localpath -ErrorAction Stop
            echo " "
            echo "############################################################################################################################################"
            echo "$localpath deleted on $target"
            echo "############################################################################################################################################"
            echo " "
            LogWrite "c:\temp\certs cleanup success"
        }
        Catch {
            echo "failed to delete $localpath on $target"
            LogWrite "failed to delete $localpath on $target"
            break
        }
        #endregion

        # Quick pause for C:\temp\certs folder cleanup
        Start-Sleep -Seconds 5

        #iisreset if you want it
        #invoke-command -computername $target {cd C:\Windows\System32\; ./cmd.exe /c "iisreset" }

        #end if for test connection
    }
    Else { 
        echo "connection to $target failed. Try running winrm /quickconfig on the destination host and try again"
        LogWrite "connection to $target failed. Try running winrm /quickconfig on the destination host and try again" 
    }
#end function
}
#endregion